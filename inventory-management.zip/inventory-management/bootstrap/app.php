<?php

use App\Http\Middleware\PermissionMiddleware;
use App\Http\Middleware\ApplySystemSettings;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->trustProxies(at: ['127.0.0.1', '::1']);
        $middleware->alias([
            'permission' => PermissionMiddleware::class,
        ]);
        $middleware->appendToGroup('web', ApplySystemSettings::class);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
