
<?php $__env->startSection('title', 'ព័ត៌មានការជូនដំណឹង'); ?>
<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-3xl">
    <a href="<?php echo e(route('notifications.index')); ?>" class="text-sm text-blue-700">← ត្រឡប់ទៅការជូនដំណឹង</a>
    <article class="mt-4 rounded-xl bg-white p-6 shadow-sm">
        <div class="flex flex-wrap items-center gap-2">
            <h1 class="text-2xl font-bold"><?php echo e($notification->data['title'] ?? 'ការជូនដំណឹង'); ?></h1>
            <span class="rounded-full bg-slate-100 px-2 py-1 text-xs"><?php echo e(\App\Notifications\InventoryNotification::typeLabel($notification->data['event_type'] ?? 'system.alert')); ?></span>
        </div>
        <p class="mt-4 whitespace-pre-line text-slate-700"><?php echo e($notification->data['message'] ?? ''); ?></p>
        <dl class="mt-6 grid gap-3 border-t pt-4 sm:grid-cols-2">
            <div><dt class="text-xs text-slate-500">ប្រភេទ</dt><dd class="mt-1 text-sm"><?php echo e(\App\Notifications\InventoryNotification::typeLabel($notification->data['event_type'] ?? 'system.alert')); ?></dd></div>
            <div><dt class="text-xs text-slate-500">ស្ថានភាព</dt><dd class="mt-1 text-sm"><?php echo e($notification->read_at ? 'បានអាន' : 'មិនទាន់អាន'); ?></dd></div>
            <div><dt class="text-xs text-slate-500">កាលបរិច្ឆេទ</dt><dd class="mt-1 text-sm"><?php echo e(app(\App\Services\SystemSettingsService::class)->formatDate($notification->created_at, true)); ?></dd></div>
            <?php if(! empty($notification->data['record_type']) && ! empty($notification->data['record_id'])): ?>
                <div><dt class="text-xs text-slate-500">កំណត់ត្រាយោង</dt><dd class="mt-1 text-sm"><?php echo e(class_basename($notification->data['record_type'])); ?> #<?php echo e($notification->data['record_id']); ?></dd></div>
            <?php endif; ?>
        </dl>
        <div class="mt-6 flex flex-wrap gap-2">
            <?php if(! empty($notification->data['url'])): ?>
                <a href="<?php echo e($notification->data['url']); ?>" class="rounded-lg bg-blue-700 px-4 py-2 text-sm text-white">ទៅកាន់កំណត់ត្រា</a>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route($notification->read_at ? 'notifications.unread' : 'notifications.read', $notification->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <button class="rounded-lg border px-4 py-2 text-sm"><?php echo e($notification->read_at ? 'សម្គាល់មិនទាន់អាន' : 'សម្គាល់ថាបានអាន'); ?></button>
            </form>
            <form method="POST" action="<?php echo e(route('notifications.destroy', $notification->id)); ?>" onsubmit="return confirm('លុបការជូនដំណឹងនេះ?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="rounded-lg border border-red-200 px-4 py-2 text-sm text-red-700">លុប</button>
            </form>
        </div>
    </article>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/notifications/show.blade.php ENDPATH**/ ?>