
<?php $__env->startSection('title', 'ដកស្តុក'); ?>
<?php $__env->startSection('content'); ?>
<div><h1 class="text-2xl font-bold">ដកស្តុក</h1><p class="mt-1 text-sm text-slate-500">កាត់បន្ថយបរិមាណស្តុក</p></div>
<?php echo $__env->make('stock._transaction_form', ['mode' => 'out', 'action' => route('stock.out.store'), 'confirmText' => 'តើអ្នកពិតជាចង់ដកស្តុកមែនទេ?'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/stock/out.blade.php ENDPATH**/ ?>