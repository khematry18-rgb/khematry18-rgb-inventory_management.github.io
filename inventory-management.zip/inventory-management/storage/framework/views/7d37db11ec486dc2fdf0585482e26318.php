
<?php $__env->startSection('title', 'ព័ត៌មានអ្នកផ្គត់ផ្គង់'); ?>
<?php $__env->startSection('content'); ?>
<div class="flex flex-wrap items-center justify-between gap-3">
    <div><h1 class="text-2xl font-bold text-slate-900"><?php echo e($supplier->name); ?></h1><p class="mt-1 text-sm text-slate-500"><?php echo e($supplier->company_name ?: 'អ្នកផ្គត់ផ្គង់'); ?></p></div>
    <a href="<?php echo e(route('suppliers.edit', $supplier)); ?>" class="rounded-lg bg-blue-700 px-4 py-2 text-white">កែសម្រួល</a>
</div>

<div class="mt-5 grid gap-5 lg:grid-cols-3">
    <section class="rounded-xl bg-white p-5 shadow-sm lg:col-span-2">
        <h2 class="font-semibold text-slate-900">ព័ត៌មានទំនាក់ទំនង</h2>
        <dl class="mt-4 grid gap-4 sm:grid-cols-2">
            <div><dt class="text-sm text-slate-500">អ្នកទំនាក់ទំនង</dt><dd class="mt-1"><?php echo e($supplier->contact_person ?: '—'); ?></dd></div>
            <div><dt class="text-sm text-slate-500">លេខទូរស័ព្ទ</dt><dd class="mt-1"><?php echo e($supplier->phone ?: '—'); ?></dd></div>
            <div><dt class="text-sm text-slate-500">អ៊ីមែល</dt><dd class="mt-1"><?php echo e($supplier->email ?: '—'); ?></dd></div>
            <div><dt class="text-sm text-slate-500">លេខអត្តសញ្ញាណពន្ធ</dt><dd class="mt-1"><?php echo e($supplier->tax_id ?: '—'); ?></dd></div>
            <div><dt class="text-sm text-slate-500">ទីក្រុង</dt><dd class="mt-1"><?php echo e($supplier->city ?: '—'); ?></dd></div>
            <div><dt class="text-sm text-slate-500">ប្រទេស</dt><dd class="mt-1"><?php echo e($supplier->country ?: '—'); ?></dd></div>
            <div class="sm:col-span-2"><dt class="text-sm text-slate-500">អាសយដ្ឋាន</dt><dd class="mt-1 whitespace-pre-line"><?php echo e($supplier->address ?: '—'); ?></dd></div>
            <div class="sm:col-span-2"><dt class="text-sm text-slate-500">កំណត់ចំណាំ</dt><dd class="mt-1 whitespace-pre-line"><?php echo e($supplier->notes ?: '—'); ?></dd></div>
        </dl>
    </section>
    <section class="rounded-xl bg-white p-5 shadow-sm">
        <h2 class="font-semibold text-slate-900">ស្ថិតិការទិញ</h2>
        <div class="mt-4 space-y-3">
            <div class="flex justify-between"><span class="text-slate-500">ការទិញសរុប</span><strong><?php echo e($supplier->purchases_count); ?></strong></div>
            <div class="flex justify-between gap-3"><span class="text-slate-500">តម្លៃបានបញ្ជាក់</span><strong class="text-right"><?php $__empty_1 = true; $__currentLoopData = $totalPurchaseAmounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency => $amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php echo e(app(\App\Services\SystemSettingsService::class)->formatAmount((float) $amount->total, $currency)); ?><?php if(!$loop->last): ?><br><?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>—<?php endif; ?></strong></div>
            <div class="flex justify-between"><span class="text-slate-500">ស្ថានភាព</span><strong><?php echo e($supplier->is_active ? 'សកម្ម' : 'អសកម្ម'); ?></strong></div>
        </div>
    </section>
</div>

<section class="mt-5 rounded-xl bg-white p-5 shadow-sm">
    <h2 class="font-semibold text-slate-900">ប្រវត្តិការទិញថ្មីៗ</h2>
    <div class="mt-4 overflow-x-auto">
        <table class="min-w-full divide-y divide-slate-200">
            <thead><tr><th class="px-3 py-2 text-left text-sm text-slate-600">លេខការទិញ</th><th class="px-3 py-2 text-left text-sm text-slate-600">កាលបរិច្ឆេទ</th><th class="px-3 py-2 text-left text-sm text-slate-600">ស្ថានភាព</th><th class="px-3 py-2 text-right text-sm text-slate-600">សរុប</th></tr></thead>
            <tbody class="divide-y divide-slate-100">
            <?php $__empty_1 = true; $__currentLoopData = $recentPurchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr><td class="px-3 py-3"><?php echo e($purchase->purchase_number); ?></td><td class="px-3 py-3"><?php echo e(app(\App\Services\SystemSettingsService::class)->formatDate($purchase->purchased_at)); ?></td><td class="px-3 py-3"><?php echo e($purchase->status); ?></td><td class="px-3 py-3 text-right"><?php echo e(app(\App\Services\SystemSettingsService::class)->formatAmount((float) $purchase->grand_total, $purchase->currency ?: 'USD')); ?></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="px-3 py-6 text-center text-slate-500">មិនទាន់មានប្រវត្តិការទិញ</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/suppliers/show.blade.php ENDPATH**/ ?>