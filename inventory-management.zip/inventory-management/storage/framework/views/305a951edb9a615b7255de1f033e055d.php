
<?php $__env->startSection('title','POS លក់ទំនិញ'); ?>
<?php $__env->startSection('content'); ?>
<form id="sale-form" method="POST" action="<?php echo e(route('sales.store')); ?>" class="grid gap-4 lg:grid-cols-[minmax(0,1fr)_380px]">
<?php echo csrf_field(); ?>
<input type="hidden" name="submission_key" value="<?php echo e(\Illuminate\Support\Str::uuid()); ?>">
<div class="space-y-4">
    <div class="rounded-xl bg-white p-4 shadow-sm"><h1 class="text-xl font-bold">POS - លក់ទំនិញ</h1></div>
    <div class="grid gap-3 rounded-xl bg-white p-3 shadow-sm sm:p-4 md:grid-cols-[1fr_auto]">
        <input id="product-search" type="search" placeholder="ស្វែងរកឈ្មោះ ឬ SKU..." class="min-h-12 rounded-lg border-slate-300">
        <button id="camera-button" type="button" class="min-h-12 rounded-lg bg-blue-700 px-5 py-3 font-semibold text-white shadow-sm hover:bg-blue-800">ស្កេន Barcode តាមកាមេរ៉ា</button>
        <div id="barcode-area" class="md:col-span-2">
            <div class="flex gap-2">
                <input id="barcode-input" type="text" autocomplete="off" placeholder="បញ្ចូល ឬស្កេន Barcode ដោយដៃ" class="min-h-12 min-w-0 flex-1 rounded-lg border-slate-300">
                <button id="barcode-submit" type="button" class="min-h-12 rounded-lg bg-slate-700 px-5 text-white">ស្វែងរក</button>
            </div>
            <p class="mt-1 text-xs text-slate-500">អាចប្រើម៉ាស៊ីនស្កេនដែលភ្ជាប់ដូចក្តារចុច រួចចុច Enter។</p>
        </div>
        <div id="camera-panel" class="hidden md:col-span-2">
            <div class="flex items-center justify-between gap-3">
                <p class="text-sm font-medium text-slate-700">ដាក់ Barcode ឱ្យនៅក្នុងស៊ុមស្កេន</p>
                <button id="camera-stop-button" type="button" class="min-h-11 rounded-lg border border-red-300 px-4 text-red-700">បិទម៉ាស៊ីនស្កេន</button>
            </div>
            <div class="relative mt-3 overflow-hidden rounded-xl bg-black">
                <video id="camera-video" class="aspect-video max-h-[60vh] w-full object-cover" autoplay playsinline muted></video>
                <div class="pointer-events-none absolute inset-0 grid place-items-center" aria-hidden="true">
                    <div class="h-1/3 w-4/5 rounded-xl border-2 border-blue-300 shadow-[0_0_0_999px_rgba(0,0,0,0.28)]"></div>
                </div>
            </div>
        </div>
        <div id="search-results" class="md:col-span-2 grid gap-2 sm:grid-cols-2"></div>
    </div>
    <div class="rounded-xl bg-white shadow-sm"><div class="border-b px-4 py-3 font-semibold">ផលិតផល</div><div id="product-grid" class="grid max-h-[460px] gap-3 overflow-y-auto p-4 sm:grid-cols-2 lg:grid-cols-3">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button type="button" class="product-card text-left rounded-lg border p-3 hover:border-blue-500" data-id="<?php echo e($product->id); ?>" data-name="<?php echo e($product->name); ?>" data-sku="<?php echo e($product->sku); ?>" data-barcode="<?php echo e($product->barcode); ?>" data-price="<?php echo e($product->selling_price); ?>" data-stock="<?php echo e($product->stock_quantity); ?>" data-image="<?php echo e($product->image ? asset('storage/'.$product->image) : ''); ?>">
            <div class="mb-2 h-24 rounded bg-slate-100"><?php if($product->image): ?><img src="<?php echo e(asset('storage/'.$product->image)); ?>" alt="" class="h-full w-full rounded object-cover"><?php endif; ?></div>
            <div class="font-medium"><?php echo e($product->name); ?></div><div class="text-xs text-slate-500"><?php echo e($product->sku); ?> · ស្តុក <?php echo e(number_format((float)$product->stock_quantity,3)); ?></div><div class="mt-1 font-semibold text-blue-700"><?php echo e(app(\App\Services\SystemSettingsService::class)->formatAmount((float)$product->selling_price, 'USD')); ?></div>
        </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div></div>
</div>
<aside class="space-y-4">
    <div class="rounded-xl bg-white p-4 shadow-sm"><div class="flex items-center justify-between"><h2 class="font-semibold">រទេះទិញ</h2><button id="clear-cart" type="button" class="text-sm text-red-600">សម្អាតទាំងអស់</button></div><div id="cart-items" class="mt-3 space-y-2"></div></div>
    <div class="rounded-xl bg-white p-4 shadow-sm space-y-3">
        <h2 class="font-semibold">ព័ត៌មានអតិថិជន និងការទូទាត់</h2>
        <input type="text" name="customer_name" value="<?php echo e(old('customer_name', $settings['default_customer'])); ?>" placeholder="ឈ្មោះអតិថិជន" class="w-full rounded-lg border-slate-300">
        <div class="grid grid-cols-2 gap-2"><input type="text" name="customer_phone" value="<?php echo e(old('customer_phone')); ?>" placeholder="លេខទូរសព្ទ" class="rounded-lg border-slate-300"><input type="email" name="customer_email" value="<?php echo e(old('customer_email')); ?>" placeholder="Email" class="rounded-lg border-slate-300"></div>
        <textarea name="customer_address" rows="2" placeholder="អាសយដ្ឋាន" class="w-full rounded-lg border-slate-300"><?php echo e(old('customer_address')); ?></textarea>
        <label>រូបិយប័ណ្ណលក់<select id="sale-currency" name="currency" class="mt-1 w-full rounded-lg border-slate-300"><option value="USD" <?php if(old('currency', $settings['currency_code']) === 'USD'): echo 'selected'; endif; ?>>USD ($)</option><option value="KHR" <?php if(old('currency', $settings['currency_code']) === 'KHR'): echo 'selected'; endif; ?> <?php if(!$settings['exchange_rate']): echo 'disabled'; endif; ?>>KHR (៛)</option></select></label>
        <input type="datetime-local" name="sold_at" value="<?php echo e(old('sold_at', now()->format('Y-m-d\TH:i'))); ?>" required class="w-full rounded-lg border-slate-300">
        <div class="grid grid-cols-2 gap-2"><label>បញ្ចុះតម្លៃ (<span class="currency-label"><?php echo e($settings['currency_symbol']); ?></span>)<input id="discount" name="discount" type="number" step="0.01" min="0" value="<?php echo e(old('discount',0)); ?>" <?php if(!$settings['discounts_allowed']): echo 'readonly'; endif; ?> class="mt-1 w-full rounded-lg border-slate-300"></label><label>ពន្ធ (<span class="currency-label"><?php echo e($settings['currency_symbol']); ?></span>)<input id="tax" name="tax" type="number" step="0.01" min="0" value="<?php echo e(old('tax',0)); ?>" <?php if(!$settings['tax_enabled'] || (float)$settings['tax_rate'] > 0): echo 'readonly'; endif; ?> class="mt-1 w-full rounded-lg border-slate-300"></label></div>
        <label>វិធីទូទាត់<select name="payment_method" class="mt-1 w-full rounded-lg border-slate-300"><option value="cash">សាច់ប្រាក់</option><option value="bank">ធនាគារ</option><option value="aba">ABA</option><option value="acleda">ACLEDA</option><option value="other">ផ្សេងទៀត</option></select></label>
        <label>ប្រាក់អតិថិជនប្រគល់ (<span class="currency-label"><?php echo e($settings['currency_symbol']); ?></span>)<input id="cash-received" type="number" step="0.01" min="0" value="<?php echo e(old('amount_paid',0)); ?>" class="mt-1 min-h-12 w-full rounded-lg border-slate-300"></label>
        <input id="amount-paid" name="amount_paid" type="hidden" value="<?php echo e(old('amount_paid',0)); ?>">
        <input type="text" name="payment_reference" placeholder="លេខយោងការទូទាត់" class="w-full rounded-lg border-slate-300">
        <textarea name="notes" rows="2" placeholder="កំណត់ចំណាំ" class="w-full rounded-lg border-slate-300"><?php echo e(old('notes')); ?></textarea>
        <div class="space-y-1 border-t pt-3"><div class="flex justify-between"><span>សរុបរង</span><strong id="subtotal">$0.00</strong></div><div class="flex justify-between text-lg"><span>សរុបទាំងអស់</span><strong id="grand-total">$0.00</strong></div><div class="flex justify-between text-sm text-slate-500"><span>សមតុល្យ</span><strong id="balance">$0.00</strong></div><div class="flex justify-between text-sm text-green-700"><span>ប្រាក់អាប់</span><strong id="change-due">$0.00</strong></div></div>
        <div id="cart-error" class="hidden rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700"></div>
        <button id="submit-sale" type="button" class="min-h-14 w-full rounded-lg bg-green-700 px-4 py-3 text-lg font-semibold text-white">បញ្ចប់ការលក់</button>
    </div>
</aside>
</form>
<script>
const cart=new Map(), csrf=document.querySelector('meta[name="csrf-token"]').content;
const settings={currency:<?php echo json_encode($settings['currency_code'], 15, 512) ?>,rate:<?php echo json_encode((float)($settings['exchange_rate']??0), 15, 512) ?>,allowNegative:<?php echo json_encode($settings['allow_negative_stock'], 15, 512) ?>,taxEnabled:<?php echo json_encode($settings['tax_enabled'], 15, 512) ?>,taxRate:<?php echo json_encode((float)$settings['tax_rate'], 15, 512) ?>,discountsAllowed:<?php echo json_encode($settings['discounts_allowed'], 15, 512) ?>,decimal:<?php echo json_encode($settings['decimal_separator'], 15, 512) ?>,thousands:<?php echo json_encode($settings['thousands_separator'], 15, 512) ?>};
let currency=document.getElementById('sale-currency').value;
const productGrid=document.getElementById('product-grid'), cartItems=document.getElementById('cart-items'), barcodeInput=document.getElementById('barcode-input');
function transactionAmount(usd){return currency==='KHR'?usd*settings.rate:usd}
function formatAmount(value,code=currency){const digits=code==='KHR'?0:2,numeric=Number(value).toLocaleString('en-US',{minimumFractionDigits:digits,maximumFractionDigits:digits}).replaceAll(',',settings.thousands).replaceAll('.',settings.decimal);return code==='KHR'?numeric+'៛':'$'+numeric}
function addProduct(p){const existing=cart.get(p.id),qty=existing?existing.quantity+1:1;if(qty>Number(p.stock)&&!settings.allowNegative){showError('បរិមាណលើសស្តុកដែលមាន');return}if(existing){existing.quantity=qty}else{cart.set(p.id,{...p,basePrice:Number(p.price),price:transactionAmount(Number(p.price)),quantity:1})}document.getElementById('cart-error').classList.add('hidden');render()}
function render(){cartItems.replaceChildren();if(!cart.size){const empty=document.createElement('div');empty.className='py-4 text-center text-sm text-slate-500';empty.textContent='រទេះទំនេរ';cartItems.append(empty)}cart.forEach((p,id)=>{const row=document.createElement('div');row.className='grid grid-cols-[1fr_auto] gap-2 border-b pb-2';const details=document.createElement('div');const name=document.createElement('div');name.className='font-medium';name.textContent=p.name;const sku=document.createElement('div');sku.className='text-xs text-slate-500';sku.textContent=`${p.sku} · Barcode ${p.barcode||'-'}`;const stock=document.createElement('div');stock.className='text-xs text-slate-500';stock.textContent=`ស្តុក ${Number(p.stock).toLocaleString('en-US')}`;const price=document.createElement('div');price.className='text-sm font-medium';price.textContent=formatAmount(p.price);details.append(name,sku,stock,price);const controls=document.createElement('div');controls.className='text-right';const quantityControls=document.createElement('div');quantityControls.className='flex items-center gap-2';const decrease=document.createElement('button');decrease.type='button';decrease.dataset.dec=id;decrease.className='h-10 w-10 rounded border';decrease.textContent='−';const quantity=document.createElement('span');quantity.className='min-w-8 text-center font-semibold';quantity.textContent=p.quantity;const increase=document.createElement('button');increase.type='button';increase.dataset.inc=id;increase.className='h-10 w-10 rounded border';increase.textContent='+';quantityControls.append(decrease,quantity,increase);const remove=document.createElement('button');remove.type='button';remove.dataset.remove=id;remove.className='mt-1 min-h-9 text-sm text-red-600';remove.textContent='លុប';controls.append(quantityControls,remove);row.append(details,controls);cartItems.append(row)});document.querySelectorAll('#sale-form input[name^="items["]').forEach(el=>el.remove());let index=0;cart.forEach((p,id)=>{const pid=document.createElement('input');pid.type='hidden';pid.name=`items[${index}][product_id]`;pid.value=id;const qty=document.createElement('input');qty.type='hidden';qty.name=`items[${index}][quantity]`;qty.value=p.quantity;document.getElementById('sale-form').append(pid,qty);index++});calculate()}
function calculate(){let subtotal=0;cart.forEach(p=>subtotal+=Number(p.price)*p.quantity);subtotal=Math.round(subtotal*100)/100;const discountInput=document.getElementById('discount'),taxInput=document.getElementById('tax');const discount=settings.discountsAllowed?Math.max(0,Number(discountInput.value||0)):0;if(!settings.discountsAllowed)discountInput.value='0';if(settings.taxEnabled&&settings.taxRate>0)taxInput.value=(Math.max(0,subtotal-discount)*settings.taxRate/100).toFixed(2);if(!settings.taxEnabled)taxInput.value='0';const tax=settings.taxEnabled?Math.max(0,Number(taxInput.value||0)):0,grand=Math.max(0,Math.round((subtotal-discount+tax)*100)/100),received=Math.max(0,Number(document.getElementById('cash-received').value||0)),paid=Math.min(received,grand);document.getElementById('amount-paid').value=paid.toFixed(2);document.getElementById('subtotal').textContent=formatAmount(subtotal);document.getElementById('grand-total').textContent=formatAmount(grand);document.getElementById('balance').textContent=formatAmount(Math.max(0,grand-received));document.getElementById('change-due').textContent=formatAmount(Math.max(0,received-grand))}
function showError(msg){const e=document.getElementById('cart-error');e.textContent=msg;e.classList.remove('hidden')}
document.querySelectorAll('.product-card').forEach(b=>b.addEventListener('click',()=>addProduct({id:Number(b.dataset.id),name:b.dataset.name,sku:b.dataset.sku,barcode:b.dataset.barcode,price:b.dataset.price,stock:Number(b.dataset.stock)})));
cartItems.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const id=Number(b.dataset.inc||b.dataset.dec||b.dataset.remove);if(b.dataset.inc){const p=cart.get(id);if(p.quantity>=p.stock&&!settings.allowNegative)return showError('បរិមាណលើសស្តុកដែលមាន');p.quantity++}if(b.dataset.dec){const p=cart.get(id);p.quantity--;if(p.quantity<=0)cart.delete(id)}if(b.dataset.remove)cart.delete(id);render()});
document.getElementById('sale-currency').addEventListener('change',event=>{currency=event.target.value;cart.forEach(p=>p.price=transactionAmount(p.basePrice));document.querySelectorAll('.currency-label').forEach(label=>label.textContent=currency==='KHR'?'៛':'$');render()});
document.getElementById('clear-cart').addEventListener('click',()=>{cart.clear();render()});['discount','tax','cash-received'].forEach(id=>document.getElementById(id).addEventListener('input',calculate));
document.getElementById('submit-sale').addEventListener('click',()=>{if(!cart.size)return showError('សូមបន្ថែមផលិតផលមួយយ៉ាងហោចណាស់');if(confirm('បញ្ជាក់ការបញ្ចប់ការលក់នេះ?'))document.getElementById('sale-form').submit()});
document.getElementById('product-search').addEventListener('input',async e=>{const q=e.target.value.trim();const res=await fetch(`<?php echo e(route('sales.products.search')); ?>?q=${encodeURIComponent(q)}`,{headers:{'Accept':'application/json'}});if(!res.ok)return;const data=await res.json();const box=document.getElementById('search-results');box.replaceChildren();data.forEach(p=>{const b=document.createElement('button');b.type='button';b.className='min-h-12 rounded border bg-white p-2 text-left';b.textContent=`${p.name} · ${p.sku} · ${formatAmount(Number(p.selling_price),'USD')}`;b.onclick=()=>addProduct({id:p.id,name:p.name,sku:p.sku,barcode:p.barcode,price:p.selling_price,stock:Number(p.stock_quantity)});box.appendChild(b)})});
async function lookupBarcode(code){
    if(!code)return;
    const error=document.getElementById('cart-error');
    error.classList.add('hidden');
    try{
        const res=await fetch(`<?php echo e(route('sales.barcode.lookup')); ?>`,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json','X-CSRF-TOKEN':csrf},body:JSON.stringify({barcode:code})});
        const data=await res.json();
        if(!res.ok)return showError(data.message||'រកមិនឃើញ Barcode នេះទេ។');
        addProduct({id:data.id,name:data.name,sku:data.sku,barcode:data.barcode,price:data.selling_price,stock:Number(data.stock_quantity)});
        barcodeInput.value='';
    }catch{
        showError('មិនអាចស្វែងរក Barcode បានទេ។ សូមពិនិត្យការតភ្ជាប់ ហើយព្យាយាមម្ដងទៀត។');
    }
}
async function lookupQrProduct(code){
    try{
        const scannedUrl=new URL(code);
        const match=scannedUrl.origin===window.location.origin?scannedUrl.pathname.match(/\/products\/(\d+)\/?$/):null;
        if(!match)return lookupBarcode(code);
        const res=await fetch(`<?php echo e(route('sales.qr.lookup')); ?>`,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json','X-CSRF-TOKEN':csrf},body:JSON.stringify({product_id:Number(match[1])})});
        const data=await res.json();
        if(!res.ok)return showError(data.message||'មិនអាចស្វែងរកផលិតផលពី QR Code បានទេ។');
        addProduct({id:data.id,name:data.name,sku:data.sku,barcode:data.barcode,price:data.selling_price,stock:Number(data.stock_quantity)});
    }catch(error){
        if(error instanceof TypeError)return lookupBarcode(code);
        showError('មិនអាចស្វែងរកផលិតផលពី QR Code បានទេ។');
    }
}
document.getElementById('barcode-submit').addEventListener('click',()=>lookupBarcode(barcodeInput.value.trim()));
barcodeInput.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();lookupBarcode(barcodeInput.value.trim())}});

let scannerControls=null, scannerSession=0, scannerStarting=false, scanHandled=false;
const cameraButton=document.getElementById('camera-button');
const cameraStopButton=document.getElementById('camera-stop-button');
const cameraVideo=document.getElementById('camera-video');
const cameraPanel=document.getElementById('camera-panel');
function stopCamera(completed=false){
    scannerSession++;
    scannerStarting=false;
    scannerControls?.stop();
    scannerControls=null;
    cameraVideo.pause();
    cameraVideo.srcObject=null;
    cameraPanel.classList.add('hidden');
    cameraButton.classList.remove('hidden');
    cameraButton.textContent=completed?'ស្កេនផលិតផលបន្ទាប់':'ស្កេន Barcode តាមកាមេរ៉ា';
}
cameraStopButton.addEventListener('click',stopCamera);
cameraButton.addEventListener('click',async()=>{
    document.getElementById('cart-error').classList.add('hidden');
    if(scannerStarting||scannerControls)return;
    if(!window.isSecureContext)return showError('កាមេរ៉ាត្រូវការ HTTPS ឬ localhost។ អ្នកអាចបញ្ចូល Barcode ដោយដៃបាន។');
    if(!navigator.mediaDevices?.getUserMedia){
        return showError('កម្មវិធីរុករកនេះមិនគាំទ្រការប្រើកាមេរ៉ាទេ។ សូមប្រើ Google Chrome ជំនាន់ថ្មី ឬបញ្ចូល Barcode ដោយដៃ។');
    }
    if(!window.loadInventoryBarcodeReader){
        return showError('មិនអាចផ្ទុកកម្មវិធីស្កេនបានទេ។ សូមផ្ទុកទំព័រឡើងវិញ ឬបញ្ចូល Barcode ដោយដៃ។');
    }
    scannerStarting=true;
    scanHandled=false;
    const currentSession=++scannerSession;
    try{
        const BrowserMultiFormatReader=await window.loadInventoryBarcodeReader();
        const reader=new BrowserMultiFormatReader();
        const controls=await reader.decodeFromConstraints(
            {audio:false,video:{facingMode:{ideal:'environment'}}},
            cameraVideo,
            (result,error)=>{
                if(currentSession!==scannerSession||scanHandled)return;
                if(result){
                    const code=result.getText().trim();
                    if(!code)return;
                    scanHandled=true;
                    stopCamera(true);
                    if(result.getBarcodeFormat().toString()==='QR_CODE')lookupQrProduct(code);
                    else lookupBarcode(code);
                    return;
                }
                if(error&&!['NotFoundException','ChecksumException','FormatException'].includes(error.name)){
                    stopCamera();
                    showError('មានបញ្ហាក្នុងការអាន Barcode។ សូមព្យាយាមម្ដងទៀត ឬបញ្ចូល Barcode ដោយដៃ។');
                }
            },
        );
        if(currentSession!==scannerSession){
            controls.stop();
            return;
        }
        scannerControls=controls;
        scannerStarting=false;
        cameraPanel.classList.remove('hidden');
        cameraButton.classList.add('hidden');
    }catch(error){
        stopCamera();
        const message=['NotAllowedError','PermissionDeniedError','SecurityError'].includes(error.name)
            ? 'អ្នកមិនបានអនុញ្ញាតឱ្យប្រើកាមេរ៉ាទេ។ សូមអនុញ្ញាតសិទ្ធិកាមេរ៉ាសម្រាប់គេហទំព័រនេះក្នុង Chrome។'
            : error.name==='NotFoundError'
                ? 'រកមិនឃើញកាមេរ៉ានៅលើឧបករណ៍នេះទេ។'
                : ['NotReadableError','TrackStartError'].includes(error.name)
                    ? 'កាមេរ៉ាកំពុងប្រើដោយកម្មវិធីផ្សេង។ សូមបិទកម្មវិធីនោះ រួចព្យាយាមម្ដងទៀត។'
                    : error.name==='OverconstrainedError'
                        ? 'មិនអាចរកកាមេរ៉ាខាងក្រោយបានទេ។ សូមពិនិត្យកាមេរ៉ារបស់ឧបករណ៍។'
                        : 'មិនអាចចាប់ផ្តើមកាមេរ៉ាបានទេ។ សូមពិនិត្យសិទ្ធិកាមេរ៉ា និង HTTPS រួចព្យាយាមម្ដងទៀត។';
        showError(message);
    }
});
window.addEventListener('pagehide',stopCamera);
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopCamera()});
render();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/sales/create.blade.php ENDPATH**/ ?>