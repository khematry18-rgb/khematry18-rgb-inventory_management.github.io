
<?php $__env->startSection('title', 'កំណត់ហេតុសកម្មភាព'); ?>
<?php $__env->startSection('content'); ?>
<?php
    $moduleLabels = ['auth' => 'ការផ្ទៀងផ្ទាត់', 'users' => 'អ្នកប្រើប្រាស់', 'products' => 'ផលិតផល', 'categories' => 'ប្រភេទផលិតផល', 'suppliers' => 'អ្នកផ្គត់ផ្គង់', 'stock' => 'ស្តុក', 'purchases' => 'ការទិញ', 'sales' => 'ការលក់', 'payments' => 'ការទូទាត់', 'settings' => 'ការកំណត់'];
    $actionLabels = ['login' => 'ចូលប្រើប្រព័ន្ធ', 'logout' => 'ចាកចេញពីប្រព័ន្ធ', 'created' => 'បង្កើត', 'updated' => 'កែប្រែ', 'deleted' => 'លុប', 'stock.in' => 'បញ្ចូលស្តុក', 'stock.out' => 'ដកស្តុក', 'stock.adjustment' => 'កែតម្រូវស្តុក', 'purchase.received' => 'ទទួលការទិញ', 'purchase.cancelled' => 'លុបចោលការទិញ', 'sale.cancelled' => 'លុបចោលការលក់', 'payment.recorded' => 'កត់ត្រាការទូទាត់'];
?>
<div>
    <h1 class="text-2xl font-bold">កំណត់ហេតុសកម្មភាព</h1>
    <p class="mt-1 text-sm text-slate-500">កំណត់ត្រាសវនកម្មសម្រាប់សកម្មភាពសំខាន់ៗ។ មិនអាចកែប្រែ ឬលុបបានទេ។</p>
</div>
<form method="GET" class="mt-5 grid gap-3 rounded-xl bg-white p-4 shadow-sm md:grid-cols-4">
    <input type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="ស្វែងរកក្នុងការពិពណ៌នា" class="rounded-lg border-slate-300">
    <select name="user_id" class="rounded-lg border-slate-300">
        <option value="">-- អ្នកប្រើប្រាស់ --</option>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->id); ?>" <?php if((string) request('user_id') === (string) $user->id): echo 'selected'; endif; ?>><?php echo e($user->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="module" class="rounded-lg border-slate-300">
        <option value="">-- ម៉ូឌុល --</option>
        <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($module); ?>" <?php if(request('module') === $module): echo 'selected'; endif; ?>><?php echo e($moduleLabels[$module] ?? $module); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="action" class="rounded-lg border-slate-300">
        <option value="">-- សកម្មភាព --</option>
        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($action); ?>" <?php if(request('action') === $action): echo 'selected'; endif; ?>><?php echo e($actionLabels[$action] ?? $action); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <input type="date" name="from_date" value="<?php echo e(request('from_date')); ?>" class="rounded-lg border-slate-300">
    <input type="date" name="to_date" value="<?php echo e(request('to_date')); ?>" class="rounded-lg border-slate-300">
    <select name="per_page" class="rounded-lg border-slate-300">
        <?php $__currentLoopData = [10, 25, 50]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($size); ?>" <?php if((int) request('per_page', 10) === $size): echo 'selected'; endif; ?>><?php echo e($size); ?> ជួរ</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <div class="flex gap-2 md:col-span-4 md:justify-end">
        <button class="rounded-lg bg-slate-700 px-4 py-2 text-white">ស្វែងរក</button>
        <a href="<?php echo e(route('activity-logs.index')); ?>" class="rounded-lg border px-4 py-2">សម្អាត</a>
    </div>
</form>
<div class="mt-5 overflow-x-auto rounded-xl bg-white shadow-sm">
    <table class="min-w-full divide-y">
        <thead class="bg-slate-50"><tr>
            <th class="px-3 py-3 text-left text-sm">កាលបរិច្ឆេទ</th>
            <th class="px-3 py-3 text-left text-sm">អ្នកប្រើប្រាស់</th>
            <th class="px-3 py-3 text-left text-sm">សកម្មភាព</th>
            <th class="px-3 py-3 text-left text-sm">ម៉ូឌុល</th>
            <th class="px-3 py-3 text-left text-sm">ការពិពណ៌នា</th>
            <th class="px-3 py-3 text-left text-sm">IP</th>
            <th class="px-3 py-3 text-right text-sm">ព័ត៌មាន</th>
        </tr></thead>
        <tbody class="divide-y">
            <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="whitespace-nowrap px-3 py-3 text-sm"><?php echo e(app(\App\Services\SystemSettingsService::class)->formatDate($log->created_at, true)); ?></td>
                    <td class="px-3 py-3 text-sm"><?php echo e($log->user?->name ?? 'ប្រព័ន្ធ / គណនីត្រូវបានលុប'); ?></td>
                    <td class="px-3 py-3 text-sm"><?php echo e($log->actionLabel()); ?></td>
                    <td class="px-3 py-3 text-sm"><?php echo e($log->moduleLabel()); ?></td>
                    <td class="max-w-md px-3 py-3 text-sm"><?php echo e($log->description); ?></td>
                    <td class="px-3 py-3 text-sm"><?php echo e($log->ip_address ?? '-'); ?></td>
                    <td class="px-3 py-3 text-right"><a href="<?php echo e(route('activity-logs.show', $log)); ?>" class="text-blue-700">មើល</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="px-3 py-10 text-center text-slate-500">មិនមានកំណត់ហេតុសកម្មភាពទេ។</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="mt-4"><?php echo e($logs->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/activity-logs/index.blade.php ENDPATH**/ ?>