
<?php $__env->startSection('title', 'កែតម្រូវស្តុក'); ?>
<?php $__env->startSection('content'); ?>
<div><h1 class="text-2xl font-bold">កែតម្រូវស្តុក</h1><p class="mt-1 text-sm text-slate-500">កំណត់ស្តុកតាមបរិមាណពិត</p></div>
<?php echo $__env->make('stock._transaction_form', ['mode' => 'adjustment', 'action' => route('stock.adjustment.store'), 'confirmText' => 'តើអ្នកពិតជាចង់កែតម្រូវស្តុកមែនទេ?'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/stock/adjustment.blade.php ENDPATH**/ ?>