
<?php $__env->startSection('title', 'ចូលប្រើប្រាស់'); ?>
<?php $__env->startSection('content'); ?>
<div class="min-h-screen flex items-center justify-center px-4 py-10 bg-gradient-to-br from-slate-900 to-blue-900">
    <div class="w-full max-w-md rounded-2xl bg-white p-7 shadow-2xl">
        <h1 class="text-2xl font-bold text-center text-slate-900">ប្រព័ន្ធគ្រប់គ្រងសារពើភ័ណ្ឌ</h1>
        <p class="mt-2 mb-6 text-center text-sm text-slate-500">សូមចូលប្រើប្រាស់គណនីរបស់អ្នក</p>
        <?php if($errors->any()): ?>
            <div class="mb-4 rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('login')); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>
            <div>
                <label class="mb-1 block text-sm font-medium">អ៊ីមែល</label>
                <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus class="w-full rounded-lg border-slate-300 focus:border-blue-500 focus:ring-blue-500">
            </div>
            <div>
                <label class="mb-1 block text-sm font-medium">លេខសម្ងាត់</label>
                <input type="password" name="password" required class="w-full rounded-lg border-slate-300 focus:border-blue-500 focus:ring-blue-500">
            </div>
            <label class="flex items-center gap-2 text-sm">
                <input type="checkbox" name="remember" value="1" class="rounded border-slate-300">
                ចងចាំការចូលប្រើ
            </label>
            <button class="w-full rounded-lg bg-blue-700 px-4 py-3 font-semibold text-white hover:bg-blue-800">ចូលប្រើប្រាស់</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/auth/login.blade.php ENDPATH**/ ?>