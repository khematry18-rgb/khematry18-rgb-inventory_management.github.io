
<?php $__env->startSection('title', 'បញ្ចូលស្តុក'); ?>
<?php $__env->startSection('content'); ?>
<div><h1 class="text-2xl font-bold">បញ្ចូលស្តុក</h1><p class="mt-1 text-sm text-slate-500">បន្ថែមបរិមាណស្តុកទៅផលិតផល</p></div>
<?php echo $__env->make('stock._transaction_form', ['mode' => 'in', 'action' => route('stock.in.store'), 'confirmText' => 'តើអ្នកពិតជាចង់បញ្ចូលស្តុកមែនទេ?'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/stock/in.blade.php ENDPATH**/ ?>