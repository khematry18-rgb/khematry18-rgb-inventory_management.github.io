
<?php $__env->startSection('title', 'កែសម្រួលតួនាទី'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold">កែសម្រួលតួនាទី: <?php echo e($role->name); ?></h1>
<form method="POST" action="<?php echo e(route('roles.update', $role)); ?>" class="mt-5 max-w-4xl rounded-xl bg-white p-5 shadow-sm">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <div class="grid gap-4 md:grid-cols-2">
        <div><label class="mb-1 block text-sm">ឈ្មោះតួនាទី</label><input name="name" required value="<?php echo e(old('name', $role->name)); ?>" class="w-full rounded-lg border-slate-300"></div>
        <div><label class="mb-1 block text-sm">ស្ថានភាព</label><select name="is_active" class="w-full rounded-lg border-slate-300"><option value="1" <?php if(old('is_active', $role->is_active) == 1): echo 'selected'; endif; ?>>សកម្ម</option><option value="0" <?php if(old('is_active', $role->is_active) == 0): echo 'selected'; endif; ?>>អសកម្ម</option></select></div>
        <div class="md:col-span-2"><label class="mb-1 block text-sm">ការពិពណ៌នា</label><textarea name="description" rows="3" class="w-full rounded-lg border-slate-300"><?php echo e(old('description', $role->description)); ?></textarea></div>
    </div>
    <fieldset class="mt-6">
        <legend class="font-semibold">សិទ្ធិប្រើប្រាស់</legend>
        <div class="mt-3 grid gap-5 md:grid-cols-2">
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="rounded-lg border p-4">
                <h2 class="mb-2 font-medium capitalize"><?php echo e($group ?: 'ផ្សេងៗ'); ?></h2>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="mb-2 flex items-center gap-2 text-sm">
                        <input type="checkbox" name="permissions[]" value="<?php echo e($permission->id); ?>" <?php if($role->permissions->contains($permission->id)): echo 'checked'; endif; ?> class="rounded border-slate-300">
                        <?php echo e($permission->name); ?>

                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </fieldset>
    <div class="mt-6 flex gap-3"><button class="rounded-lg bg-blue-700 px-4 py-2 text-white">រក្សាទុក</button><a href="<?php echo e(route('roles.index')); ?>" class="rounded-lg border px-4 py-2">បោះបង់</a></div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/roles/edit.blade.php ENDPATH**/ ?>