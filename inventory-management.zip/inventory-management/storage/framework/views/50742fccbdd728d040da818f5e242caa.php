<?php ($submissionKey = old('submission_key', (string) \Illuminate\Support\Str::uuid())); ?>
<form method="POST" action="<?php echo e($action); ?>" onsubmit="return confirm('<?php echo e($confirmText); ?>')" class="mt-5 max-w-4xl rounded-xl bg-white p-5 shadow-sm">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="submission_key" value="<?php echo e($submissionKey); ?>">

    <div class="grid gap-4 md:grid-cols-2">
        <div class="md:col-span-2">
            <label for="product_id" class="mb-1 block text-sm font-medium">ផលិតផល <span class="text-red-600">*</span></label>
            <select id="product_id" name="product_id" required class="w-full rounded-lg border-slate-300">
                <option value="">-- ជ្រើសរើសផលិតផល --</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->id); ?>" data-quantity="<?php echo e($product->stock_quantity); ?>" data-unit="<?php echo e($product->unit); ?>" <?php if((string) old('product_id') === (string) $product->id): echo 'selected'; endif; ?>>
                        <?php echo e($product->name); ?> (SKU: <?php echo e($product->sku); ?>)
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <p class="mt-2 text-sm text-slate-500">បរិមាណបច្ចុប្បន្ន: <strong id="current-quantity">—</strong></p>
        </div>

        <?php if($mode === 'adjustment'): ?>
            <div>
                <label for="actual_quantity" class="mb-1 block text-sm font-medium">បរិមាណស្តុកពិតប្រាកដ <span class="text-red-600">*</span></label>
                <input id="actual_quantity" name="actual_quantity" type="number" step="0.001" min="0" required value="<?php echo e(old('actual_quantity')); ?>" class="w-full rounded-lg border-slate-300">
                <?php $__errorArgs = ['actual_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        <?php else: ?>
            <div>
                <label for="quantity" class="mb-1 block text-sm font-medium">បរិមាណ <span class="text-red-600">*</span></label>
                <input id="quantity" name="quantity" type="number" step="0.001" min="0.001" required value="<?php echo e(old('quantity')); ?>" class="w-full rounded-lg border-slate-300">
                <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        <?php endif; ?>

        <?php if($mode === 'in'): ?>
            <div>
                <label for="unit_cost" class="mb-1 block text-sm font-medium">តម្លៃឯកតា (USD)</label>
                <input id="unit_cost" name="unit_cost" type="number" step="0.01" min="0" value="<?php echo e(old('unit_cost')); ?>" class="w-full rounded-lg border-slate-300">
            </div>
        <?php endif; ?>

        <div>
            <label for="reference_number" class="mb-1 block text-sm font-medium">លេខយោង</label>
            <input id="reference_number" name="reference_number" maxlength="255" value="<?php echo e(old('reference_number')); ?>" class="w-full rounded-lg border-slate-300">
        </div>
        <div>
            <label for="transaction_date" class="mb-1 block text-sm font-medium">កាលបរិច្ឆេទប្រតិបត្តិការ <span class="text-red-600">*</span></label>
            <input id="transaction_date" name="transaction_date" type="datetime-local" required value="<?php echo e(old('transaction_date', now()->format('Y-m-d\TH:i'))); ?>" class="w-full rounded-lg border-slate-300">
            <?php $__errorArgs = ['transaction_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <?php if($mode !== 'in'): ?>
            <div class="md:col-span-2">
                <label for="reason" class="mb-1 block text-sm font-medium"><?php echo e($mode === 'out' ? 'មូលហេតុដកស្តុក' : 'មូលហេតុកែតម្រូវ'); ?> <span class="text-red-600">*</span></label>
                <input id="reason" name="reason" maxlength="255" required value="<?php echo e(old('reason')); ?>" class="w-full rounded-lg border-slate-300">
                <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        <?php else: ?>
            <div class="md:col-span-2">
                <label for="reason" class="mb-1 block text-sm font-medium">មូលហេតុ</label>
                <input id="reason" name="reason" maxlength="255" value="<?php echo e(old('reason')); ?>" class="w-full rounded-lg border-slate-300">
            </div>
        <?php endif; ?>

        <div class="md:col-span-2">
            <label for="notes" class="mb-1 block text-sm font-medium">កំណត់ចំណាំ</label>
            <textarea id="notes" name="notes" rows="4" maxlength="5000" class="w-full rounded-lg border-slate-300"><?php echo e(old('notes')); ?></textarea>
        </div>
    </div>
    <div class="mt-6 flex flex-wrap gap-3">
        <button type="submit" class="rounded-lg bg-blue-700 px-4 py-2 text-white">រក្សាទុកប្រតិបត្តិការ</button>
        <a href="<?php echo e(route('stock.index')); ?>" class="rounded-lg border border-slate-300 px-4 py-2 text-slate-700">បោះបង់</a>
    </div>
</form>
<script>
document.getElementById('product_id')?.addEventListener('change', function () {
    const option = this.options[this.selectedIndex];
    document.getElementById('current-quantity').textContent = option.value
        ? Number(option.dataset.quantity).toFixed(3) + ' ' + (option.dataset.unit || '')
        : '—';
});
</script>
<?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/stock/_transaction_form.blade.php ENDPATH**/ ?>