
<?php $__env->startSection('title', 'បង្កើតការទិញ'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold">បង្កើតការទិញ</h1>
<?php echo $__env->make('purchases._form', ['action'=>route('purchases.store'),'method'=>'POST','purchase'=>null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/purchases/create.blade.php ENDPATH**/ ?>