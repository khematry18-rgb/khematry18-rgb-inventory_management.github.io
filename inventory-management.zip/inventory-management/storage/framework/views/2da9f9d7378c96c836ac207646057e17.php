
<?php $__env->startSection('title', 'ការកំណត់ប្រព័ន្ធ'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-5">
    <h1 class="text-2xl font-bold">ការកំណត់ប្រព័ន្ធ</h1>
    <p class="mt-1 text-sm text-slate-500">កំណត់ព័ត៌មានហាង រូបិយប័ណ្ណ ស្តុក ការលក់ និងការទិញ។ ការកំណត់អនុវត្តចំពោះប្រតិបត្តិការថ្មីប៉ុណ្ណោះ។</p>
</div>
<form method="POST" action="<?php echo e(route('settings.update')); ?>" enctype="multipart/form-data" class="space-y-5">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <section class="rounded-xl bg-white p-5 shadow-sm">
        <h2 class="mb-4 text-lg font-semibold">១. ការកំណត់ហាងទូទៅ</h2>
        <div class="grid gap-4 md:grid-cols-2">
            <label class="block text-sm">ឈ្មោះហាង<input name="store_name" value="<?php echo e(old('store_name', $settings['store_name'])); ?>" maxlength="255" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">ឈ្មោះប្រព័ន្ធ<input name="system_name" required value="<?php echo e(old('system_name', $settings['system_name'])); ?>" maxlength="255" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm md:col-span-2">អាសយដ្ឋាន<textarea name="store_address" rows="2" maxlength="1000" class="mt-1 w-full rounded-lg border-slate-300"><?php echo e(old('store_address', $settings['store_address'])); ?></textarea></label>
            <label class="block text-sm">លេខទូរសព្ទ<input name="phone_number" value="<?php echo e(old('phone_number', $settings['phone_number'])); ?>" maxlength="40" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">អ៊ីមែល<input name="email" type="email" value="<?php echo e(old('email', $settings['email'])); ?>" maxlength="255" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">គេហទំព័រ<input name="website" type="url" value="<?php echo e(old('website', $settings['website'])); ?>" maxlength="255" placeholder="https://" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">ភាសាលំនាំដើម<select name="default_language" class="mt-1 w-full rounded-lg border-slate-300"><option value="km" selected>ខ្មែរ</option></select></label>
            <label class="block text-sm">តំបន់ម៉ោង<select name="timezone" required class="mt-1 w-full rounded-lg border-slate-300"><?php $__currentLoopData = $timezones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timezone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($timezone); ?>" <?php if(old('timezone', $settings['timezone']) === $timezone): echo 'selected'; endif; ?>><?php echo e($timezone); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
            <label class="block text-sm">ទម្រង់កាលបរិច្ឆេទ<select name="date_format" class="mt-1 w-full rounded-lg border-slate-300"><?php $__currentLoopData = ['d/m/Y', 'Y-m-d', 'd-m-Y']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $format): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($format); ?>" <?php if(old('date_format', $settings['date_format']) === $format): echo 'selected'; endif; ?>><?php echo e($format); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
            <label class="block text-sm">ទម្រង់ម៉ោង<select name="time_format" class="mt-1 w-full rounded-lg border-slate-300"><?php $__currentLoopData = ['H:i', 'h:i A', 'H:i:s']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $format): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($format); ?>" <?php if(old('time_format', $settings['time_format']) === $format): echo 'selected'; endif; ?>><?php echo e(now()->format($format)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
        </div>
    </section>

    <section class="rounded-xl bg-white p-5 shadow-sm">
        <h2 class="mb-4 text-lg font-semibold">២. រូបិយប័ណ្ណ និងទម្រង់លេខ</h2>
        <p class="mb-3 text-sm text-slate-500">តម្លៃផលិតផលគោលជា USD។ រូបិយប័ណ្ណ និងអត្រាប្តូរត្រូវបានរក្សាទុកជាមួយប្រតិបត្តិការថ្មី ដោយមិនកែប្រែប្រវត្តិចាស់។ 1 USD = អត្រា KHR ដែលកំណត់ខាងក្រោម។</p>
        <div class="grid gap-4 md:grid-cols-2">
            <label class="block text-sm">រូបិយប័ណ្ណលំនាំដើម<select name="currency_code" id="currency-code" class="mt-1 w-full rounded-lg border-slate-300"><option value="USD" <?php if(old('currency_code', $settings['currency_code']) === 'USD'): echo 'selected'; endif; ?>>USD ($)</option><option value="KHR" <?php if(old('currency_code', $settings['currency_code']) === 'KHR'): echo 'selected'; endif; ?>>KHR (៛)</option></select></label>
            <label class="block text-sm">និមិត្តសញ្ញារូបិយប័ណ្ណ<input id="currency-symbol" value="<?php echo e(old('currency_code', $settings['currency_code']) === 'KHR' ? '៛' : '$'); ?>" readonly class="mt-1 w-full rounded-lg border-slate-300 bg-slate-50"></label>
            <label class="block text-sm">អត្រាប្តូរ USD → KHR<input name="exchange_rate" type="number" step="0.0001" min="0.0001" value="<?php echo e(old('exchange_rate', $settings['exchange_rate'])); ?>" class="mt-1 w-full rounded-lg border-slate-300"><span class="text-xs text-slate-500">ត្រូវបំពេញពេលរូបិយប័ណ្ណលំនាំដើមជា KHR។</span></label>
            <label class="block text-sm">សញ្ញាទសភាគ<input name="decimal_separator" maxlength="1" required value="<?php echo e(old('decimal_separator', $settings['decimal_separator'])); ?>" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">សញ្ញាបំបែកខ្ទង់ពាន់<input name="thousands_separator" maxlength="1" required value="<?php echo e(old('thousands_separator', $settings['thousands_separator'])); ?>" class="mt-1 w-full rounded-lg border-slate-300"></label>
        </div>
    </section>

    <section class="rounded-xl bg-white p-5 shadow-sm">
        <h2 class="mb-4 text-lg font-semibold">៣. ការកំណត់សារពើភ័ណ្ឌ</h2>
        <div class="grid gap-4 md:grid-cols-2">
            <label class="block text-sm">ស្តុកអប្បបរមាលំនាំដើម<input name="default_minimum_stock" type="number" step="0.001" min="0" required value="<?php echo e(old('default_minimum_stock', $settings['default_minimum_stock'])); ?>" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">ឯកតាផលិតផលលំនាំដើម<input name="default_product_unit" required maxlength="30" value="<?php echo e(old('default_product_unit', $settings['default_product_unit'])); ?>" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">បុព្វបទ SKU<input name="sku_prefix" required maxlength="20" value="<?php echo e(old('sku_prefix', $settings['sku_prefix'])); ?>" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <?php $__currentLoopData = ['allow_negative_stock' => 'អនុញ្ញាតស្តុកអវិជ្ជមាន', 'low_stock_alert' => 'ជូនដំណឹងស្តុកជិតអស់', 'out_of_stock_alert' => 'ជូនដំណឹងអស់ស្តុក', 'auto_generate_sku' => 'បង្កើត SKU ដោយស្វ័យប្រវត្តិពេលទុកទទេ', 'auto_generate_barcode' => 'បង្កើត Barcode ដោយស្វ័យប្រវត្តិ']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="flex items-center gap-2 text-sm"><input type="hidden" name="<?php echo e($field); ?>" value="0"><input type="checkbox" name="<?php echo e($field); ?>" value="1" <?php if(old($field, $settings[$field])): echo 'checked'; endif; ?> class="rounded border-slate-300"> <?php echo e($label); ?></label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <section class="rounded-xl bg-white p-5 shadow-sm">
        <h2 class="mb-4 text-lg font-semibold">៤. ការលក់ និង POS</h2>
        <div class="grid gap-4 md:grid-cols-2">
            <label class="block text-sm">បុព្វបទវិក្កយបត្រ<input name="invoice_prefix" required maxlength="20" value="<?php echo e(old('invoice_prefix', $settings['invoice_prefix'])); ?>" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">លេខរៀងវិក្កយបត្រ<select name="invoice_numbering" class="mt-1 w-full rounded-lg border-slate-300"><option value="date_random" <?php if(old('invoice_numbering', $settings['invoice_numbering']) === 'date_random'): echo 'selected'; endif; ?>>កាលបរិច្ឆេទ និងលេខចៃដន្យ</option><option value="sequential" <?php if(old('invoice_numbering', $settings['invoice_numbering']) === 'sequential'): echo 'selected'; endif; ?>>លេខរៀងតាមថ្ងៃ</option></select></label>
            <label class="block text-sm">អតិថិជនលំនាំដើម<input name="default_customer" required maxlength="255" value="<?php echo e(old('default_customer', $settings['default_customer'])); ?>" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">អត្រាពន្ធ (%)<input name="tax_rate" type="number" min="0" max="100" step="0.01" required value="<?php echo e(old('tax_rate', $settings['tax_rate'])); ?>" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">ទំហំក្រដាសបង្កាន់ដៃ<select name="receipt_paper_size" class="mt-1 w-full rounded-lg border-slate-300"><?php $__currentLoopData = ['58mm', '80mm', 'A4']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($size); ?>" <?php if(old('receipt_paper_size', $settings['receipt_paper_size']) === $size): echo 'selected'; endif; ?>><?php echo e($size); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
            <?php $__currentLoopData = ['tax_enabled' => 'បើកពន្ធលើការលក់', 'discounts_allowed' => 'អនុញ្ញាតការបញ្ចុះតម្លៃ', 'print_receipt_automatically' => 'បោះពុម្ពបង្កាន់ដៃដោយស្វ័យប្រវត្តិ']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="flex items-center gap-2 text-sm"><input type="hidden" name="<?php echo e($field); ?>" value="0"><input type="checkbox" name="<?php echo e($field); ?>" value="1" <?php if(old($field, $settings[$field])): echo 'checked'; endif; ?> class="rounded border-slate-300"> <?php echo e($label); ?></label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <label class="block text-sm md:col-span-2">សារបាតកថាបង្កាន់ដៃ<textarea name="receipt_footer" rows="2" maxlength="1000" class="mt-1 w-full rounded-lg border-slate-300"><?php echo e(old('receipt_footer', $settings['receipt_footer'])); ?></textarea></label>
        </div>
    </section>

    <section class="rounded-xl bg-white p-5 shadow-sm">
        <h2 class="mb-4 text-lg font-semibold">៥. ការកំណត់ការទិញ</h2>
        <div class="grid gap-4 md:grid-cols-2">
            <label class="block text-sm">បុព្វបទបញ្ជាទិញ<input name="purchase_order_prefix" required maxlength="20" value="<?php echo e(old('purchase_order_prefix', $settings['purchase_order_prefix'])); ?>" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">លេខរៀងបញ្ជាទិញ<select name="purchase_order_numbering" class="mt-1 w-full rounded-lg border-slate-300"><option value="date_random" <?php if(old('purchase_order_numbering', $settings['purchase_order_numbering']) === 'date_random'): echo 'selected'; endif; ?>>កាលបរិច្ឆេទ និងលេខចៃដន្យ</option><option value="sequential" <?php if(old('purchase_order_numbering', $settings['purchase_order_numbering']) === 'sequential'): echo 'selected'; endif; ?>>លេខរៀងតាមថ្ងៃ</option></select></label>
            <label class="block text-sm">ស្ថានភាពបញ្ជាទិញលំនាំដើម<select name="default_purchase_status" class="mt-1 w-full rounded-lg border-slate-300"><option value="draft" <?php if(old('default_purchase_status', $settings['default_purchase_status']) === 'draft'): echo 'selected'; endif; ?>>សេចក្តីព្រាង</option><option value="pending" <?php if(old('default_purchase_status', $settings['default_purchase_status']) === 'pending'): echo 'selected'; endif; ?>>កំពុងរង់ចាំ</option></select></label>
            <label class="block text-sm">ទំហំក្រដាសបញ្ជាទិញ<select name="purchase_receipt_paper_size" class="mt-1 w-full rounded-lg border-slate-300"><option value="A4" <?php if(old('purchase_receipt_paper_size', $settings['purchase_receipt_paper_size']) === 'A4'): echo 'selected'; endif; ?>>A4</option><option value="80mm" <?php if(old('purchase_receipt_paper_size', $settings['purchase_receipt_paper_size']) === '80mm'): echo 'selected'; endif; ?>>80mm</option></select></label>
        </div>
    </section>

    <section class="rounded-xl bg-white p-5 shadow-sm">
        <h2 class="mb-4 text-lg font-semibold">៦. រូបសញ្ញា និងម៉ាកហាង</h2>
        <div class="grid gap-4 md:grid-cols-2">
            <div>
                <label for="store-logo" class="block text-sm">រូបសញ្ញាហាង (JPG, PNG, WEBP; អតិបរមា 2MB)</label>
                <input id="store-logo" name="store_logo" type="file" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" class="mt-1 block w-full text-sm">
                <img id="store-logo-preview" src="<?php echo e($settings['store_logo'] ? asset('storage/'.$settings['store_logo']) : ''); ?>" alt="រូបសញ្ញាហាង" class="<?php echo e($settings['store_logo'] ? 'mt-3 h-24 max-w-48 object-contain' : 'mt-3 hidden h-24 max-w-48 object-contain'); ?>">
                <?php if($settings['store_logo']): ?>
                    <button type="button" id="remove-logo" data-url="<?php echo e(route('settings.logo.destroy')); ?>" class="mt-3 rounded-lg border border-red-300 px-3 py-2 text-sm text-red-700">លុបរូបសញ្ញា</button>
                <?php endif; ?>
            </div>
            <div class="flex items-end"><button type="submit" class="rounded-lg bg-blue-700 px-5 py-3 font-semibold text-white hover:bg-blue-800">រក្សាទុកការកំណត់ទាំងអស់</button></div>
        </div>
    </section>
</form>
<script>
const logoInput=document.getElementById('store-logo'),logoPreview=document.getElementById('store-logo-preview');
logoInput?.addEventListener('change',()=>{const file=logoInput.files?.[0];if(file){logoPreview.src=URL.createObjectURL(file);logoPreview.classList.remove('hidden')}});
document.getElementById('currency-code')?.addEventListener('change',event=>{document.getElementById('currency-symbol').value=event.target.value==='KHR'?'៛':'$'});
document.getElementById('remove-logo')?.addEventListener('click',async event=>{if(!confirm('តើអ្នកប្រាកដថាចង់លុបរូបសញ្ញានេះឬ?'))return;const response=await fetch(event.currentTarget.dataset.url,{method:'DELETE',headers:{'X-CSRF-TOKEN':document.querySelector('meta[name="csrf-token"]').content,'Accept':'application/json'}});if(response.ok)location.reload();else alert('មិនអាចលុបរូបសញ្ញាបានទេ។ សូមព្យាយាមម្ដងទៀត។')});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/settings/edit.blade.php ENDPATH**/ ?>