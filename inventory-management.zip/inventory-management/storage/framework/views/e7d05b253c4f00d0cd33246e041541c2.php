
<?php $__env->startSection('title', 'ព័ត៌មានកំណត់ហេតុ'); ?>
<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-3xl">
    <a href="<?php echo e(route('activity-logs.index')); ?>" class="text-sm text-blue-700">← ត្រឡប់ទៅកំណត់ហេតុសកម្មភាព</a>
    <article class="mt-4 rounded-xl bg-white p-6 shadow-sm">
        <div class="flex flex-wrap items-start justify-between gap-3">
            <div>
                <h1 class="text-2xl font-bold">ព័ត៌មានសកម្មភាព</h1>
                <p class="mt-1 text-sm text-slate-500">កំណត់ត្រាប្រវត្តិសាស្ត្រ មិនអាចកែប្រែបាន។</p>
            </div>
            <span class="rounded-full bg-slate-100 px-3 py-1 text-sm"><?php echo e($activityLog->moduleLabel()); ?></span>
        </div>
        <dl class="mt-6 grid gap-5 border-t pt-5 sm:grid-cols-2">
            <div><dt class="text-xs text-slate-500">អ្នកប្រើប្រាស់</dt><dd class="mt-1"><?php echo e($activityLog->user?->name ?? 'ប្រព័ន្ធ / គណនីត្រូវបានលុប'); ?></dd></div>
            <div><dt class="text-xs text-slate-500">សកម្មភាព</dt><dd class="mt-1"><?php echo e($activityLog->actionLabel()); ?></dd></div>
            <div><dt class="text-xs text-slate-500">ម៉ូឌុល</dt><dd class="mt-1"><?php echo e($activityLog->moduleLabel()); ?></dd></div>
            <div><dt class="text-xs text-slate-500">កាលបរិច្ឆេទ</dt><dd class="mt-1"><?php echo e(app(\App\Services\SystemSettingsService::class)->formatDate($activityLog->created_at, true)); ?></dd></div>
            <div class="sm:col-span-2"><dt class="text-xs text-slate-500">ការពិពណ៌នា</dt><dd class="mt-1 whitespace-pre-line"><?php echo e($activityLog->description); ?></dd></div>
            <div><dt class="text-xs text-slate-500">អាសយដ្ឋាន IP</dt><dd class="mt-1"><?php echo e($activityLog->ip_address ?? '-'); ?></dd></div>
            <div><dt class="text-xs text-slate-500">កំណត់ត្រាយោង</dt><dd class="mt-1"><?php echo e($activityLog->subject_type ? class_basename($activityLog->subject_type) . ' #' . $activityLog->subject_id : '-'); ?></dd></div>
            <div class="sm:col-span-2"><dt class="text-xs text-slate-500">កម្មវិធីរុករក</dt><dd class="mt-1 break-all text-sm"><?php echo e($activityLog->user_agent ?? '-'); ?></dd></div>
        </dl>
    </article>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/activity-logs/show.blade.php ENDPATH**/ ?>