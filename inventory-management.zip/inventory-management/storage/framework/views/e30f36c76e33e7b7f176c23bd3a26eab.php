<form method="POST" action="<?php echo e($action); ?>" class="mt-5 rounded-xl bg-white p-5 shadow-sm">
    <?php echo csrf_field(); ?> <?php if($method !== 'POST'): ?> <?php echo method_field($method); ?> <?php endif; ?>
    <div class="grid gap-4 md:grid-cols-4">
        <div>
            <label class="mb-1 block text-sm font-medium">រូបិយប័ណ្ណបញ្ជាទិញ</label>
            <select id="purchase-currency" name="currency" required class="w-full rounded-lg border-slate-300">
                <option value="USD" <?php if(old('currency', $purchase?->currency ?? $settings['currency_code']) === 'USD'): echo 'selected'; endif; ?>>USD ($)</option>
                <option value="KHR" <?php if(old('currency', $purchase?->currency ?? $settings['currency_code']) === 'KHR'): echo 'selected'; endif; ?> <?php if(!$settings['exchange_rate']): echo 'disabled'; endif; ?>>KHR (៛)</option>
            </select>
        </div>
        <div class="md:col-span-2">
            <label class="mb-1 block text-sm font-medium">អ្នកផ្គត់ផ្គង់ <span class="text-red-600">*</span></label>
            <select name="supplier_id" required class="w-full rounded-lg border-slate-300">
                <option value="">-- ជ្រើសរើស --</option>
                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($supplier->id); ?>" <?php if((string) old('supplier_id', $purchase?->supplier_id) === (string) $supplier->id): echo 'selected'; endif; ?>><?php echo e($supplier->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label class="mb-1 block text-sm font-medium">ថ្ងៃទិញ <span class="text-red-600">*</span></label>
            <input type="datetime-local" name="purchased_at" required value="<?php echo e(old('purchased_at', optional($purchase?->purchased_at)->format('Y-m-d\TH:i') ?: now()->format('Y-m-d\TH:i'))); ?>" class="w-full rounded-lg border-slate-300">
        </div>
        <div>
            <label class="mb-1 block text-sm font-medium">ថ្ងៃដឹកជិតមក</label>
            <input type="datetime-local" name="expected_delivery_at" value="<?php echo e(old('expected_delivery_at', optional($purchase?->expected_delivery_at)->format('Y-m-d\TH:i'))); ?>" class="w-full rounded-lg border-slate-300">
        </div>
        <div>
            <label class="mb-1 block text-sm font-medium">លេខយោង</label>
            <input name="reference_number" maxlength="255" value="<?php echo e(old('reference_number', $purchase?->reference_number)); ?>" class="w-full rounded-lg border-slate-300">
        </div>
        <div>
            <label class="mb-1 block text-sm font-medium">ស្ថានភាព</label>
            <select name="status" required class="w-full rounded-lg border-slate-300">
                <option value="draft" <?php if(old('status', $purchase?->status ?? $settings['default_purchase_status']) === 'draft'): echo 'selected'; endif; ?>>សេចក្តីព្រាង</option>
                <option value="pending" <?php if(old('status', $purchase?->status ?? $settings['default_purchase_status']) === 'pending'): echo 'selected'; endif; ?>>កំពុងរង់ចាំ</option>
            </select>
        </div>
        <div class="md:col-span-2">
            <label class="mb-1 block text-sm font-medium">កំណត់ចំណាំ</label>
            <textarea name="notes" rows="2" class="w-full rounded-lg border-slate-300"><?php echo e(old('notes', $purchase?->notes)); ?></textarea>
        </div>
    </div>

    <div class="mt-6 overflow-x-auto">
        <table class="min-w-full">
            <thead><tr><th class="px-2 py-2 text-left">ផលិតផល</th><th class="px-2 py-2 text-left">SKU</th><th class="px-2 py-2 text-right">ស្តុកបច្ចុប្បន្ន</th><th class="px-2 py-2 text-right">បរិមាណ</th><th class="px-2 py-2 text-right">តម្លៃឯកតា <span class="currency-label"><?php echo e($purchase?->currency === 'KHR' ? 'KHR' : ($settings['currency_code'] === 'KHR' ? 'KHR' : 'USD')); ?></span></th><th class="px-2 py-2 text-right">សរុប</th><th></th></tr></thead>
            <tbody id="itemRows"></tbody>
        </table>
        <button type="button" id="addItem" class="mt-3 rounded-lg border border-blue-300 px-3 py-2 text-blue-700">+ បន្ថែមផលិតផល</button>
    </div>

    <div class="mt-6 grid gap-4 md:grid-cols-4">
        <div><label class="mb-1 block text-sm">សរុបរង</label><input id="subtotalDisplay" readonly value="$0.00" class="w-full rounded-lg border-slate-300 bg-slate-50"></div>
        <div><label class="mb-1 block text-sm">បញ្ចុះតម្លៃ <span class="currency-label"></span></label><input name="discount" id="discount" type="number" step="0.01" min="0" value="<?php echo e(old('discount', $purchase?->discount ?? 0)); ?>" class="w-full rounded-lg border-slate-300"></div>
        <div><label class="mb-1 block text-sm">ពន្ធ <span class="currency-label"></span></label><input name="tax" id="tax" type="number" step="0.01" min="0" value="<?php echo e(old('tax', $purchase?->tax ?? 0)); ?>" class="w-full rounded-lg border-slate-300"></div>
        <div><label class="mb-1 block text-sm">សរុបចុងក្រោយ</label><input id="grandTotalDisplay" readonly value="$0.00" class="w-full rounded-lg border-slate-300 bg-slate-50"></div>
    </div>
    <?php $__errorArgs = ['items'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="mt-6 flex gap-3"><button type="submit" class="rounded-lg bg-blue-700 px-4 py-2 text-white">រក្សាទុក</button><a href="<?php echo e(route('purchases.index')); ?>" class="rounded-lg border border-slate-300 px-4 py-2">បោះបង់</a></div>
</form>

<?php
    $purchaseProducts = $products->map(fn ($product) => [
        'id' => $product->id,
        'name' => $product->name,
        'sku' => $product->sku,
        'stock' => $product->stock_quantity,
        'unit' => $product->unit,
        'cost' => $product->cost_price,
    ])->values()->all();
    $purchaseOldItems = old('items', isset($purchase)
        ? $purchase->items->map(fn ($item) => [
            'product_id' => $item->product_id,
            'quantity' => $item->quantity,
            'unit_cost' => $item->unit_cost,
        ])->values()->all()
        : []);
?>
<script>
const products = <?php echo e(\Illuminate\Support\Js::from($purchaseProducts)); ?>;
const oldItems = <?php echo e(\Illuminate\Support\Js::from($purchaseOldItems)); ?>;
const rate=Number(<?php echo json_encode($settings['exchange_rate']??0, 15, 512) ?>),currencySelect=document.getElementById('purchase-currency'),decimalSeparator=<?php echo json_encode($settings['decimal_separator'], 15, 512) ?>,thousandsSeparator=<?php echo json_encode($settings['thousands_separator'], 15, 512) ?>;
let currency=currencySelect.value,baseRate=currency==='KHR'?Number(<?php echo json_encode($purchase?->exchange_rate ?? $settings['exchange_rate'] ?? 0, 15, 512) ?>):1;
let nextItemIndex=0;
function currentRate(){return currency==='KHR'?rate:1}
function formatCurrency(value){const digits=currency==='KHR'?0:2,numeric=Number(value).toLocaleString('en-US',{minimumFractionDigits:digits,maximumFractionDigits:digits}).replaceAll(',',thousandsSeparator).replaceAll('.',decimalSeparator);return currency==='KHR'?numeric+'៛':'$'+numeric}
function addRow(item = {}) {
    const rowIndex=nextItemIndex++;
    const row = document.createElement('tr');
    row.innerHTML = '<td class="px-2 py-2"><select required class="productSelect rounded-lg border-slate-300"></select></td><td class="px-2 py-2 sku text-xs text-slate-500">—</td><td class="px-2 py-2 stock text-right">—</td><td class="px-2 py-2"><input type="number" step="0.001" min="0.001" required class="quantity w-28 rounded-lg border-slate-300 text-right"></td><td class="px-2 py-2"><input type="number" step="0.01" min="0" required class="cost w-28 rounded-lg border-slate-300 text-right"></td><td class="px-2 py-2 lineTotal text-right"></td><td class="px-2 py-2"><button type="button" class="remove text-red-600">លុប</button></td>';
    const select = row.querySelector('.productSelect');
    select.name = `items[${rowIndex}][product_id]`;
    row.querySelector('.quantity').name = `items[${rowIndex}][quantity]`;
    row.querySelector('.cost').name = `items[${rowIndex}][unit_cost]`;
    const placeholder = document.createElement('option');
    placeholder.value = '';
    placeholder.textContent = '-- ជ្រើស --';
    select.append(placeholder);
    products.forEach(product => {
        const option = document.createElement('option');
        option.value = product.id;
        option.dataset.sku = product.sku;
        option.dataset.stock = product.stock;
        option.dataset.unit = product.unit;
        option.dataset.cost = product.cost;
        option.textContent = product.name;
        select.append(option);
    });
    if (item.product_id) select.value = item.product_id;
    row.querySelector('.quantity').value = item.quantity ?? 1;
    row.querySelector('.cost').value = item.unit_cost ?? 0;
    document.getElementById('itemRows').appendChild(row);
    updateRow(row);
}
function updateRow(row) {
    const select = row.querySelector('.productSelect');
    const option = select.options[select.selectedIndex];
    row.querySelector('.sku').textContent = option?.dataset.sku || '—';
    row.querySelector('.stock').textContent = option?.value ? Number(option.dataset.stock).toFixed(3) + ' ' + (option.dataset.unit || '') : '—';
    if (!row.querySelector('.cost').value || Number(row.querySelector('.cost').value) === 0) {
        if (option?.dataset.cost) row.querySelector('.cost').value = (Number(option.dataset.cost)*currentRate()).toFixed(2);
    }
    calculate();
}
function calculate() {
    let subtotal = 0;
    document.querySelectorAll('#itemRows tr').forEach(row => {
        const quantity = Number(row.querySelector('.quantity').value || 0);
        const cost = Number(row.querySelector('.cost').value || 0);
        const line = quantity * cost;
        row.querySelector('.lineTotal').textContent = formatCurrency(line);
        subtotal += line;
    });
    const discount = Number(document.getElementById('discount').value || 0);
    const tax = Number(document.getElementById('tax').value || 0);
    document.getElementById('subtotalDisplay').value = formatCurrency(subtotal);
    document.getElementById('grandTotalDisplay').value = formatCurrency(Math.max(0, subtotal - discount + tax));
}
currencySelect.addEventListener('change',()=>{const nextCurrency=currencySelect.value,nextRate=nextCurrency==='KHR'?rate:1,factor=baseRate>0?nextRate/baseRate:1;document.querySelectorAll('#itemRows .cost').forEach(input=>input.value=(Number(input.value||0)*factor).toFixed(2));baseRate=nextRate;document.querySelectorAll('.currency-label').forEach(label=>label.textContent=nextCurrency);currency=nextCurrency;calculate()});
document.getElementById('itemRows').addEventListener('change', e => { if (e.target.classList.contains('productSelect')) updateRow(e.target.closest('tr')); });
document.getElementById('itemRows').addEventListener('input', calculate);
document.getElementById('itemRows').addEventListener('click', e => { if (e.target.classList.contains('remove')) { e.target.closest('tr').remove(); calculate(); } });
document.getElementById('addItem').addEventListener('click', () => addRow());
document.getElementById('discount').addEventListener('input', calculate);
document.getElementById('tax').addEventListener('input', calculate);
(oldItems.length ? oldItems : [{}]).forEach(addRow);
</script>
<?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/purchases/_form.blade.php ENDPATH**/ ?>