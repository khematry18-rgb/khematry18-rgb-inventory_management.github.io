
<?php $__env->startSection('title', 'តួនាទី និងសិទ្ធិ'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold">តួនាទី និងសិទ្ធិ</h1>
<div class="mt-5 grid gap-4 md:grid-cols-3">
<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="rounded-xl bg-white p-5 shadow-sm">
        <div class="flex items-center justify-between">
            <h2 class="text-lg font-bold"><?php echo e($role->name); ?></h2>
            <span class="rounded-full px-2 py-1 text-xs <?php echo e($role->is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'); ?>"><?php echo e($role->is_active ? 'សកម្ម' : 'អសកម្ម'); ?></span>
        </div>
        <p class="mt-2 text-sm text-slate-500"><?php echo e($role->permissions_count); ?> សិទ្ធិ</p>
        <a href="<?php echo e(route('roles.edit', $role)); ?>" class="mt-4 inline-block rounded-lg border border-blue-700 px-3 py-2 text-sm text-blue-700 hover:bg-blue-50">កែសម្រួលសិទ្ធិ</a>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/roles/index.blade.php ENDPATH**/ ?>