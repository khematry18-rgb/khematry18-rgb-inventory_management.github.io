
<?php $__env->startSection('title', 'ប្រវត្តិស្តុក'); ?>
<?php $__env->startSection('content'); ?>
<div class="flex flex-wrap items-center justify-between gap-3">
    <div><h1 class="text-2xl font-bold">ប្រវត្តិចលនាស្តុក</h1><p class="mt-1 text-sm text-slate-500">ប្រតិបត្តិការចូល ដក និងកែតម្រូវស្តុក</p></div>
    <a href="<?php echo e(route('stock.index')); ?>" class="rounded-lg border border-slate-300 px-4 py-2">ត្រឡប់ស្តុក</a>
</div>

<form method="GET" class="mt-5 grid gap-3 rounded-xl bg-white p-4 shadow-sm md:grid-cols-6">
    <input type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="ឈ្មោះ ឬ SKU" class="rounded-lg border-slate-300 md:col-span-2">
    <select name="movement_type" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់ប្រភេទ --</option>
        <option value="stock_in" <?php if(request('movement_type') === 'stock_in'): echo 'selected'; endif; ?>>បញ្ចូលស្តុក</option>
        <option value="stock_out" <?php if(request('movement_type') === 'stock_out'): echo 'selected'; endif; ?>>ដកស្តុក</option>
        <option value="adjustment" <?php if(request('movement_type') === 'adjustment'): echo 'selected'; endif; ?>>កែតម្រូវស្តុក</option>
    </select>
    <select name="stock_status" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់ស្ថានភាព --</option>
        <option value="in_stock" <?php if(request('stock_status') === 'in_stock'): echo 'selected'; endif; ?>>មានស្តុក</option>
        <option value="low_stock" <?php if(request('stock_status') === 'low_stock'): echo 'selected'; endif; ?>>ស្តុកតិច</option>
        <option value="out_of_stock" <?php if(request('stock_status') === 'out_of_stock'): echo 'selected'; endif; ?>>អស់ស្តុក</option>
    </select>
    <select name="user_id" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់អ្នកប្រើប្រាស់ --</option>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->id); ?>" <?php if((string) request('user_id') === (string) $user->id): echo 'selected'; endif; ?>><?php echo e($user->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <input type="date" name="from_date" value="<?php echo e(request('from_date')); ?>" class="rounded-lg border-slate-300">
    <input type="date" name="to_date" value="<?php echo e(request('to_date')); ?>" class="rounded-lg border-slate-300">
    <select name="per_page" class="rounded-lg border-slate-300">
        <?php $__currentLoopData = [10,25,50]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($size); ?>" <?php if((int) request('per_page', 10) === $size): echo 'selected'; endif; ?>><?php echo e($size); ?> ជួរ</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <div class="flex gap-2 md:col-span-6 md:justify-end">
        <button type="submit" class="rounded-lg bg-slate-700 px-4 py-2 text-white">ស្វែងរក</button>
        <a href="<?php echo e(route('stock.history')); ?>" class="rounded-lg border border-slate-300 px-4 py-2">សម្អាត</a>
    </div>
</form>

<div class="mt-5 overflow-x-auto rounded-xl bg-white shadow-sm">
    <table class="min-w-full divide-y divide-slate-200">
        <thead class="bg-slate-50">
            <tr>
                <th class="px-3 py-3 text-left text-sm text-slate-600">លេខប្រតិបត្តិការ</th>
                <th class="px-3 py-3 text-left text-sm text-slate-600">ផលិតផល</th>
                <th class="px-3 py-3 text-left text-sm text-slate-600">ប្រភេទ</th>
                <th class="px-3 py-3 text-left text-sm text-slate-600">បរិមាណ</th>
                <th class="px-3 py-3 text-left text-sm text-slate-600">មុន → ក្រោយ</th>
                <th class="px-3 py-3 text-left text-sm text-slate-600">លេខយោង / មូលហេតុ</th>
                <th class="px-3 py-3 text-left text-sm text-slate-600">អ្នកធ្វើ</th>
                <th class="px-3 py-3 text-left text-sm text-slate-600">កាលបរិច្ឆេទ</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
        <?php $__empty_1 = true; $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $movementLabel = match($movement->movement_type) {
                    'stock_in' => ['បញ្ចូលស្តុក', 'bg-green-100 text-green-700'],
                    'stock_out' => ['ដកស្តុក', 'bg-red-100 text-red-700'],
                    'adjustment' => ['កែតម្រូវស្តុក', 'bg-blue-100 text-blue-700'],
                    default => [$movement->movement_type, 'bg-slate-100 text-slate-700'],
                };
            ?>
            <tr>
                <td class="px-3 py-3 font-mono text-xs">#<?php echo e($movement->id); ?></td>
                <td class="px-3 py-3"><div class="font-medium"><?php echo e($movement->product->name); ?></div><div class="font-mono text-xs text-slate-500">SKU: <?php echo e($movement->product->sku); ?></div></td>
                <td class="px-3 py-3"><span class="rounded-full px-2 py-1 text-xs <?php echo e($movementLabel[1]); ?>"><?php echo e($movementLabel[0]); ?></span></td>
                <td class="px-3 py-3"><?php echo e(number_format((float) $movement->quantity, 3)); ?></td>
                <td class="px-3 py-3"><?php echo e(number_format((float) $movement->stock_before, 3)); ?> → <?php echo e(number_format((float) $movement->stock_after, 3)); ?></td>
                <td class="px-3 py-3 text-sm"><div><?php echo e($movement->reference_number ?: '—'); ?></div><div class="text-slate-500"><?php echo e($movement->reason ?: $movement->notes ?: '—'); ?></div></td>
                <td class="px-3 py-3"><?php echo e($movement->user->name ?? '—'); ?></td>
                <td class="px-3 py-3 whitespace-nowrap"><?php echo e(app(\App\Services\SystemSettingsService::class)->formatDate($movement->transaction_date ?: $movement->created_at, true)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="8" class="px-3 py-8 text-center text-slate-500">មិនមានប្រវត្តិស្តុក</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="mt-4"><?php echo e($movements->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/stock/history.blade.php ENDPATH**/ ?>