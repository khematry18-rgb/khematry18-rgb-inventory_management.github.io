
<?php $__env->startSection('title', 'អ្នកប្រើប្រាស់'); ?>
<?php $__env->startSection('content'); ?>
<div class="flex flex-wrap items-center justify-between gap-3">
    <h1 class="text-2xl font-bold">បញ្ជីអ្នកប្រើប្រាស់</h1>
    <a href="<?php echo e(route('users.create')); ?>" class="rounded-lg bg-blue-700 px-4 py-2 text-white hover:bg-blue-800">បង្កើតអ្នកប្រើប្រាស់</a>
</div>
<form method="GET" class="mt-5 grid gap-3 rounded-xl bg-white p-4 shadow-sm md:grid-cols-4">
    <input type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="ស្វែងរកឈ្មោះ ឬអ៊ីមែល" class="rounded-lg border-slate-300 md:col-span-2">
    <select name="role_id" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់តួនាទី --</option>
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($role->id); ?>" <?php if(request('role_id') == $role->id): echo 'selected'; endif; ?>><?php echo e($role->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="is_active" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់ស្ថានភាព --</option>
        <option value="1" <?php if(request('is_active') === '1'): echo 'selected'; endif; ?>>សកម្ម</option>
        <option value="0" <?php if(request('is_active') === '0'): echo 'selected'; endif; ?>>អសកម្ម</option>
    </select>
    <button class="rounded-lg bg-slate-700 px-4 py-2 text-white md:col-start-4">ស្វែងរក</button>
</form>
<div class="mt-5 overflow-x-auto rounded-xl bg-white shadow-sm">
    <table class="min-w-full divide-y divide-slate-200">
        <thead class="bg-slate-50"><tr><th class="px-4 py-3 text-left">ឈ្មោះ</th><th class="px-4 py-3 text-left">អ៊ីមែល</th><th class="px-4 py-3 text-left">តួនាទី</th><th class="px-4 py-3 text-left">ស្ថានភាព</th><th class="px-4 py-3 text-right">សកម្មភាព</th></tr></thead>
        <tbody class="divide-y">
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="px-4 py-3"><a href="<?php echo e(route('users.show', $user)); ?>" class="font-medium text-blue-700"><?php echo e($user->name); ?></a></td>
                <td class="px-4 py-3"><?php echo e($user->email); ?></td>
                <td class="px-4 py-3"><?php echo e($user->role?->name ?? '—'); ?></td>
                <td class="px-4 py-3"><span class="rounded-full px-2 py-1 text-xs <?php echo e($user->is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'); ?>"><?php echo e($user->is_active ? 'សកម្ម' : 'អសកម្ម'); ?></span></td>
                <td class="px-4 py-3 text-right">
                    <a href="<?php echo e(route('users.edit', $user)); ?>" class="text-blue-700">កែសម្រួល</a>
                    <form method="POST" action="<?php echo e(route('users.destroy', $user)); ?>" class="inline" onsubmit="return confirm('តើអ្នកពិតជាចង់លុបអ្នកប្រើប្រាស់នេះមែនទេ?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="ml-3 text-red-700">លុប</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5" class="px-4 py-8 text-center text-slate-500">មិនមានទិន្នន័យ</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="mt-4"><?php echo e($users->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/users/index.blade.php ENDPATH**/ ?>