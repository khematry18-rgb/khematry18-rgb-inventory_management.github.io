
<?php $__env->startSection('title','ចំណេញ និងខាត'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('reports._filter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="mt-5 flex items-center justify-between"><h1 class="text-2xl font-bold">របាយការណ៍ចំណេញ និងខាត</h1><div class="flex gap-2"><a href="<?php echo e(route('reports.profit-loss.export', request()->query())); ?>" class="rounded-lg border px-4 py-2">Export CSV</a><button onclick="window.print()" class="rounded-lg bg-slate-700 px-4 py-2 text-white">បោះពុម្ព</button></div></div>
<?php $__empty_1 = true; $__currentLoopData = $profitLoss['by_currency']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency=>$totals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<h2 class="mt-5 text-lg font-semibold">រូបិយប័ណ្ណ <?php echo e($currency); ?></h2>
<div class="mt-3 grid gap-4 md:grid-cols-2 xl:grid-cols-4"><?php $__currentLoopData = [['ចំណូលលក់រង',$totals['revenue']],['ថ្លៃដើមទំនិញ',$totals['cogs']],['ចំណេញមូល',$totals['gross_profit']],['បញ្ចុះតម្លៃ',$totals['discounts']],['ពន្ធដែលបានប្រមូល',$totals['tax']]]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="rounded-xl bg-white p-5 shadow-sm"><div class="text-sm text-slate-500"><?php echo e($card[0]); ?></div><div class="mt-2 text-2xl font-bold"><?php echo e(app(\App\Services\SystemSettingsService::class)->formatAmount((float)$card[1], $currency)); ?></div></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><div class="rounded-xl bg-white p-5 shadow-sm"><div class="text-sm text-slate-500">ចំណេញសុទ្ធ</div><div class="mt-2 text-xl font-bold">មិនអាចគណនាបាន</div></div></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="mt-5 rounded-xl bg-white p-8 text-center text-slate-500">មិនមានទិន្នន័យលក់សម្រាប់គណនា។</div>
<?php endif; ?>
<div class="mt-5 rounded-xl border border-blue-200 bg-blue-50 p-5 text-blue-900"><strong>ការពន្យល់៖</strong> COGS គណនាពីតម្លៃដើមដែលបានរក្សាទុកនៅលើ Sale Item នៅពេលលក់។ ពន្ធដែលប្រមូលមិនត្រូវបានចាត់ទុកជាចំណូលអាជីវកម្ម។ ចំណេញសុទ្ធមិនអាចគណនាដោយស្មើរ ព្រោះប្រព័ន្ធមិនទាន់មានទិន្នន័យការចំណាយប្រតិបត្តិការសរុប។</div>
<?php if($profitLoss['unknown_cost_items']>0): ?><div class="mt-4 rounded-xl border border-yellow-200 bg-yellow-50 p-4 text-yellow-900">មាន <?php echo e($profitLoss['unknown_cost_items']); ?> Sale Item ដែលគ្មានតម្លៃដើមតាមប្រវត្តិ។ COGS អាចមិនពេញលេញសម្រាប់ប្រតិបត្តិការខ្លះ។</div><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/reports/profit-loss.blade.php ENDPATH**/ ?>