
<?php $__env->startSection('title', 'ការជូនដំណឹង'); ?>
<?php $__env->startSection('content'); ?>
<div class="flex flex-wrap items-center justify-between gap-3">
    <div>
        <h1 class="text-2xl font-bold">ការជូនដំណឹង</h1>
        <p class="mt-1 text-sm text-slate-500">មិនទាន់អាន <?php echo e(number_format($unreadCount)); ?> ការជូនដំណឹង</p>
    </div>
    <div class="flex gap-2">
        <?php if($unreadCount > 0): ?>
            <form method="POST" action="<?php echo e(route('notifications.read-all')); ?>">
                <?php echo csrf_field(); ?>
                <button class="rounded-lg border bg-white px-4 py-2 text-sm">សម្គាល់ទាំងអស់ថាបានអាន</button>
            </form>
        <?php endif; ?>
        <?php if($notifications->total() > 0): ?>
            <form method="POST" action="<?php echo e(route('notifications.clear')); ?>" onsubmit="return confirm('តើអ្នកប្រាកដថាចង់លុបការជូនដំណឹងទាំងអស់ឬ?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="rounded-lg border border-red-200 px-4 py-2 text-sm text-red-700">សម្អាតទាំងអស់</button>
            </form>
        <?php endif; ?>
    </div>
</div>
<div class="mt-5 space-y-3">
    <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="rounded-xl border bg-white p-4 shadow-sm <?php echo e($notification->read_at ? '' : 'border-l-4 border-l-blue-600'); ?>">
            <div class="flex flex-wrap items-start justify-between gap-3">
                <a href="<?php echo e(route('notifications.show', $notification->id)); ?>" class="min-w-0 flex-1">
                    <div class="flex flex-wrap items-center gap-2">
                        <h2 class="font-semibold"><?php echo e($notification->data['title'] ?? 'ការជូនដំណឹង'); ?></h2>
                        <span class="rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-600"><?php echo e(\App\Notifications\InventoryNotification::typeLabel($notification->data['event_type'] ?? 'system.alert')); ?></span>
                        <span class="rounded-full px-2 py-0.5 text-xs <?php echo e($notification->read_at ? 'bg-slate-100 text-slate-500' : 'bg-blue-100 text-blue-700'); ?>"><?php echo e($notification->read_at ? 'បានអាន' : 'មិនទាន់អាន'); ?></span>
                    </div>
                    <p class="mt-1 text-sm text-slate-600"><?php echo e($notification->data['message'] ?? ''); ?></p>
                    <time class="mt-2 block text-xs text-slate-400" datetime="<?php echo e($notification->created_at->toIso8601String()); ?>"><?php echo e(app(\App\Services\SystemSettingsService::class)->formatDate($notification->created_at, true)); ?> · <?php echo e($notification->created_at->diffForHumans()); ?></time>
                </a>
                <div class="flex items-center gap-2">
                    <?php if($notification->read_at): ?>
                        <form method="POST" action="<?php echo e(route('notifications.unread', $notification->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button class="text-xs text-blue-700">សម្គាល់មិនទាន់អាន</button>
                        </form>
                    <?php else: ?>
                        <form method="POST" action="<?php echo e(route('notifications.read', $notification->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button class="text-xs text-slate-600">សម្គាល់ថាបានអាន</button>
                        </form>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('notifications.destroy', $notification->id)); ?>" onsubmit="return confirm('លុបការជូនដំណឹងនេះ?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="text-xs text-red-700">លុប</button>
                    </form>
                </div>
            </div>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="rounded-xl border border-dashed bg-white px-6 py-12 text-center text-slate-500">មិនមានការជូនដំណឹងទេ។</div>
    <?php endif; ?>
</div>
<div class="mt-5"><?php echo e($notifications->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/notifications/index.blade.php ENDPATH**/ ?>