
<?php $__env->startSection('title', 'Barcode និង QR Code'); ?>
<?php $__env->startSection('content'); ?>
<div>
    <h1 class="text-2xl font-bold">Barcode និង QR Code</h1>
    <p class="mt-1 text-sm text-slate-500">ជ្រើសផលិតផលដែលមាន Barcode ដើម្បីមើលជាមុន និងបោះពុម្ពស្លាក។</p>
</div>
<form method="GET" class="mt-5 flex flex-wrap gap-2 rounded-xl bg-white p-4 shadow-sm">
    <input type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="ឈ្មោះ, SKU ឬ Barcode" class="min-w-60 flex-1 rounded-lg border-slate-300">
    <button class="rounded-lg bg-slate-700 px-4 py-2 text-white">ស្វែងរក</button>
    <a href="<?php echo e(route('barcodes.index')); ?>" class="rounded-lg border px-4 py-2">សម្អាត</a>
</form>
<form method="POST" action="<?php echo e(route('barcodes.print')); ?>" target="_blank">
    <?php echo csrf_field(); ?>
    <div class="mt-4 flex flex-wrap items-end justify-between gap-3 rounded-xl bg-white p-4 shadow-sm">
        <label class="text-sm">ទំហំស្លាក
            <select name="label_size" class="mt-1 block rounded-lg border-slate-300">
                <option value="small">តូច</option>
                <option value="medium" selected>មធ្យម</option>
                <option value="large">ធំ</option>
            </select>
        </label>
        <button class="rounded-lg bg-blue-700 px-4 py-2 text-white">មើលស្លាក និងបោះពុម្ព</button>
    </div>
    <?php $__errorArgs = ['product_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-3 rounded-lg bg-red-50 p-3 text-sm text-red-700"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="mt-4 overflow-x-auto rounded-xl bg-white shadow-sm">
        <table class="min-w-full divide-y">
            <thead class="bg-slate-50"><tr>
                <th class="px-4 py-3 text-left text-sm">ជ្រើស</th>
                <th class="px-4 py-3 text-left text-sm">ផលិតផល</th>
                <th class="px-4 py-3 text-left text-sm">Barcode</th>
                <th class="px-4 py-3 text-right text-sm">តម្លៃលក់</th>
                <th class="px-4 py-3 text-right text-sm">ចំនួនស្លាក</th>
                <th class="px-4 py-3 text-left text-sm">មើលជាមុន</th>
            </tr></thead>
            <tbody class="divide-y">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-4 py-3">
                            <?php if($product->barcode): ?>
                                <input type="checkbox" name="product_ids[]" value="<?php echo e($product->id); ?>" class="rounded border-slate-300">
                            <?php else: ?>
                                <span class="text-xs text-slate-400">គ្មាន Barcode</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3">
                            <a href="<?php echo e(route('products.show', $product)); ?>" class="font-medium text-blue-700"><?php echo e($product->name); ?></a>
                            <div class="font-mono text-xs text-slate-500">SKU: <?php echo e($product->sku); ?></div>
                        </td>
                        <td class="px-4 py-3 font-mono text-sm"><?php echo e($product->barcode ?: '—'); ?></td>
                        <td class="px-4 py-3 text-right"><?php echo e(app(\App\Services\SystemSettingsService::class)->formatAmount((float) $product->selling_price, 'USD')); ?></td>
                        <td class="px-4 py-3 text-right">
                            <?php if($product->barcode): ?>
                                <input type="number" name="quantities[<?php echo e($product->id); ?>]" min="1" max="100" value="1" class="w-20 rounded-lg border-slate-300 text-right">
                            <?php elseif(auth()->user()->hasRole('admin') || auth()->user()->hasPermission('products.manage')): ?>
                                <a href="<?php echo e(route('products.edit', $product)); ?>" class="text-sm text-blue-700">បង្កើត Barcode</a>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3">
                            <?php if($product->barcode): ?>
                                <img src="<?php echo e(route('products.barcode', $product)); ?>" alt="Barcode <?php echo e($product->barcode); ?>" class="h-12 max-w-48">
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="px-4 py-8 text-center text-slate-500">មិនមានផលិតផលទេ។</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</form>
<div class="mt-4"><?php echo e($products->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/barcodes/index.blade.php ENDPATH**/ ?>