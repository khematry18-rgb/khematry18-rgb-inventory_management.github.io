
<?php $__env->startSection('title', 'ផលិតផល'); ?>
<?php $__env->startSection('content'); ?>
<?php
    $canManage = auth()->user()->hasPermission('products.manage');
?>
<div class="flex flex-wrap items-center justify-between gap-3">
    <div>
        <h1 class="text-2xl font-bold text-slate-900">បញ្ជីផលិតផល</h1>
        <p class="mt-1 text-sm text-slate-500">ស្វែងរក តម្រង និងត្រួតពិនិត្យស្តុកផលិតផល</p>
    </div>
    <?php if($canManage): ?>
        <div class="flex flex-wrap gap-2">
            <a href="<?php echo e(route('barcodes.index')); ?>" class="rounded-lg border border-slate-300 px-4 py-2 text-slate-700">បោះពុម្ព Barcode / QR</a>
            <a href="<?php echo e(route('products.create')); ?>" class="rounded-lg bg-blue-700 px-4 py-2 text-white hover:bg-blue-800">បង្កើតផលិតផល</a>
        </div>
    <?php endif; ?>
</div>

<form method="GET" class="mt-5 grid gap-3 rounded-xl bg-white p-4 shadow-sm md:grid-cols-6">
    <input type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="ឈ្មោះ, SKU ឬ Barcode" class="rounded-lg border-slate-300 md:col-span-2">
    <select name="category_id" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់ប្រភេទ --</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>" <?php if((string) request('category_id') === (string) $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="is_active" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់ស្ថានភាព --</option>
        <option value="1" <?php if(request('is_active') === '1'): echo 'selected'; endif; ?>>សកម្ម</option>
        <option value="0" <?php if(request('is_active') === '0'): echo 'selected'; endif; ?>>អសកម្ម</option>
    </select>
    <select name="stock_status" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់ស្តុក --</option>
        <option value="in_stock" <?php if(request('stock_status') === 'in_stock'): echo 'selected'; endif; ?>>មានស្តុក</option>
        <option value="low_stock" <?php if(request('stock_status') === 'low_stock'): echo 'selected'; endif; ?>>ស្តុកតិច</option>
        <option value="out_of_stock" <?php if(request('stock_status') === 'out_of_stock'): echo 'selected'; endif; ?>>អស់ស្តុក</option>
    </select>
    <select name="per_page" class="rounded-lg border-slate-300">
        <?php $__currentLoopData = [10, 25, 50]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($size); ?>" <?php if((int) request('per_page', 10) === $size): echo 'selected'; endif; ?>><?php echo e($size); ?> ជួរ</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <div class="flex gap-2 md:col-span-6 md:justify-end">
        <button type="submit" class="rounded-lg bg-slate-700 px-4 py-2 text-white">ស្វែងរក</button>
        <a href="<?php echo e(route('products.index')); ?>" class="rounded-lg border border-slate-300 px-4 py-2 text-slate-700">សម្អាត</a>
    </div>
</form>

<div class="mt-5 overflow-x-auto rounded-xl bg-white shadow-sm">
    <table class="min-w-full divide-y divide-slate-200">
        <thead class="bg-slate-50">
            <tr>
                <th class="px-4 py-3 text-left text-sm text-slate-600">រូបភាព</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">ផលិតផល</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">ប្រភេទ</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">តម្លៃលក់</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">ស្តុក</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">ស្ថានភាព</th>
                <?php if($canManage): ?><th class="px-4 py-3 text-right text-sm text-slate-600">សកម្មភាព</th><?php endif; ?>
            </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                if ((float) $product->stock_quantity <= 0) {
                    $stockLabel = 'អស់ស្តុក'; $stockClass = 'bg-red-100 text-red-700';
                } elseif ((float) $product->stock_quantity <= (float) $product->minimum_stock) {
                    $stockLabel = 'ស្តុកតិច'; $stockClass = 'bg-amber-100 text-amber-700';
                } else {
                    $stockLabel = 'មានស្តុក'; $stockClass = 'bg-green-100 text-green-700';
                }
            ?>
            <tr>
                <td class="px-4 py-3">
                    <?php if($product->image): ?>
                        <img src="<?php echo e(asset('storage/'.$product->image)); ?>" alt="<?php echo e($product->name); ?>" class="h-12 w-12 rounded-lg object-cover">
                    <?php else: ?>
                        <div class="grid h-12 w-12 place-items-center rounded-lg bg-slate-100 text-xs text-slate-400">N/A</div>
                    <?php endif; ?>
                </td>
                <td class="px-4 py-3">
                    <a href="<?php echo e(route('products.show', $product)); ?>" class="font-medium text-blue-700 hover:text-blue-900"><?php echo e($product->name); ?></a>
                    <div class="mt-1 font-mono text-xs text-slate-500">SKU: <?php echo e($product->sku); ?></div>
                    <div class="mt-1 font-mono text-xs text-slate-500">Barcode: <?php echo e($product->barcode ?: '—'); ?></div>
                </td>
                <td class="px-4 py-3"><?php echo e($product->category->name ?? '—'); ?></td>
                <td class="px-4 py-3"><?php echo e(app(\App\Services\SystemSettingsService::class)->formatAmount((float) $product->selling_price, 'USD')); ?></td>
                <td class="px-4 py-3">
                    <div><?php echo e(number_format((float) $product->stock_quantity, 3)); ?> <?php echo e($product->unit); ?></div>
                    <div class="mt-1 text-xs text-slate-500">អប្បបរមា <?php echo e(number_format((float) $product->minimum_stock, 3)); ?></div>
                    <span class="mt-1 inline-block rounded-full px-2 py-1 text-xs <?php echo e($stockClass); ?>"><?php echo e($stockLabel); ?></span>
                </td>
                <td class="px-4 py-3">
                    <span class="rounded-full px-2 py-1 text-xs <?php echo e($product->is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'); ?>"><?php echo e($product->is_active ? 'សកម្ម' : 'អសកម្ម'); ?></span>
                </td>
                <?php if($canManage): ?>
                <td class="px-4 py-3 text-right whitespace-nowrap">
                    <a href="<?php echo e(route('products.edit', $product)); ?>" class="text-blue-700 hover:text-blue-900">កែសម្រួល</a>
                    <form method="POST" action="<?php echo e(route('products.destroy', $product)); ?>" class="inline" onsubmit="return confirm('តើអ្នកពិតជាចង់លុបផលិតផល <?php echo e(addslashes($product->name)); ?> មែនទេ?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="ml-3 text-red-700 hover:text-red-900">លុប</button>
                    </form>
                </td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="<?php echo e($canManage ? 7 : 6); ?>" class="px-4 py-8 text-center text-slate-500">មិនមានទិន្នន័យផលិតផល</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="mt-4"><?php echo e($products->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/products/index.blade.php ENDPATH**/ ?>