
<?php $__env->startSection('title', 'អ្នកផ្គត់ផ្គង់'); ?>
<?php $__env->startSection('content'); ?>
<div class="flex flex-wrap items-center justify-between gap-3">
    <div>
        <h1 class="text-2xl font-bold text-slate-900">បញ្ជីអ្នកផ្គត់ផ្គង់</h1>
        <p class="mt-1 text-sm text-slate-500">ស្វែងរក និងគ្រប់គ្រងព័ត៌មានអ្នកផ្គត់ផ្គង់</p>
    </div>
    <a href="<?php echo e(route('suppliers.create')); ?>" class="rounded-lg bg-blue-700 px-4 py-2 text-white hover:bg-blue-800">បង្កើតអ្នកផ្គត់ផ្គង់</a>
</div>

<form method="GET" class="mt-5 grid gap-3 rounded-xl bg-white p-4 shadow-sm md:grid-cols-5">
    <input type="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="ឈ្មោះ, ក្រុមហ៊ុន, អ្នកទំនាក់ទំនង, ទូរស័ព្ទ ឬអ៊ីមែល" class="rounded-lg border-slate-300 md:col-span-2">
    <select name="is_active" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់ស្ថានភាព --</option>
        <option value="1" <?php if(request('is_active') === '1'): echo 'selected'; endif; ?>>សកម្ម</option>
        <option value="0" <?php if(request('is_active') === '0'): echo 'selected'; endif; ?>>អសកម្ម</option>
    </select>
    <select name="per_page" class="rounded-lg border-slate-300">
        <?php $__currentLoopData = [10,25,50]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($size); ?>" <?php if((int) request('per_page', 10) === $size): echo 'selected'; endif; ?>><?php echo e($size); ?> ជួរ</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <div class="flex gap-2 md:justify-end">
        <button type="submit" class="rounded-lg bg-slate-700 px-4 py-2 text-white">ស្វែងរក</button>
        <a href="<?php echo e(route('suppliers.index')); ?>" class="rounded-lg border border-slate-300 px-4 py-2 text-slate-700">សម្អាត</a>
    </div>
</form>

<div class="mt-5 overflow-x-auto rounded-xl bg-white shadow-sm">
    <table class="min-w-full divide-y divide-slate-200">
        <thead class="bg-slate-50">
            <tr>
                <th class="px-4 py-3 text-left text-sm text-slate-600">អ្នកផ្គត់ផ្គង់</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">ទំនាក់ទំនង</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">ទីតាំង</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">ការទិញ</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">ស្ថានភាព</th>
                <th class="px-4 py-3 text-right text-sm text-slate-600">សកម្មភាព</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
        <?php $__empty_1 = true; $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="px-4 py-3">
                    <a href="<?php echo e(route('suppliers.show', $supplier)); ?>" class="font-medium text-blue-700"><?php echo e($supplier->name); ?></a>
                    <div class="text-xs text-slate-500"><?php echo e($supplier->company_name ?: '—'); ?></div>
                </td>
                <td class="px-4 py-3 text-sm">
                    <div><?php echo e($supplier->contact_person ?: '—'); ?></div>
                    <div class="text-slate-500"><?php echo e($supplier->phone ?: '—'); ?></div>
                    <div class="text-slate-500"><?php echo e($supplier->email ?: '—'); ?></div>
                </td>
                <td class="px-4 py-3 text-sm"><?php echo e(collect([$supplier->city, $supplier->country])->filter()->implode(', ') ?: '—'); ?></td>
                <td class="px-4 py-3"><?php echo e($supplier->purchases_count); ?></td>
                <td class="px-4 py-3">
                    <span class="rounded-full px-2 py-1 text-xs <?php echo e($supplier->is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'); ?>"><?php echo e($supplier->is_active ? 'សកម្ម' : 'អសកម្ម'); ?></span>
                </td>
                <td class="px-4 py-3 text-right whitespace-nowrap">
                    <a href="<?php echo e(route('suppliers.edit', $supplier)); ?>" class="text-blue-700">កែសម្រួល</a>
                    <form method="POST" action="<?php echo e(route('suppliers.destroy', $supplier)); ?>" class="inline" onsubmit="return confirm('តើអ្នកពិតជាចង់លុបអ្នកផ្គត់ផ្គង់ <?php echo e(addslashes($supplier->name)); ?> មែនទេ?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="ml-3 text-red-700">លុប</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6" class="px-4 py-8 text-center text-slate-500">មិនមានទិន្នន័យអ្នកផ្គត់ផ្គង់</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="mt-4"><?php echo e($suppliers->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/suppliers/index.blade.php ENDPATH**/ ?>