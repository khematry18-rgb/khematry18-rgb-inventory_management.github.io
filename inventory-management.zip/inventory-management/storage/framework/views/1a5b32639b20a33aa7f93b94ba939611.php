
<?php $__env->startSection('title', 'គ្រប់គ្រងស្តុក'); ?>
<?php $__env->startSection('content'); ?>
<?php
    $canManage = auth()->user()->hasRole('admin') || auth()->user()->hasPermission('stock.manage');
?>
<div class="flex flex-wrap items-center justify-between gap-3">
    <div><h1 class="text-2xl font-bold text-slate-900">គ្រប់គ្រងស្តុក</h1><p class="mt-1 text-sm text-slate-500">ពិនិត្យស្តុក បញ្ចូល ដក និងកែតម្រូវ</p></div>
    <?php if($canManage): ?>
    <div class="flex flex-wrap gap-2">
        <a href="<?php echo e(route('stock.in')); ?>" class="rounded-lg bg-green-700 px-3 py-2 text-white">បញ្ចូលស្តុក</a>
        <a href="<?php echo e(route('stock.out')); ?>" class="rounded-lg bg-red-700 px-3 py-2 text-white">ដកស្តុក</a>
        <a href="<?php echo e(route('stock.adjustment')); ?>" class="rounded-lg bg-blue-700 px-3 py-2 text-white">កែតម្រូវស្តុក</a>
    </div>
    <?php endif; ?>
</div>

<div class="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
    <div class="rounded-xl bg-white p-5 shadow-sm"><div class="text-sm text-slate-500">សរុបផលិតផល</div><div class="mt-2 text-2xl font-bold"><?php echo e(number_format($totalProducts)); ?></div></div>
    <div class="rounded-xl bg-white p-5 shadow-sm"><div class="text-sm text-slate-500">បរិមាណស្តុកសរុប</div><div class="mt-2 text-2xl font-bold"><?php echo e(number_format($totalStockQuantity, 3)); ?></div></div>
    <div class="rounded-xl bg-white p-5 shadow-sm"><div class="text-sm text-slate-500">ស្តុកតិច</div><div class="mt-2 text-2xl font-bold text-amber-600"><?php echo e(number_format($lowStockCount)); ?></div></div>
    <div class="rounded-xl bg-white p-5 shadow-sm"><div class="text-sm text-slate-500">អស់ស្តុក</div><div class="mt-2 text-2xl font-bold text-red-600"><?php echo e(number_format($outOfStockCount)); ?></div></div>
</div>

<div class="mt-5 grid gap-5 lg:grid-cols-3">
    <section class="rounded-xl bg-white p-5 shadow-sm lg:col-span-2">
        <div class="flex items-center justify-between"><h2 class="font-semibold">ប្រតិបត្តិការថ្មីៗ</h2><a href="<?php echo e(route('stock.history')); ?>" class="text-sm text-blue-700">មើលទាំងអស់</a></div>
        <div class="mt-4 overflow-x-auto">
            <table class="min-w-full divide-y divide-slate-200">
                <thead class="bg-slate-50"><tr><th class="px-3 py-2 text-left text-sm">ផលិតផល</th><th class="px-3 py-2 text-left text-sm">ប្រភេទ</th><th class="px-3 py-2 text-left text-sm">មុន → បន្ទាប់</th><th class="px-3 py-2 text-left text-sm">កាលបរិច្ឆេទ</th></tr></thead>
                <tbody class="divide-y">
                <?php $__empty_1 = true; $__currentLoopData = $stockMovements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr><td class="px-3 py-3"><div><?php echo e($movement->product->name); ?></div><div class="font-mono text-xs text-slate-500"><?php echo e($movement->product->sku); ?></div></td><td class="px-3 py-3"><?php echo e($movement->movement_type); ?></td><td class="px-3 py-3"><?php echo e(number_format((float) $movement->stock_before, 3)); ?> → <?php echo e(number_format((float) $movement->stock_after, 3)); ?></td><td class="px-3 py-3"><?php echo e(app(\App\Services\SystemSettingsService::class)->formatDate($movement->transaction_date ?: $movement->created_at, true)); ?></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="px-3 py-8 text-center text-slate-500">មិនមានប្រតិបត្តិការស្តុក</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
    <section class="rounded-xl bg-white p-5 shadow-sm">
        <h2 class="font-semibold">ការជូនដំណឹងស្តុកតិច</h2>
        <div class="mt-4 space-y-3">
        <?php $__empty_1 = true; $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="rounded-lg border border-amber-200 bg-amber-50 p-3">
                <div class="font-medium"><?php echo e($product->name); ?></div>
                <div class="mt-1 text-xs text-slate-600">SKU: <?php echo e($product->sku); ?></div>
                <div class="mt-1 text-sm text-amber-800"><?php echo e(number_format((float) $product->stock_quantity, 3)); ?> / <?php echo e(number_format((float) $product->minimum_stock, 3)); ?> <?php echo e($product->unit); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-sm text-slate-500">មិនមានផលិតផលស្តុកតិច</p>
        <?php endif; ?>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\websites\inventory-management\resources\views/stock/index.blade.php ENDPATH**/ ?>