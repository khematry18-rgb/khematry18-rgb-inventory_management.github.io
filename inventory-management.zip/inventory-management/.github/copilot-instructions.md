# Inventory Management System Workspace Guidelines

- Build this Laravel 12 application incrementally in the order defined by the project phases.
- Preserve existing working code and database tables.
- Use Laravel Blade, Tailwind CSS, Vite, and vanilla JavaScript.
- Use MySQL, Eloquent relationships, migrations, validation, policies, middleware, and database transactions.
- User-facing labels must be Khmer; currency must support USD and KHR.
- Use server-calculated totals and prevent negative stock.
- Add focused tests and run them before moving to the next module.
- Keep changes small, repository-specific, and compatible with PHP 8.2+ and XAMPP.
