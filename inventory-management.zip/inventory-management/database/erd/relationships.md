# Inventory Management Database Relationships

This document describes the current `inventory_management` MariaDB schema, checked against the live database, all 26 Laravel migrations, and the Eloquent models. It describes relationships only; it does not change the database.

## Database verification

- Database connection: Laravel `mysql` driver, MariaDB 10.4.32.
- Migrations: all 26 recorded as `Ran`.
- Tables: 24.
- Declared foreign keys: 18; all child and referenced column types match (`BIGINT UNSIGNED`).
- No duplicate foreign keys or duplicate index column sets were found.

## Business relationships

| Parent | Child / related table | Relationship | Foreign key / pivot | Delete behavior |
|---|---|---|---|---|
| `roles` | `users` | One role has many users; a user's role is optional | `users.role_id` → `roles.id` | Set role to `NULL` |
| `roles` | `permissions` | Many-to-many | `role_permissions.role_id` → `roles.id`; `role_permissions.permission_id` → `permissions.id`; composite primary key prevents duplicate pairs | Cascade from either parent |
| `categories` | `products` | One category has many products | `products.category_id` → `categories.id` | Restrict category deletion while products exist |
| `suppliers` | `purchases` | One supplier has many purchases | `purchases.supplier_id` → `suppliers.id` | Restrict supplier deletion while purchases exist |
| `users` | `purchases` (creator) | One user can create many purchases; creator is optional | `purchases.created_by` → `users.id` | Set to `NULL` |
| `users` | `purchases` (receiver) | One user can receive many purchases; receiver is optional | `purchases.received_by` → `users.id` | Set to `NULL` |
| `purchases` | `purchase_items` | One purchase has many line items | `purchase_items.purchase_id` → `purchases.id` | Cascade |
| `products` | `purchase_items` | One product can appear in many purchase line items | `purchase_items.product_id` → `products.id` | Restrict product deletion while referenced |
| `users` | `sales` (creator) | One user can create many sales; creator is optional | `sales.created_by` → `users.id` | Set to `NULL` |
| `sales` | `sale_items` | One sale has many line items | `sale_items.sale_id` → `sales.id` | Cascade |
| `products` | `sale_items` | One product can appear in many sale line items | `sale_items.product_id` → `products.id` | Restrict product deletion while referenced |
| `products` | `stock_movements` | One product has many stock movements | `stock_movements.product_id` → `products.id` | Restrict product deletion while referenced |
| `users` | `stock_movements` | One user can record many stock movements; user is optional | `stock_movements.user_id` → `users.id` | Set to `NULL` |
| `sales` | `payments` | One sale has many payments; payment owner is optional per FK | `payments.sale_id` → `sales.id` | Cascade |
| `purchases` | `payments` | One purchase has many payments; payment owner is optional per FK | `payments.purchase_id` → `purchases.id` | Cascade |
| `users` | `payments` (recorder) | One user can record many payments; recorder is optional | `payments.recorded_by` → `users.id` | Set to `NULL` |
| `users` | `activity_logs` | One user can have many activity log entries; user is optional | `activity_logs.user_id` → `users.id` | Set to `NULL` |

`payments_has_one_owner` is a database CHECK constraint requiring exactly one of `sale_id` or `purchase_id` to be non-`NULL`. Thus each payment belongs to either a sale or a purchase, not both or neither.

The sale/product and purchase/product associations are implemented through `sale_items` and `purchase_items`. They are line-item models with quantity and price fields, not direct `belongsToMany` relationships. Each line-item table has a unique constraint on its parent/`product_id` pair, so the same product cannot appear twice in one transaction.

## Polymorphic associations

These are polymorphic Eloquent relationships, so a single conventional foreign key cannot reference multiple possible parent tables:

- `notifications.notifiable_type` + `notifications.notifiable_id` → a notifiable model (Laravel notification owner).
- `stock_movements.reference_type` + `stock_movements.reference_id` → a referenced model; `Purchase` and `Sale` expose these as `stockMovements()`.
- `activity_logs.subject_type` + `activity_logs.subject_id` → the subject model for an activity log.

The corresponding indexes support lookup, but referential integrity for the polymorphic target is application-managed.

## Relationships intentionally not enforced by a foreign key

- `sessions.user_id` is indexed but has no FK to `users.id` in the Laravel framework migration. The live database currently has zero session rows whose non-`NULL` user ID is orphaned. This is reported as an FK omission, not silently represented as an enforced relationship.
- `password_reset_tokens` uses its email as a primary key and has no user-ID relationship.
- The remaining Laravel infrastructure tables (`cache`, `cache_locks`, `jobs`, `job_batches`, `failed_jobs`, and `migrations`) have no relationships to application tables.
- `system_settings` is standalone.

## Integrity findings

- No mismatch was found between the data types of any existing FK and its referenced PK.
- A nonnegative-stock CHECK constraint was created for `products.stock_quantity` by `2026_11_03_010013_add_inventory_business_constraints.php` but explicitly dropped by `2026_11_11_010001_add_transaction_currencies.php`. The live schema therefore does not enforce nonnegative stock at the database level. No negative product stock was found during this check. Application-side safeguards were not modified.
- Other live CHECK constraints from the inventory constraints migration remain: nonnegative `products.minimum_stock`, positive purchase/sale item and stock movement quantities, and the one-owner payment rule. MariaDB also enforces valid JSON for `system_settings.settings_data`.

