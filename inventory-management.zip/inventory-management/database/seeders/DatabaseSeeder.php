<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\Role;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $permissions = [
            'users.manage' => ['name' => 'គ្រប់គ្រងអ្នកប្រើប្រាស់', 'group' => 'users'],
            'roles.manage' => ['name' => 'គ្រប់គ្រងតួនាទី និងសិទ្ធិ', 'group' => 'roles'],
            'products.manage' => ['name' => 'គ្រប់គ្រងផលិតផល', 'group' => 'products'],
            'products.view' => ['name' => 'មើលផលិតផល', 'group' => 'products'],
            'categories.manage' => ['name' => 'គ្រប់គ្រងប្រភេទ', 'group' => 'categories'],
            'suppliers.manage' => ['name' => 'គ្រប់គ្រងអ្នកផ្គត់ផ្គង់', 'group' => 'suppliers'],
            'purchases.manage' => ['name' => 'គ្រប់គ្រងការទិញ', 'group' => 'purchases'],
            'sales.manage' => ['name' => 'គ្រប់គ្រងការលក់', 'group' => 'sales'],
            'sales.create' => ['name' => 'បង្កើតការលក់', 'group' => 'sales'],
            'sales.view' => ['name' => 'មើលការលក់', 'group' => 'sales'],
            'stock.manage' => ['name' => 'គ្រប់គ្រងស្តុក', 'group' => 'stock'],
            'stock.view' => ['name' => 'មើលស្តុក', 'group' => 'stock'],
            'reports.view' => ['name' => 'មើលរបាយការណ៍', 'group' => 'reports'],
            'activity-logs.view' => ['name' => 'មើលកំណត់ហេតុសកម្មភាព', 'group' => 'activity-logs'],
            'settings.manage' => ['name' => 'គ្រប់គ្រងការកំណត់', 'group' => 'settings'],
        ];

        foreach ($permissions as $slug => $data) {
            Permission::updateOrCreate(['slug' => $slug], [
                'name' => $data['name'],
                'group_name' => $data['group'],
            ]);
        }

        $roles = [
            'admin' => ['name' => 'Admin', 'permissions' => array_keys($permissions)],
            'manager' => ['name' => 'Manager', 'permissions' => [
                'products.manage', 'categories.manage', 'suppliers.manage', 'purchases.manage',
                'sales.manage', 'stock.manage', 'reports.view',
            ]],
            'staff' => ['name' => 'Staff', 'permissions' => [
                'products.view', 'sales.create', 'sales.view', 'stock.view',
            ]],
        ];

        foreach ($roles as $slug => $data) {
            $role = Role::updateOrCreate(['slug' => $slug], [
                'name' => $data['name'],
                'description' => null,
                'is_active' => true,
            ]);
            $role->permissions()->sync(
                Permission::whereIn('slug', $data['permissions'])->pluck('id')
            );
        }
    }
}
