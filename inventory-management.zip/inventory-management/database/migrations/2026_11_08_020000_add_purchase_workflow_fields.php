<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('purchases', function (Blueprint $table) {
            if (! Schema::hasColumn('purchases', 'expected_delivery_at')) {
                $table->dateTime('expected_delivery_at')->nullable()->after('purchased_at');
            }
            if (! Schema::hasColumn('purchases', 'reference_number')) {
                $table->string('reference_number')->nullable()->after('expected_delivery_at');
            }
            if (! Schema::hasColumn('purchases', 'tax')) {
                $table->decimal('tax', 15, 2)->default(0)->after('discount');
            }
            if (! Schema::hasColumn('purchases', 'payment_status')) {
                $table->string('payment_status', 30)->default('unpaid')->after('status')->index();
            }
            if (! Schema::hasColumn('purchases', 'received_at')) {
                $table->timestamp('received_at')->nullable()->after('confirmed_at');
            }
            if (! Schema::hasColumn('purchases', 'received_by')) {
                $table->foreignId('received_by')->nullable()->after('received_at')->constrained('users')->nullOnDelete();
            }
            if (! Schema::hasColumn('purchases', 'cancelled_at')) {
                $table->timestamp('cancelled_at')->nullable();
            }
            if (! Schema::hasColumn('purchases', 'cancel_reason')) {
                $table->text('cancel_reason')->nullable();
            }
        });

        Schema::table('purchase_items', function (Blueprint $table) {
            if (! Schema::hasColumn('purchase_items', 'received_quantity')) {
                $table->decimal('received_quantity', 15, 3)->default(0)->after('quantity');
            }
        });
    }

    public function down(): void
    {
        Schema::table('purchase_items', function (Blueprint $table) {
            if (Schema::hasColumn('purchase_items', 'received_quantity')) {
                $table->dropColumn('received_quantity');
            }
        });

        Schema::table('purchases', function (Blueprint $table) {
            if (Schema::hasColumn('purchases', 'received_by')) {
                $table->dropConstrainedForeignId('received_by');
            }
            $columns = ['expected_delivery_at', 'reference_number', 'tax', 'payment_status', 'received_at', 'cancelled_at', 'cancel_reason'];
            foreach ($columns as $column) {
                if (Schema::hasColumn('purchases', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
