<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('sale_items', function (Blueprint $table) {
            if (! Schema::hasColumn('sale_items', 'cost_price')) {
                $table->decimal('cost_price', 15, 2)->nullable()->after('unit_price');
            }
        });

        DB::table('sale_items')
            ->whereNull('cost_price')
            ->select(['id', 'product_id'])
            ->orderBy('id')
            ->chunkById(500, function ($items) {
                foreach ($items as $item) {
                    $costPrice = DB::table('products')->where('id', $item->product_id)->value('cost_price');
                    DB::table('sale_items')->where('id', $item->id)->update([
                        'cost_price' => $costPrice === null ? 0 : $costPrice,
                    ]);
                }
            }, 'id');
    }

    public function down(): void
    {
        Schema::table('sale_items', function (Blueprint $table) {
            if (Schema::hasColumn('sale_items', 'cost_price')) {
                $table->dropColumn('cost_price');
            }
        });
    }
};
