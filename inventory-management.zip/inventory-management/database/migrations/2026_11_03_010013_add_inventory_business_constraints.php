<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        if (DB::getDriverName() !== 'mysql') {
            return;
        }

        DB::statement('ALTER TABLE products ADD CONSTRAINT products_stock_nonnegative CHECK (stock_quantity >= 0)');
        DB::statement('ALTER TABLE products ADD CONSTRAINT products_minimum_stock_nonnegative CHECK (minimum_stock >= 0)');
        DB::statement('ALTER TABLE purchase_items ADD CONSTRAINT purchase_items_quantity_positive CHECK (quantity > 0)');
        DB::statement('ALTER TABLE sale_items ADD CONSTRAINT sale_items_quantity_positive CHECK (quantity > 0)');
        DB::statement('ALTER TABLE stock_movements ADD CONSTRAINT stock_movements_quantity_positive CHECK (quantity > 0)');
        DB::statement('ALTER TABLE payments ADD CONSTRAINT payments_has_one_owner CHECK ((sale_id IS NOT NULL AND purchase_id IS NULL) OR (sale_id IS NULL AND purchase_id IS NOT NULL))');
    }

    public function down(): void
    {
        if (DB::getDriverName() !== 'mysql') {
            return;
        }

        DB::statement('ALTER TABLE products DROP CONSTRAINT products_stock_nonnegative');
        DB::statement('ALTER TABLE products DROP CONSTRAINT products_minimum_stock_nonnegative');
        DB::statement('ALTER TABLE purchase_items DROP CONSTRAINT purchase_items_quantity_positive');
        DB::statement('ALTER TABLE sale_items DROP CONSTRAINT sale_items_quantity_positive');
        DB::statement('ALTER TABLE stock_movements DROP CONSTRAINT stock_movements_quantity_positive');
        DB::statement('ALTER TABLE payments DROP CONSTRAINT payments_has_one_owner');
    }
};
