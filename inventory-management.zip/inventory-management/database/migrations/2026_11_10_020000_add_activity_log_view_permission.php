<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::table('permissions')->insertOrIgnore([
            'name' => 'មើលកំណត់ហេតុសកម្មភាព',
            'slug' => 'activity-logs.view',
            'group_name' => 'activity-logs',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function down(): void
    {
        // Keep the permission row so existing role assignments survive rollback.
    }
};
