<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('sales', function (Blueprint $table) {
            if (! Schema::hasColumn('sales', 'tax')) {
                $table->decimal('tax', 15, 2)->default(0)->after('discount');
            }
            if (! Schema::hasColumn('sales', 'customer_email')) {
                $table->string('customer_email')->nullable()->after('customer_phone');
            }
            if (! Schema::hasColumn('sales', 'customer_address')) {
                $table->text('customer_address')->nullable()->after('customer_email');
            }
            if (! Schema::hasColumn('sales', 'submission_key')) {
                $table->string('submission_key', 36)->nullable()->unique()->after('notes');
            }
            if (! Schema::hasColumn('sales', 'cancelled_at')) {
                $table->timestamp('cancelled_at')->nullable();
            }
            if (! Schema::hasColumn('sales', 'cancel_reason')) {
                $table->text('cancel_reason')->nullable();
            }
            $table->index(['sold_at', 'status']);
        });
    }

    public function down(): void
    {
        Schema::table('sales', function (Blueprint $table) {
            $table->dropIndex(['sold_at', 'status']);
            if (Schema::hasColumn('sales', 'submission_key')) {
                $table->dropUnique(['submission_key']);
            }
        });

        Schema::table('sales', function (Blueprint $table) {
            foreach (['tax', 'customer_email', 'customer_address', 'submission_key', 'cancelled_at', 'cancel_reason'] as $column) {
                if (Schema::hasColumn('sales', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
