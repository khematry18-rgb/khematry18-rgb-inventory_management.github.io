<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('stock_movements', function (Blueprint $table) {
            if (! Schema::hasColumn('stock_movements', 'reference_number')) {
                $table->string('reference_number')->nullable()->after('reason');
            }
            if (! Schema::hasColumn('stock_movements', 'notes')) {
                $table->text('notes')->nullable()->after('reference_number');
            }
            if (! Schema::hasColumn('stock_movements', 'transaction_date')) {
                $table->dateTime('transaction_date')->nullable()->after('notes');
            }
            if (! Schema::hasColumn('stock_movements', 'unit_cost')) {
                $table->decimal('unit_cost', 15, 2)->nullable()->after('transaction_date');
            }
            if (! Schema::hasColumn('stock_movements', 'submission_key')) {
                $table->string('submission_key', 36)->nullable()->after('unit_cost');
            }
        });

        Schema::table('stock_movements', function (Blueprint $table) {
            $table->unique('submission_key', 'stock_movements_submission_key_unique');
            $table->index(['transaction_date', 'movement_type']);
            $table->index(['user_id', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::table('stock_movements', function (Blueprint $table) {
            $table->dropUnique('stock_movements_submission_key_unique');
            $table->dropIndex(['transaction_date', 'movement_type']);
            $table->dropIndex(['user_id', 'created_at']);
            $table->dropColumn(['reference_number', 'notes', 'transaction_date', 'unit_cost', 'submission_key']);
        });
    }
};
