<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('sales', function (Blueprint $table) {
            $table->string('currency', 3)->default('USD')->after('sale_number');
            $table->decimal('exchange_rate', 15, 6)->default(1)->after('currency');
            $table->index(['currency', 'sold_at']);
        });

        Schema::table('purchases', function (Blueprint $table) {
            $table->string('currency', 3)->default('USD')->after('purchase_number');
            $table->decimal('exchange_rate', 15, 6)->default(1)->after('currency');
            $table->index(['currency', 'purchased_at']);
        });

        if (DB::getDriverName() === 'mysql') {
            DB::statement('ALTER TABLE products DROP CONSTRAINT products_stock_nonnegative');
        }
    }

    public function down(): void
    {
        if (DB::getDriverName() === 'mysql') {
            DB::statement('ALTER TABLE products ADD CONSTRAINT products_stock_nonnegative CHECK (stock_quantity >= 0)');
        }

        Schema::table('purchases', function (Blueprint $table) {
            $table->dropIndex(['currency', 'purchased_at']);
            $table->dropColumn(['currency', 'exchange_rate']);
        });

        Schema::table('sales', function (Blueprint $table) {
            $table->dropIndex(['currency', 'sold_at']);
            $table->dropColumn(['currency', 'exchange_rate']);
        });
    }
};
