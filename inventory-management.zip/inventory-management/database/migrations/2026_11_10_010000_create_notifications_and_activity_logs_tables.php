<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('notifications')) {
            Schema::create('notifications', function (Blueprint $table) {
                $table->uuid('id')->primary();
                $table->string('type');
                $table->morphs('notifiable');
                $table->text('data');
                $table->timestamp('read_at')->nullable()->index();
                $table->timestamps();

                $table->index(['notifiable_type', 'notifiable_id', 'created_at'], 'notifications_owner_created_index');
            });
        }

        if (! Schema::hasTable('activity_logs')) {
            Schema::create('activity_logs', function (Blueprint $table) {
                $table->id();
                $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
                $table->string('action', 80)->index();
                $table->string('module', 50)->index();
                $table->text('description');
                $table->nullableMorphs('subject');
                $table->string('ip_address', 45)->nullable();
                $table->text('user_agent')->nullable();
                $table->timestamps();

                $table->index(['module', 'action', 'created_at'], 'activity_logs_module_action_created_index');
                $table->index(['user_id', 'created_at'], 'activity_logs_user_created_index');
            });
        }

        if (Schema::hasTable('products') && ! Schema::hasColumn('products', 'stock_alert_status')) {
            Schema::table('products', function (Blueprint $table) {
                $table->string('stock_alert_status', 20)->default('normal')->after('minimum_stock');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('products') && Schema::hasColumn('products', 'stock_alert_status')) {
            Schema::table('products', function (Blueprint $table) {
                $table->dropColumn('stock_alert_status');
            });
        }

        Schema::dropIfExists('activity_logs');
        Schema::dropIfExists('notifications');
    }
};
