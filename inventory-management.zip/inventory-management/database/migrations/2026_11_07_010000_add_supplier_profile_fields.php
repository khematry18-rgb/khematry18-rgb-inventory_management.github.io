<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('suppliers', function (Blueprint $table) {
            if (! Schema::hasColumn('suppliers', 'company_name')) {
                $table->string('company_name')->nullable()->after('name');
            }
            if (! Schema::hasColumn('suppliers', 'contact_person')) {
                $table->string('contact_person')->nullable()->after('company_name');
            }
            if (! Schema::hasColumn('suppliers', 'city')) {
                $table->string('city')->nullable()->after('address');
            }
            if (! Schema::hasColumn('suppliers', 'country')) {
                $table->string('country')->nullable()->after('city');
            }
            if (! Schema::hasColumn('suppliers', 'tax_id')) {
                $table->string('tax_id')->nullable()->after('country');
            }
        });

        Schema::table('suppliers', function (Blueprint $table) {
            $table->index(['company_name', 'contact_person']);
            $table->index(['city', 'country']);
        });
    }

    public function down(): void
    {
        Schema::table('suppliers', function (Blueprint $table) {
            $table->dropIndex(['company_name', 'contact_person']);
            $table->dropIndex(['city', 'country']);
            $table->dropColumn(['company_name', 'contact_person', 'city', 'country', 'tax_id']);
        });
    }
};
