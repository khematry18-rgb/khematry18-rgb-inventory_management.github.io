import './bootstrap';

window.loadInventoryBarcodeReader = () => import('@zxing/browser')
    .then(({ BrowserMultiFormatReader }) => BrowserMultiFormatReader);
