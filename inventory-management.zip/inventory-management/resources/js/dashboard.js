import Chart from 'chart.js/auto';

const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('sidebar-overlay');
const openSidebar = () => {
    sidebar?.classList.remove('-translate-x-full');
    overlay?.classList.remove('hidden');
};
const closeSidebar = () => {
    sidebar?.classList.add('-translate-x-full');
    overlay?.classList.add('hidden');
};
document.getElementById('sidebar-open')?.addEventListener('click', openSidebar);
document.getElementById('sidebar-close')?.addEventListener('click', closeSidebar);
overlay?.addEventListener('click', closeSidebar);

const profileButton = document.getElementById('profile-button');
const profileMenu = document.getElementById('profile-menu');
profileButton?.addEventListener('click', () => {
    const opening = profileMenu?.classList.toggle('hidden') === false;
    profileButton.setAttribute('aria-expanded', opening ? 'true' : 'false');
});
document.addEventListener('click', (event) => {
    if (!profileButton?.contains(event.target) && !profileMenu?.contains(event.target)) {
        profileMenu?.classList.add('hidden');
        profileButton?.setAttribute('aria-expanded', 'false');
    }
});

const notificationButton = document.getElementById('notification-button');
const notificationMenu = document.getElementById('notification-menu');
const notificationItems = document.getElementById('notification-items');
notificationButton?.addEventListener('click', () => {
    const opening = notificationMenu?.classList.toggle('hidden') === false;
    notificationButton.setAttribute('aria-expanded', opening ? 'true' : 'false');
    if (opening && notificationItems && notificationItems.dataset.loaded !== 'true') {
        notificationItems.textContent = 'កំពុងផ្ទុក...';
        fetch(notificationItems.dataset.endpoint, { headers: { Accept: 'application/json' } })
            .then((response) => {
                if (!response.ok) throw new Error('Unable to load notifications');
                return response.json();
            })
            .then(({ notifications }) => {
                notificationItems.replaceChildren();
                if (notifications.length === 0) {
                    notificationItems.textContent = 'មិនមានការជូនដំណឹងទេ។';
                } else {
                    notifications.forEach((notification) => {
                        const link = document.createElement('a');
                        link.href = `/notifications/${encodeURIComponent(notification.id)}`;
                        link.className = `block border-b px-4 py-3 hover:bg-slate-50 ${notification.read ? 'bg-white' : 'bg-blue-50'}`;

                        const title = document.createElement('span');
                        title.className = 'block text-sm font-medium';
                        title.textContent = notification.title;
                        const message = document.createElement('span');
                        message.className = 'mt-1 block text-xs text-slate-600';
                        message.textContent = notification.message;
                        const createdAt = document.createElement('span');
                        createdAt.className = 'mt-1 block text-xs text-slate-400';
                        createdAt.textContent = notification.created_at;
                        link.append(title, message, createdAt);
                        notificationItems.append(link);
                    });
                }
                notificationItems.dataset.loaded = 'true';
            })
            .catch(() => {
                notificationItems.textContent = 'មិនអាចផ្ទុកការជូនដំណឹងបានទេ។ សូមព្យាយាមម្ដងទៀត។';
            });
    }
});
document.addEventListener('click', (event) => {
    if (!notificationButton?.contains(event.target) && !notificationMenu?.contains(event.target)) {
        notificationMenu?.classList.add('hidden');
        notificationButton?.setAttribute('aria-expanded', 'false');
    }
});

const dataElement = document.getElementById('dashboard-data');
const canvas = document.getElementById('dashboard-chart');
if (dataElement && canvas) {
    const data = JSON.parse(dataElement.textContent);
    const currency = data.currency || 'USD';
    const symbol = currency === 'KHR' ? '៛' : '$';
    const fractionDigits = currency === 'KHR' ? 0 : 2;
    const formatCurrency = (value) => `${currency === 'KHR' ? '' : symbol}${Number(value).toLocaleString('en-US', { minimumFractionDigits: fractionDigits, maximumFractionDigits: fractionDigits })}${currency === 'KHR' ? symbol : ''}`;
    const periodSelect = document.getElementById('chart-period');
    const metricSelect = document.getElementById('chart-metric');
    const metricLabels = {
        salesSeries: 'ចំណូលលក់',
        purchaseSeries: 'ចំណាយទិញ',
        profitSeries: 'ចំណេញ',
    };
    const metricColors = {
        salesSeries: ['#2563EB', 'rgba(37, 99, 235, 0.12)'],
        purchaseSeries: ['#10B981', 'rgba(16, 185, 129, 0.08)'],
        profitSeries: ['#F59E0B', 'rgba(245, 158, 11, 0.10)'],
    };
    const datasetsFor = (series, metric) => {
        const metrics = metric === 'comparisonSeries'
            ? ['salesSeries', ...(data.canViewPurchases && series.purchaseSeries ? ['purchaseSeries'] : [])]
            : [metric];

        return metrics.map((seriesKey) => {
            const colors = metricColors[seriesKey] || metricColors.salesSeries;

            return {
                label: `${metricLabels[seriesKey]} (${currency})`,
                data: series[seriesKey] || [],
                borderColor: colors[0],
                backgroundColor: colors[1],
                fill: metric !== 'comparisonSeries',
                tension: 0.35,
            };
        });
    };
    let chart;

    const renderChart = () => {
        const granularity = periodSelect?.value || 'daily';
        const metric = metricSelect?.value || 'comparisonSeries';
        const series = data.series[granularity] || data.series.daily;

        if (chart) chart.destroy();
        chart = new Chart(canvas, {
        type: 'line',
        data: {
            labels: series.labels,
            datasets: datasetsFor(series, metric),
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { intersect: false, mode: 'index' },
            plugins: { legend: { display: true, position: 'bottom' }, tooltip: { callbacks: {
                label: (context) => `${context.dataset.label}: ${formatCurrency(context.raw)}`,
            } } },
            scales: { y: { beginAtZero: true, ticks: { callback: (value) => formatCurrency(value) } } },
        },
        });
    };

    periodSelect?.addEventListener('change', renderChart);
    metricSelect?.addEventListener('change', renderChart);
    renderChart();
}

const reportsElement = document.getElementById('reports-data');
if (reportsElement) {
    const reports = JSON.parse(reportsElement.textContent);
    const currency = reports.currency || 'USD';
    const symbol = currency === 'KHR' ? '៛' : '$';
    const fractionDigits = currency === 'KHR' ? 0 : 2;
    const formatCurrency = (value) => `${currency === 'KHR' ? '' : symbol}${Number(value).toLocaleString('en-US', { minimumFractionDigits: fractionDigits, maximumFractionDigits: fractionDigits })}${currency === 'KHR' ? symbol : ''}`;
    const salesCanvas = document.getElementById('report-sales-chart');
    const topCanvas = document.getElementById('report-top-products-chart');
    if (salesCanvas && reports.daily?.labels?.length) {
        new Chart(salesCanvas, {
            type: 'line',
            data: {
                labels: reports.daily.labels,
                datasets: [{
                    label: `ការលក់ (${currency})`,
                    data: reports.daily.sales,
                    borderColor: '#2563EB',
                    backgroundColor: 'rgba(37, 99, 235, 0.12)',
                    fill: true,
                    tension: 0.35,
                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { beginAtZero: true, ticks: { callback: (value) => formatCurrency(value) } } },
                plugins: { legend: { position: 'bottom' } },
            },
        });
    }
    if (topCanvas && reports.top?.labels?.length) {
        new Chart(topCanvas, {
            type: 'bar',
            data: {
                labels: reports.top.labels,
                datasets: [{
                    label: 'បរិមាណលក់',
                    data: reports.top.quantities,
                    backgroundColor: '#10B981',
                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { beginAtZero: true } },
                plugins: { legend: { position: 'bottom' } },
            },
        });
    }
}
