@extends('layouts.app')
@section('title', 'ការកំណត់ប្រព័ន្ធ')
@section('content')
<div class="mb-5">
    <h1 class="text-2xl font-bold">ការកំណត់ប្រព័ន្ធ</h1>
    <p class="mt-1 text-sm text-slate-500">កំណត់ព័ត៌មានហាង រូបិយប័ណ្ណ ស្តុក ការលក់ និងការទិញ។ ការកំណត់អនុវត្តចំពោះប្រតិបត្តិការថ្មីប៉ុណ្ណោះ។</p>
</div>
<form method="POST" action="{{ route('settings.update') }}" enctype="multipart/form-data" class="space-y-5">
    @csrf
    @method('PUT')

    <section class="rounded-xl bg-white p-5 shadow-sm">
        <h2 class="mb-4 text-lg font-semibold">១. ការកំណត់ហាងទូទៅ</h2>
        <div class="grid gap-4 md:grid-cols-2">
            <label class="block text-sm">ឈ្មោះហាង<input name="store_name" value="{{ old('store_name', $settings['store_name']) }}" maxlength="255" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">ឈ្មោះប្រព័ន្ធ<input name="system_name" required value="{{ old('system_name', $settings['system_name']) }}" maxlength="255" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm md:col-span-2">អាសយដ្ឋាន<textarea name="store_address" rows="2" maxlength="1000" class="mt-1 w-full rounded-lg border-slate-300">{{ old('store_address', $settings['store_address']) }}</textarea></label>
            <label class="block text-sm">លេខទូរសព្ទ<input name="phone_number" value="{{ old('phone_number', $settings['phone_number']) }}" maxlength="40" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">អ៊ីមែល<input name="email" type="email" value="{{ old('email', $settings['email']) }}" maxlength="255" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">គេហទំព័រ<input name="website" type="url" value="{{ old('website', $settings['website']) }}" maxlength="255" placeholder="https://" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">ភាសាលំនាំដើម<select name="default_language" class="mt-1 w-full rounded-lg border-slate-300"><option value="km" selected>ខ្មែរ</option></select></label>
            <label class="block text-sm">តំបន់ម៉ោង<select name="timezone" required class="mt-1 w-full rounded-lg border-slate-300">@foreach($timezones as $timezone)<option value="{{ $timezone }}" @selected(old('timezone', $settings['timezone']) === $timezone)>{{ $timezone }}</option>@endforeach</select></label>
            <label class="block text-sm">ទម្រង់កាលបរិច្ឆេទ<select name="date_format" class="mt-1 w-full rounded-lg border-slate-300">@foreach(['d/m/Y', 'Y-m-d', 'd-m-Y'] as $format)<option value="{{ $format }}" @selected(old('date_format', $settings['date_format']) === $format)>{{ $format }}</option>@endforeach</select></label>
            <label class="block text-sm">ទម្រង់ម៉ោង<select name="time_format" class="mt-1 w-full rounded-lg border-slate-300">@foreach(['H:i', 'h:i A', 'H:i:s'] as $format)<option value="{{ $format }}" @selected(old('time_format', $settings['time_format']) === $format)>{{ now()->format($format) }}</option>@endforeach</select></label>
        </div>
    </section>

    <section class="rounded-xl bg-white p-5 shadow-sm">
        <h2 class="mb-4 text-lg font-semibold">២. រូបិយប័ណ្ណ និងទម្រង់លេខ</h2>
        <p class="mb-3 text-sm text-slate-500">តម្លៃផលិតផលគោលជា USD។ រូបិយប័ណ្ណ និងអត្រាប្តូរត្រូវបានរក្សាទុកជាមួយប្រតិបត្តិការថ្មី ដោយមិនកែប្រែប្រវត្តិចាស់។ 1 USD = អត្រា KHR ដែលកំណត់ខាងក្រោម។</p>
        <div class="grid gap-4 md:grid-cols-2">
            <label class="block text-sm">រូបិយប័ណ្ណលំនាំដើម<select name="currency_code" id="currency-code" class="mt-1 w-full rounded-lg border-slate-300"><option value="USD" @selected(old('currency_code', $settings['currency_code']) === 'USD')>USD ($)</option><option value="KHR" @selected(old('currency_code', $settings['currency_code']) === 'KHR')>KHR (៛)</option></select></label>
            <label class="block text-sm">និមិត្តសញ្ញារូបិយប័ណ្ណ<input id="currency-symbol" value="{{ old('currency_code', $settings['currency_code']) === 'KHR' ? '៛' : '$' }}" readonly class="mt-1 w-full rounded-lg border-slate-300 bg-slate-50"></label>
            <label class="block text-sm">អត្រាប្តូរ USD → KHR<input name="exchange_rate" type="number" step="0.0001" min="0.0001" value="{{ old('exchange_rate', $settings['exchange_rate']) }}" class="mt-1 w-full rounded-lg border-slate-300"><span class="text-xs text-slate-500">ត្រូវបំពេញពេលរូបិយប័ណ្ណលំនាំដើមជា KHR។</span></label>
            <label class="block text-sm">សញ្ញាទសភាគ<input name="decimal_separator" maxlength="1" required value="{{ old('decimal_separator', $settings['decimal_separator']) }}" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">សញ្ញាបំបែកខ្ទង់ពាន់<input name="thousands_separator" maxlength="1" required value="{{ old('thousands_separator', $settings['thousands_separator']) }}" class="mt-1 w-full rounded-lg border-slate-300"></label>
        </div>
    </section>

    <section class="rounded-xl bg-white p-5 shadow-sm">
        <h2 class="mb-4 text-lg font-semibold">៣. ការកំណត់សារពើភ័ណ្ឌ</h2>
        <div class="grid gap-4 md:grid-cols-2">
            <label class="block text-sm">ស្តុកអប្បបរមាលំនាំដើម<input name="default_minimum_stock" type="number" step="0.001" min="0" required value="{{ old('default_minimum_stock', $settings['default_minimum_stock']) }}" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">ឯកតាផលិតផលលំនាំដើម<input name="default_product_unit" required maxlength="30" value="{{ old('default_product_unit', $settings['default_product_unit']) }}" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">បុព្វបទ SKU<input name="sku_prefix" required maxlength="20" value="{{ old('sku_prefix', $settings['sku_prefix']) }}" class="mt-1 w-full rounded-lg border-slate-300"></label>
            @foreach(['allow_negative_stock' => 'អនុញ្ញាតស្តុកអវិជ្ជមាន', 'low_stock_alert' => 'ជូនដំណឹងស្តុកជិតអស់', 'out_of_stock_alert' => 'ជូនដំណឹងអស់ស្តុក', 'auto_generate_sku' => 'បង្កើត SKU ដោយស្វ័យប្រវត្តិពេលទុកទទេ', 'auto_generate_barcode' => 'បង្កើត Barcode ដោយស្វ័យប្រវត្តិ'] as $field => $label)
                <label class="flex items-center gap-2 text-sm"><input type="hidden" name="{{ $field }}" value="0"><input type="checkbox" name="{{ $field }}" value="1" @checked(old($field, $settings[$field])) class="rounded border-slate-300"> {{ $label }}</label>
            @endforeach
        </div>
    </section>

    <section class="rounded-xl bg-white p-5 shadow-sm">
        <h2 class="mb-4 text-lg font-semibold">៤. ការលក់ និង POS</h2>
        <div class="grid gap-4 md:grid-cols-2">
            <label class="block text-sm">បុព្វបទវិក្កយបត្រ<input name="invoice_prefix" required maxlength="20" value="{{ old('invoice_prefix', $settings['invoice_prefix']) }}" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">លេខរៀងវិក្កយបត្រ<select name="invoice_numbering" class="mt-1 w-full rounded-lg border-slate-300"><option value="date_random" @selected(old('invoice_numbering', $settings['invoice_numbering']) === 'date_random')>កាលបរិច្ឆេទ និងលេខចៃដន្យ</option><option value="sequential" @selected(old('invoice_numbering', $settings['invoice_numbering']) === 'sequential')>លេខរៀងតាមថ្ងៃ</option></select></label>
            <label class="block text-sm">អតិថិជនលំនាំដើម<input name="default_customer" required maxlength="255" value="{{ old('default_customer', $settings['default_customer']) }}" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">អត្រាពន្ធ (%)<input name="tax_rate" type="number" min="0" max="100" step="0.01" required value="{{ old('tax_rate', $settings['tax_rate']) }}" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">ទំហំក្រដាសបង្កាន់ដៃ<select name="receipt_paper_size" class="mt-1 w-full rounded-lg border-slate-300">@foreach(['58mm', '80mm', 'A4'] as $size)<option value="{{ $size }}" @selected(old('receipt_paper_size', $settings['receipt_paper_size']) === $size)>{{ $size }}</option>@endforeach</select></label>
            @foreach(['tax_enabled' => 'បើកពន្ធលើការលក់', 'discounts_allowed' => 'អនុញ្ញាតការបញ្ចុះតម្លៃ', 'print_receipt_automatically' => 'បោះពុម្ពបង្កាន់ដៃដោយស្វ័យប្រវត្តិ'] as $field => $label)
                <label class="flex items-center gap-2 text-sm"><input type="hidden" name="{{ $field }}" value="0"><input type="checkbox" name="{{ $field }}" value="1" @checked(old($field, $settings[$field])) class="rounded border-slate-300"> {{ $label }}</label>
            @endforeach
            <label class="block text-sm md:col-span-2">សារបាតកថាបង្កាន់ដៃ<textarea name="receipt_footer" rows="2" maxlength="1000" class="mt-1 w-full rounded-lg border-slate-300">{{ old('receipt_footer', $settings['receipt_footer']) }}</textarea></label>
        </div>
    </section>

    <section class="rounded-xl bg-white p-5 shadow-sm">
        <h2 class="mb-4 text-lg font-semibold">៥. ការកំណត់ការទិញ</h2>
        <div class="grid gap-4 md:grid-cols-2">
            <label class="block text-sm">បុព្វបទបញ្ជាទិញ<input name="purchase_order_prefix" required maxlength="20" value="{{ old('purchase_order_prefix', $settings['purchase_order_prefix']) }}" class="mt-1 w-full rounded-lg border-slate-300"></label>
            <label class="block text-sm">លេខរៀងបញ្ជាទិញ<select name="purchase_order_numbering" class="mt-1 w-full rounded-lg border-slate-300"><option value="date_random" @selected(old('purchase_order_numbering', $settings['purchase_order_numbering']) === 'date_random')>កាលបរិច្ឆេទ និងលេខចៃដន្យ</option><option value="sequential" @selected(old('purchase_order_numbering', $settings['purchase_order_numbering']) === 'sequential')>លេខរៀងតាមថ្ងៃ</option></select></label>
            <label class="block text-sm">ស្ថានភាពបញ្ជាទិញលំនាំដើម<select name="default_purchase_status" class="mt-1 w-full rounded-lg border-slate-300"><option value="draft" @selected(old('default_purchase_status', $settings['default_purchase_status']) === 'draft')>សេចក្តីព្រាង</option><option value="pending" @selected(old('default_purchase_status', $settings['default_purchase_status']) === 'pending')>កំពុងរង់ចាំ</option></select></label>
            <label class="block text-sm">ទំហំក្រដាសបញ្ជាទិញ<select name="purchase_receipt_paper_size" class="mt-1 w-full rounded-lg border-slate-300"><option value="A4" @selected(old('purchase_receipt_paper_size', $settings['purchase_receipt_paper_size']) === 'A4')>A4</option><option value="80mm" @selected(old('purchase_receipt_paper_size', $settings['purchase_receipt_paper_size']) === '80mm')>80mm</option></select></label>
        </div>
    </section>

    <section class="rounded-xl bg-white p-5 shadow-sm">
        <h2 class="mb-4 text-lg font-semibold">៦. រូបសញ្ញា និងម៉ាកហាង</h2>
        <div class="grid gap-4 md:grid-cols-2">
            <div>
                <label for="store-logo" class="block text-sm">រូបសញ្ញាហាង (JPG, PNG, WEBP; អតិបរមា 2MB)</label>
                <input id="store-logo" name="store_logo" type="file" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" class="mt-1 block w-full text-sm">
                <img id="store-logo-preview" src="{{ $settings['store_logo'] ? asset('storage/'.$settings['store_logo']) : '' }}" alt="រូបសញ្ញាហាង" class="{{ $settings['store_logo'] ? 'mt-3 h-24 max-w-48 object-contain' : 'mt-3 hidden h-24 max-w-48 object-contain' }}">
                @if($settings['store_logo'])
                    <button type="button" id="remove-logo" data-url="{{ route('settings.logo.destroy') }}" class="mt-3 rounded-lg border border-red-300 px-3 py-2 text-sm text-red-700">លុបរូបសញ្ញា</button>
                @endif
            </div>
            <div class="flex items-end"><button type="submit" class="rounded-lg bg-blue-700 px-5 py-3 font-semibold text-white hover:bg-blue-800">រក្សាទុកការកំណត់ទាំងអស់</button></div>
        </div>
    </section>
</form>
<script>
const logoInput=document.getElementById('store-logo'),logoPreview=document.getElementById('store-logo-preview');
logoInput?.addEventListener('change',()=>{const file=logoInput.files?.[0];if(file){logoPreview.src=URL.createObjectURL(file);logoPreview.classList.remove('hidden')}});
document.getElementById('currency-code')?.addEventListener('change',event=>{document.getElementById('currency-symbol').value=event.target.value==='KHR'?'៛':'$'});
document.getElementById('remove-logo')?.addEventListener('click',async event=>{if(!confirm('តើអ្នកប្រាកដថាចង់លុបរូបសញ្ញានេះឬ?'))return;const response=await fetch(event.currentTarget.dataset.url,{method:'DELETE',headers:{'X-CSRF-TOKEN':document.querySelector('meta[name="csrf-token"]').content,'Accept':'application/json'}});if(response.ok)location.reload();else alert('មិនអាចលុបរូបសញ្ញាបានទេ។ សូមព្យាយាមម្ដងទៀត។')});
</script>
@endsection
