@extends('layouts.app')
@section('title', 'កែសម្រួលតួនាទី')
@section('content')
<h1 class="text-2xl font-bold">កែសម្រួលតួនាទី: {{ $role->name }}</h1>
<form method="POST" action="{{ route('roles.update', $role) }}" class="mt-5 max-w-4xl rounded-xl bg-white p-5 shadow-sm">
    @csrf @method('PUT')
    <div class="grid gap-4 md:grid-cols-2">
        <div><label class="mb-1 block text-sm">ឈ្មោះតួនាទី</label><input name="name" required value="{{ old('name', $role->name) }}" class="w-full rounded-lg border-slate-300"></div>
        <div><label class="mb-1 block text-sm">ស្ថានភាព</label><select name="is_active" class="w-full rounded-lg border-slate-300"><option value="1" @selected(old('is_active', $role->is_active) == 1)>សកម្ម</option><option value="0" @selected(old('is_active', $role->is_active) == 0)>អសកម្ម</option></select></div>
        <div class="md:col-span-2"><label class="mb-1 block text-sm">ការពិពណ៌នា</label><textarea name="description" rows="3" class="w-full rounded-lg border-slate-300">{{ old('description', $role->description) }}</textarea></div>
    </div>
    <fieldset class="mt-6">
        <legend class="font-semibold">សិទ្ធិប្រើប្រាស់</legend>
        <div class="mt-3 grid gap-5 md:grid-cols-2">
        @foreach($permissions as $group => $items)
            <div class="rounded-lg border p-4">
                <h2 class="mb-2 font-medium capitalize">{{ $group ?: 'ផ្សេងៗ' }}</h2>
                @foreach($items as $permission)
                    <label class="mb-2 flex items-center gap-2 text-sm">
                        <input type="checkbox" name="permissions[]" value="{{ $permission->id }}" @checked($role->permissions->contains($permission->id)) class="rounded border-slate-300">
                        {{ $permission->name }}
                    </label>
                @endforeach
            </div>
        @endforeach
        </div>
    </fieldset>
    <div class="mt-6 flex gap-3"><button class="rounded-lg bg-blue-700 px-4 py-2 text-white">រក្សាទុក</button><a href="{{ route('roles.index') }}" class="rounded-lg border px-4 py-2">បោះបង់</a></div>
</form>
@endsection
