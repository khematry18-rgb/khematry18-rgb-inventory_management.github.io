@extends('layouts.app')
@section('title', 'តួនាទី និងសិទ្ធិ')
@section('content')
<h1 class="text-2xl font-bold">តួនាទី និងសិទ្ធិ</h1>
<div class="mt-5 grid gap-4 md:grid-cols-3">
@foreach($roles as $role)
    <div class="rounded-xl bg-white p-5 shadow-sm">
        <div class="flex items-center justify-between">
            <h2 class="text-lg font-bold">{{ $role->name }}</h2>
            <span class="rounded-full px-2 py-1 text-xs {{ $role->is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' }}">{{ $role->is_active ? 'សកម្ម' : 'អសកម្ម' }}</span>
        </div>
        <p class="mt-2 text-sm text-slate-500">{{ $role->permissions_count }} សិទ្ធិ</p>
        <a href="{{ route('roles.edit', $role) }}" class="mt-4 inline-block rounded-lg border border-blue-700 px-3 py-2 text-sm text-blue-700 hover:bg-blue-50">កែសម្រួលសិទ្ធិ</a>
    </div>
@endforeach
</div>
@endsection
