@extends('layouts.app')
@section('title', 'ព័ត៌មានប្រភេទផលិតផល')
@section('content')
<div class="grid gap-5 lg:grid-cols-3">
    <div class="rounded-xl bg-white p-6 shadow-sm lg:col-span-1">
        <div class="flex items-start justify-between gap-3">
            <h1 class="text-2xl font-bold text-slate-900">{{ $category->name }}</h1>
            <span class="rounded-full px-2 py-1 text-xs {{ $category->is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' }}">
                {{ $category->is_active ? 'សកម្ម' : 'អសកម្ម' }}
            </span>
        </div>
        <dl class="mt-5 space-y-4">
            <div><dt class="text-sm text-slate-500">ស្លក URL</dt><dd class="mt-1 font-mono text-sm">{{ $category->slug }}</dd></div>
            <div><dt class="text-sm text-slate-500">សេចក្តីពណ៌នា</dt><dd class="mt-1 whitespace-pre-line">{{ $category->description ?: '—' }}</dd></div>
            <div><dt class="text-sm text-slate-500">ចំនួនផលិតផល</dt><dd class="mt-1">{{ number_format($category->products_count) }}</dd></div>
            <div><dt class="text-sm text-slate-500">កាលបរិច្ឆេទបង្កើត</dt><dd class="mt-1">{{ app(\App\Services\SystemSettingsService::class)->formatDate($category->created_at, true) }}</dd></div>
        </dl>
        <div class="mt-6 flex flex-wrap gap-3">
            <a href="{{ route('categories.edit', $category) }}" class="rounded-lg bg-blue-700 px-4 py-2 text-white">កែសម្រួល</a>
            <a href="{{ route('categories.index') }}" class="rounded-lg border border-slate-300 px-4 py-2">ត្រឡប់ក្រោយ</a>
        </div>
    </div>

    <div class="rounded-xl bg-white p-6 shadow-sm lg:col-span-2">
        <h2 class="text-lg font-semibold">ផលិតផលក្នុងប្រភេទ</h2>
        <div class="mt-4 overflow-x-auto">
            <table class="min-w-full divide-y">
                <thead class="bg-slate-50"><tr><th class="px-3 py-3 text-left text-sm">SKU</th><th class="px-3 py-3 text-left text-sm">ឈ្មោះ</th><th class="px-3 py-3 text-left text-sm">ស្តុក</th></tr></thead>
                <tbody class="divide-y">
                @forelse($category->products as $product)
                    <tr><td class="px-3 py-3 font-mono text-sm">{{ $product->sku }}</td><td class="px-3 py-3">{{ $product->name }}</td><td class="px-3 py-3">{{ number_format((float) $product->stock_quantity, 3) }} {{ $product->unit }}</td></tr>
                @empty
                    <tr><td colspan="3" class="px-3 py-8 text-center text-slate-500">មិនទាន់មានផលិតផលក្នុងប្រភេទនេះ</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
