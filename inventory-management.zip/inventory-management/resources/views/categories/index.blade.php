@extends('layouts.app')
@section('title', 'ប្រភេទផលិតផល')
@section('content')
<div class="flex flex-wrap items-center justify-between gap-3">
    <div>
        <h1 class="text-2xl font-bold text-slate-900">បញ្ជីប្រភេទផលិតផល</h1>
        <p class="mt-1 text-sm text-slate-500">ស្វែងរក និងគ្រប់គ្រងប្រភេទដែលមាននៅក្នុងប្រព័ន្ធ</p>
    </div>
    <a href="{{ route('categories.create') }}" class="rounded-lg bg-blue-700 px-4 py-2 text-white hover:bg-blue-800">បង្កើតប្រភេទថ្មី</a>
</div>

<form method="GET" class="mt-5 grid gap-3 rounded-xl bg-white p-4 shadow-sm md:grid-cols-4">
    <input type="search" name="search" value="{{ request('search') }}" placeholder="ស្វែងរកឈ្មោះ ស្លក ឬសេចក្តីពណ៌នា" class="rounded-lg border-slate-300 md:col-span-2">
    <select name="is_active" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់ស្ថានភាព --</option>
        <option value="1" @selected(request('is_active') === '1')>សកម្ម</option>
        <option value="0" @selected(request('is_active') === '0')>អសកម្ម</option>
    </select>
    <div class="flex gap-2">
        <button type="submit" class="flex-1 rounded-lg bg-slate-700 px-4 py-2 text-white">ស្វែងរក</button>
        <a href="{{ route('categories.index') }}" class="rounded-lg border border-slate-300 px-4 py-2 text-slate-700">សម្អាត</a>
    </div>
</form>

<div class="mt-5 overflow-x-auto rounded-xl bg-white shadow-sm">
    <table class="min-w-full divide-y divide-slate-200">
        <thead class="bg-slate-50">
            <tr>
                <th class="px-4 py-3 text-left text-sm text-slate-600">ឈ្មោះប្រភេទ</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">ស្លក URL</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">ផលិតផល</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">ស្ថានភាព</th>
                <th class="px-4 py-3 text-right text-sm text-slate-600">សកម្មភាព</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
        @forelse($categories as $category)
            <tr>
                <td class="px-4 py-3">
                    <a href="{{ route('categories.show', $category) }}" class="font-medium text-blue-700 hover:text-blue-900">{{ $category->name }}</a>
                </td>
                <td class="px-4 py-3 font-mono text-sm text-slate-600">{{ $category->slug }}</td>
                <td class="px-4 py-3">{{ number_format($category->products_count) }}</td>
                <td class="px-4 py-3">
                    <span class="rounded-full px-2 py-1 text-xs {{ $category->is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' }}">
                        {{ $category->is_active ? 'សកម្ម' : 'អសកម្ម' }}
                    </span>
                </td>
                <td class="px-4 py-3 text-right">
                    <a href="{{ route('categories.edit', $category) }}" class="text-blue-700 hover:text-blue-900">កែសម្រួល</a>
                    <form method="POST" action="{{ route('categories.destroy', $category) }}" class="inline"
                        onsubmit="return confirm('តើអ្នកពិតជាចង់លុបប្រភេទ {{ addslashes($category->name) }} មែនទេ? ប្រភេទដែលមានផលិតផលនឹងមិនអាចលុបបានទេ។')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="ml-3 text-red-700 hover:text-red-900">លុប</button>
                    </form>
                </td>
            </tr>
        @empty
            <tr><td colspan="5" class="px-4 py-8 text-center text-slate-500">មិនមានទិន្នន័យប្រភេទ</td></tr>
        @endforelse
        </tbody>
    </table>
</div>
<div class="mt-4">{{ $categories->links() }}</div>
@endsection
