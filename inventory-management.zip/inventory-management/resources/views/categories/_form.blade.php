<form method="POST" action="{{ $action }}" class="mt-5 max-w-3xl rounded-xl bg-white p-5 shadow-sm">
    @csrf
    @if($method !== 'POST') @method($method) @endif

    <div class="grid gap-4 md:grid-cols-2">
        <div class="md:col-span-2">
            <label for="name" class="mb-1 block text-sm font-medium">ឈ្មោះប្រភេទ <span class="text-red-600">*</span></label>
            <input id="name" name="name" required maxlength="255" value="{{ old('name', $category?->name) }}"
                class="w-full rounded-lg border-slate-300 focus:border-blue-600 focus:ring-blue-600">
            @error('name')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
        </div>

        <div class="md:col-span-2">
            <label for="description" class="mb-1 block text-sm font-medium">សេចក្តីពណ៌នា</label>
            <textarea id="description" name="description" rows="5" maxlength="5000"
                class="w-full rounded-lg border-slate-300 focus:border-blue-600 focus:ring-blue-600">{{ old('description', $category?->description) }}</textarea>
            @error('description')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
        </div>

        <div>
            <label for="is_active" class="mb-1 block text-sm font-medium">ស្ថានភាព</label>
            <select id="is_active" name="is_active" required class="w-full rounded-lg border-slate-300">
                <option value="1" @selected((string) old('is_active', $category?->is_active ?? 1) === '1')>សកម្ម</option>
                <option value="0" @selected((string) old('is_active', $category?->is_active ?? 1) === '0')>អសកម្ម</option>
            </select>
            @error('is_active')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
        </div>
    </div>

    <div class="mt-6 flex flex-wrap gap-3">
        <button type="submit" class="rounded-lg bg-blue-700 px-4 py-2 text-white hover:bg-blue-800">រក្សាទុក</button>
        <a href="{{ route('categories.index') }}" class="rounded-lg border border-slate-300 px-4 py-2 text-slate-700 hover:bg-slate-50">បោះបង់</a>
    </div>
</form>
