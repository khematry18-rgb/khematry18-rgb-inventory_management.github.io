@extends('layouts.app')
@section('title', 'បង្កើតប្រភេទផលិតផល')
@section('content')
<div>
    <h1 class="text-2xl font-bold text-slate-900">បង្កើតប្រភេទផលិតផល</h1>
    <p class="mt-1 text-sm text-slate-500">បំពេញព័ត៌មានប្រភេទថ្មី</p>
</div>
@include('categories._form', [
    'action' => route('categories.store'),
    'method' => 'POST',
    'category' => null,
])
@endsection
