@extends('layouts.app')
@section('title', 'កែសម្រួលប្រភេទផលិតផល')
@section('content')
<div>
    <h1 class="text-2xl font-bold text-slate-900">កែសម្រួលប្រភេទផលិតផល</h1>
    <p class="mt-1 text-sm text-slate-500">{{ $category->name }}</p>
</div>
@include('categories._form', [
    'action' => route('categories.update', $category),
    'method' => 'PUT',
    'category' => $category,
])
@endsection
