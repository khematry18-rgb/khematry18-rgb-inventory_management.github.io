@extends('layouts.app')
@section('title', 'កែសម្រួលអ្នកផ្គត់ផ្គង់')
@section('content')
<div><h1 class="text-2xl font-bold text-slate-900">កែសម្រួលអ្នកផ្គត់ផ្គង់</h1><p class="mt-1 text-sm text-slate-500">{{ $supplier->name }}</p></div>
@include('suppliers._form', ['action' => route('suppliers.update', $supplier), 'method' => 'PUT', 'supplier' => $supplier])
@endsection
