@extends('layouts.app')
@section('title', 'បង្កើតអ្នកផ្គត់ផ្គង់')
@section('content')
<div><h1 class="text-2xl font-bold text-slate-900">បង្កើតអ្នកផ្គត់ផ្គង់</h1><p class="mt-1 text-sm text-slate-500">បំពេញព័ត៌មានអ្នកផ្គត់ផ្គង់ថ្មី</p></div>
@include('suppliers._form', ['action' => route('suppliers.store'), 'method' => 'POST', 'supplier' => null])
@endsection
