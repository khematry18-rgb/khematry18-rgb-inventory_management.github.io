@extends('layouts.app')
@section('title', 'ព័ត៌មានអ្នកផ្គត់ផ្គង់')
@section('content')
<div class="flex flex-wrap items-center justify-between gap-3">
    <div><h1 class="text-2xl font-bold text-slate-900">{{ $supplier->name }}</h1><p class="mt-1 text-sm text-slate-500">{{ $supplier->company_name ?: 'អ្នកផ្គត់ផ្គង់' }}</p></div>
    <a href="{{ route('suppliers.edit', $supplier) }}" class="rounded-lg bg-blue-700 px-4 py-2 text-white">កែសម្រួល</a>
</div>

<div class="mt-5 grid gap-5 lg:grid-cols-3">
    <section class="rounded-xl bg-white p-5 shadow-sm lg:col-span-2">
        <h2 class="font-semibold text-slate-900">ព័ត៌មានទំនាក់ទំនង</h2>
        <dl class="mt-4 grid gap-4 sm:grid-cols-2">
            <div><dt class="text-sm text-slate-500">អ្នកទំនាក់ទំនង</dt><dd class="mt-1">{{ $supplier->contact_person ?: '—' }}</dd></div>
            <div><dt class="text-sm text-slate-500">លេខទូរស័ព្ទ</dt><dd class="mt-1">{{ $supplier->phone ?: '—' }}</dd></div>
            <div><dt class="text-sm text-slate-500">អ៊ីមែល</dt><dd class="mt-1">{{ $supplier->email ?: '—' }}</dd></div>
            <div><dt class="text-sm text-slate-500">លេខអត្តសញ្ញាណពន្ធ</dt><dd class="mt-1">{{ $supplier->tax_id ?: '—' }}</dd></div>
            <div><dt class="text-sm text-slate-500">ទីក្រុង</dt><dd class="mt-1">{{ $supplier->city ?: '—' }}</dd></div>
            <div><dt class="text-sm text-slate-500">ប្រទេស</dt><dd class="mt-1">{{ $supplier->country ?: '—' }}</dd></div>
            <div class="sm:col-span-2"><dt class="text-sm text-slate-500">អាសយដ្ឋាន</dt><dd class="mt-1 whitespace-pre-line">{{ $supplier->address ?: '—' }}</dd></div>
            <div class="sm:col-span-2"><dt class="text-sm text-slate-500">កំណត់ចំណាំ</dt><dd class="mt-1 whitespace-pre-line">{{ $supplier->notes ?: '—' }}</dd></div>
        </dl>
    </section>
    <section class="rounded-xl bg-white p-5 shadow-sm">
        <h2 class="font-semibold text-slate-900">ស្ថិតិការទិញ</h2>
        <div class="mt-4 space-y-3">
            <div class="flex justify-between"><span class="text-slate-500">ការទិញសរុប</span><strong>{{ $supplier->purchases_count }}</strong></div>
            <div class="flex justify-between gap-3"><span class="text-slate-500">តម្លៃបានបញ្ជាក់</span><strong class="text-right">@forelse($totalPurchaseAmounts as $currency => $amount){{ app(\App\Services\SystemSettingsService::class)->formatAmount((float) $amount->total, $currency) }}@if(!$loop->last)<br>@endif @empty—@endforelse</strong></div>
            <div class="flex justify-between"><span class="text-slate-500">ស្ថានភាព</span><strong>{{ $supplier->is_active ? 'សកម្ម' : 'អសកម្ម' }}</strong></div>
        </div>
    </section>
</div>

<section class="mt-5 rounded-xl bg-white p-5 shadow-sm">
    <h2 class="font-semibold text-slate-900">ប្រវត្តិការទិញថ្មីៗ</h2>
    <div class="mt-4 overflow-x-auto">
        <table class="min-w-full divide-y divide-slate-200">
            <thead><tr><th class="px-3 py-2 text-left text-sm text-slate-600">លេខការទិញ</th><th class="px-3 py-2 text-left text-sm text-slate-600">កាលបរិច្ឆេទ</th><th class="px-3 py-2 text-left text-sm text-slate-600">ស្ថានភាព</th><th class="px-3 py-2 text-right text-sm text-slate-600">សរុប</th></tr></thead>
            <tbody class="divide-y divide-slate-100">
            @forelse($recentPurchases as $purchase)
                <tr><td class="px-3 py-3">{{ $purchase->purchase_number }}</td><td class="px-3 py-3">{{ app(\App\Services\SystemSettingsService::class)->formatDate($purchase->purchased_at) }}</td><td class="px-3 py-3">{{ $purchase->status }}</td><td class="px-3 py-3 text-right">{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float) $purchase->grand_total, $purchase->currency ?: 'USD') }}</td></tr>
            @empty
                <tr><td colspan="4" class="px-3 py-6 text-center text-slate-500">មិនទាន់មានប្រវត្តិការទិញ</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
</section>
@endsection
