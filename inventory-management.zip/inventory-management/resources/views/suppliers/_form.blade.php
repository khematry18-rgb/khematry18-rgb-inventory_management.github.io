<form method="POST" action="{{ $action }}" class="mt-5 max-w-4xl rounded-xl bg-white p-5 shadow-sm">
    @csrf
    @if($method !== 'POST') @method($method) @endif

    <div class="grid gap-4 md:grid-cols-2">
        <div>
            <label for="name" class="mb-1 block text-sm font-medium">ឈ្មោះអ្នកផ្គត់ផ្គង់ <span class="text-red-600">*</span></label>
            <input id="name" name="name" required maxlength="255" value="{{ old('name', $supplier?->name) }}" class="w-full rounded-lg border-slate-300">
            @error('name')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
        </div>
        <div>
            <label for="company_name" class="mb-1 block text-sm font-medium">ឈ្មោះក្រុមហ៊ុន</label>
            <input id="company_name" name="company_name" maxlength="255" value="{{ old('company_name', $supplier?->company_name) }}" class="w-full rounded-lg border-slate-300">
        </div>
        <div>
            <label for="contact_person" class="mb-1 block text-sm font-medium">អ្នកទំនាក់ទំនង</label>
            <input id="contact_person" name="contact_person" maxlength="255" value="{{ old('contact_person', $supplier?->contact_person) }}" class="w-full rounded-lg border-slate-300">
        </div>
        <div>
            <label for="phone" class="mb-1 block text-sm font-medium">លេខទូរស័ព្ទ</label>
            <input id="phone" name="phone" maxlength="30" value="{{ old('phone', $supplier?->phone) }}" class="w-full rounded-lg border-slate-300">
            @error('phone')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
        </div>
        <div>
            <label for="email" class="mb-1 block text-sm font-medium">អ៊ីមែល</label>
            <input id="email" type="email" name="email" maxlength="255" value="{{ old('email', $supplier?->email) }}" class="w-full rounded-lg border-slate-300">
            @error('email')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
        </div>
        <div>
            <label for="tax_id" class="mb-1 block text-sm font-medium">លេខអត្តសញ្ញាណពន្ធ</label>
            <input id="tax_id" name="tax_id" maxlength="100" value="{{ old('tax_id', $supplier?->tax_id) }}" class="w-full rounded-lg border-slate-300">
        </div>
        <div>
            <label for="city" class="mb-1 block text-sm font-medium">ទីក្រុង</label>
            <input id="city" name="city" maxlength="255" value="{{ old('city', $supplier?->city) }}" class="w-full rounded-lg border-slate-300">
        </div>
        <div>
            <label for="country" class="mb-1 block text-sm font-medium">ប្រទេស</label>
            <input id="country" name="country" maxlength="255" value="{{ old('country', $supplier?->country) }}" class="w-full rounded-lg border-slate-300">
        </div>
        <div class="md:col-span-2">
            <label for="address" class="mb-1 block text-sm font-medium">អាសយដ្ឋាន</label>
            <textarea id="address" name="address" rows="3" maxlength="5000" class="w-full rounded-lg border-slate-300">{{ old('address', $supplier?->address) }}</textarea>
        </div>
        <div class="md:col-span-2">
            <label for="notes" class="mb-1 block text-sm font-medium">កំណត់ចំណាំ</label>
            <textarea id="notes" name="notes" rows="3" maxlength="5000" class="w-full rounded-lg border-slate-300">{{ old('notes', $supplier?->notes) }}</textarea>
        </div>
        <div>
            <label for="is_active" class="mb-1 block text-sm font-medium">ស្ថានភាព</label>
            <select id="is_active" name="is_active" required class="w-full rounded-lg border-slate-300">
                <option value="1" @selected((string) old('is_active', $supplier?->is_active ?? 1) === '1')>សកម្ម</option>
                <option value="0" @selected((string) old('is_active', $supplier?->is_active ?? 0) === '0')>អសកម្ម</option>
            </select>
            @error('is_active')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
        </div>
    </div>

    <div class="mt-6 flex flex-wrap gap-3">
        <button type="submit" class="rounded-lg bg-blue-700 px-4 py-2 text-white hover:bg-blue-800">រក្សាទុក</button>
        <a href="{{ route('suppliers.index') }}" class="rounded-lg border border-slate-300 px-4 py-2 text-slate-700 hover:bg-slate-50">បោះបង់</a>
    </div>
</form>
