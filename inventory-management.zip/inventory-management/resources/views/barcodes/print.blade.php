@extends('layouts.app')
@section('title', 'បោះពុម្ពស្លាក Barcode')
@section('content')
<style>
    @page { size: A4; margin: 8mm; }
    @media print {
        body { background: #fff !important; }
        aside, header, .no-print { display: none !important; }
        main, main > div { padding: 0 !important; margin: 0 !important; }
        .label-grid { gap: 3mm !important; }
        .barcode-label { break-inside: avoid; border: 1px solid #bbb !important; box-shadow: none !important; }
    }
    .label-grid.small { grid-template-columns: repeat(4, minmax(0, 1fr)); }
    .label-grid.medium { grid-template-columns: repeat(3, minmax(0, 1fr)); }
    .label-grid.large { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .barcode-label svg { max-width: 100%; height: auto; }
</style>
<div class="no-print mb-5 flex flex-wrap items-center justify-between gap-3">
    <div>
        <h1 class="text-2xl font-bold">មើលជាមុនស្លាកផលិតផល</h1>
        <p class="mt-1 text-sm text-slate-500">{{ count($labels) }} ស្លាក · ទំហំក្រដាស A4</p>
    </div>
    <div class="flex gap-2">
        <button type="button" onclick="window.print()" class="rounded-lg bg-blue-700 px-4 py-2 text-white">បោះពុម្ព</button>
        <a href="{{ route('barcodes.index') }}" class="rounded-lg border px-4 py-2">ត្រឡប់ក្រោយ</a>
    </div>
</div>
<div class="label-grid {{ $labelSize }} grid gap-3">
    @foreach($labels as $label)
        @php($product = $label['product'])
        <article class="barcode-label flex min-h-44 flex-col items-center justify-between rounded-lg border border-slate-300 bg-white p-3 text-center shadow-sm">
            <div class="w-full">
                <h2 class="line-clamp-2 text-sm font-semibold">{{ $product->name }}</h2>
                <p class="mt-1 font-mono text-xs text-slate-600">SKU: {{ $product->sku }}</p>
            </div>
            <div class="my-2 w-full">
                {!! $label['barcode_svg'] !!}
            </div>
            <div class="flex w-full items-center justify-between gap-2">
                <div class="text-left">
                    <p class="font-mono text-xs">{{ $product->barcode }}</p>
                    <p class="mt-1 text-sm font-bold">{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float) $product->selling_price, 'USD') }}</p>
                </div>
                <div class="h-12 w-12 shrink-0">{!! $label['qr_svg'] !!}</div>
            </div>
        </article>
    @endforeach
</div>
@endsection
