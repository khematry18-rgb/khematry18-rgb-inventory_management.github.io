@extends('layouts.app')
@section('title', 'Barcode និង QR Code')
@section('content')
<div>
    <h1 class="text-2xl font-bold">Barcode និង QR Code</h1>
    <p class="mt-1 text-sm text-slate-500">ជ្រើសផលិតផលដែលមាន Barcode ដើម្បីមើលជាមុន និងបោះពុម្ពស្លាក។</p>
</div>
<form method="GET" class="mt-5 flex flex-wrap gap-2 rounded-xl bg-white p-4 shadow-sm">
    <input type="search" name="search" value="{{ request('search') }}" placeholder="ឈ្មោះ, SKU ឬ Barcode" class="min-w-60 flex-1 rounded-lg border-slate-300">
    <button class="rounded-lg bg-slate-700 px-4 py-2 text-white">ស្វែងរក</button>
    <a href="{{ route('barcodes.index') }}" class="rounded-lg border px-4 py-2">សម្អាត</a>
</form>
<form method="POST" action="{{ route('barcodes.print') }}" target="_blank">
    @csrf
    <div class="mt-4 flex flex-wrap items-end justify-between gap-3 rounded-xl bg-white p-4 shadow-sm">
        <label class="text-sm">ទំហំស្លាក
            <select name="label_size" class="mt-1 block rounded-lg border-slate-300">
                <option value="small">តូច</option>
                <option value="medium" selected>មធ្យម</option>
                <option value="large">ធំ</option>
            </select>
        </label>
        <button class="rounded-lg bg-blue-700 px-4 py-2 text-white">មើលស្លាក និងបោះពុម្ព</button>
    </div>
    @error('product_ids')<p class="mt-3 rounded-lg bg-red-50 p-3 text-sm text-red-700">{{ $message }}</p>@enderror
    <div class="mt-4 overflow-x-auto rounded-xl bg-white shadow-sm">
        <table class="min-w-full divide-y">
            <thead class="bg-slate-50"><tr>
                <th class="px-4 py-3 text-left text-sm">ជ្រើស</th>
                <th class="px-4 py-3 text-left text-sm">ផលិតផល</th>
                <th class="px-4 py-3 text-left text-sm">Barcode</th>
                <th class="px-4 py-3 text-right text-sm">តម្លៃលក់</th>
                <th class="px-4 py-3 text-right text-sm">ចំនួនស្លាក</th>
                <th class="px-4 py-3 text-left text-sm">មើលជាមុន</th>
            </tr></thead>
            <tbody class="divide-y">
                @forelse($products as $product)
                    <tr>
                        <td class="px-4 py-3">
                            @if($product->barcode)
                                <input type="checkbox" name="product_ids[]" value="{{ $product->id }}" class="rounded border-slate-300">
                            @else
                                <span class="text-xs text-slate-400">គ្មាន Barcode</span>
                            @endif
                        </td>
                        <td class="px-4 py-3">
                            <a href="{{ route('products.show', $product) }}" class="font-medium text-blue-700">{{ $product->name }}</a>
                            <div class="font-mono text-xs text-slate-500">SKU: {{ $product->sku }}</div>
                        </td>
                        <td class="px-4 py-3 font-mono text-sm">{{ $product->barcode ?: '—' }}</td>
                        <td class="px-4 py-3 text-right">{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float) $product->selling_price, 'USD') }}</td>
                        <td class="px-4 py-3 text-right">
                            @if($product->barcode)
                                <input type="number" name="quantities[{{ $product->id }}]" min="1" max="100" value="1" class="w-20 rounded-lg border-slate-300 text-right">
                            @elseif(auth()->user()->hasRole('admin') || auth()->user()->hasPermission('products.manage'))
                                <a href="{{ route('products.edit', $product) }}" class="text-sm text-blue-700">បង្កើត Barcode</a>
                            @endif
                        </td>
                        <td class="px-4 py-3">
                            @if($product->barcode)
                                <img src="{{ route('products.barcode', $product) }}" alt="Barcode {{ $product->barcode }}" class="h-12 max-w-48">
                            @endif
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="6" class="px-4 py-8 text-center text-slate-500">មិនមានផលិតផលទេ។</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</form>
<div class="mt-4">{{ $products->links() }}</div>
@endsection
