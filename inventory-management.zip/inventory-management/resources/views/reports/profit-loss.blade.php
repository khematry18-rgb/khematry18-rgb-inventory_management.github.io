@extends('layouts.app')
@section('title','ចំណេញ និងខាត')
@section('content')
@include('reports._filter')
<div class="mt-5 flex items-center justify-between"><h1 class="text-2xl font-bold">របាយការណ៍ចំណេញ និងខាត</h1><div class="flex gap-2"><a href="{{ route('reports.profit-loss.export', request()->query()) }}" class="rounded-lg border px-4 py-2">Export CSV</a><button onclick="window.print()" class="rounded-lg bg-slate-700 px-4 py-2 text-white">បោះពុម្ព</button></div></div>
@forelse($profitLoss['by_currency'] as $currency=>$totals)
<h2 class="mt-5 text-lg font-semibold">រូបិយប័ណ្ណ {{ $currency }}</h2>
<div class="mt-3 grid gap-4 md:grid-cols-2 xl:grid-cols-4">@foreach([['ចំណូលលក់រង',$totals['revenue']],['ថ្លៃដើមទំនិញ',$totals['cogs']],['ចំណេញមូល',$totals['gross_profit']],['បញ្ចុះតម្លៃ',$totals['discounts']],['ពន្ធដែលបានប្រមូល',$totals['tax']]] as $card)<div class="rounded-xl bg-white p-5 shadow-sm"><div class="text-sm text-slate-500">{{ $card[0] }}</div><div class="mt-2 text-2xl font-bold">{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$card[1], $currency) }}</div></div>@endforeach<div class="rounded-xl bg-white p-5 shadow-sm"><div class="text-sm text-slate-500">ចំណេញសុទ្ធ</div><div class="mt-2 text-xl font-bold">មិនអាចគណនាបាន</div></div></div>
@empty
<div class="mt-5 rounded-xl bg-white p-8 text-center text-slate-500">មិនមានទិន្នន័យលក់សម្រាប់គណនា។</div>
@endforelse
<div class="mt-5 rounded-xl border border-blue-200 bg-blue-50 p-5 text-blue-900"><strong>ការពន្យល់៖</strong> COGS គណនាពីតម្លៃដើមដែលបានរក្សាទុកនៅលើ Sale Item នៅពេលលក់។ ពន្ធដែលប្រមូលមិនត្រូវបានចាត់ទុកជាចំណូលអាជីវកម្ម។ ចំណេញសុទ្ធមិនអាចគណនាដោយស្មើរ ព្រោះប្រព័ន្ធមិនទាន់មានទិន្នន័យការចំណាយប្រតិបត្តិការសរុប។</div>
@if($profitLoss['unknown_cost_items']>0)<div class="mt-4 rounded-xl border border-yellow-200 bg-yellow-50 p-4 text-yellow-900">មាន {{ $profitLoss['unknown_cost_items'] }} Sale Item ដែលគ្មានតម្លៃដើមតាមប្រវត្តិ។ COGS អាចមិនពេញលេញសម្រាប់ប្រតិបត្តិការខ្លះ។</div>@endif
@endsection
