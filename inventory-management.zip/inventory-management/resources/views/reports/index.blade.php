@extends('layouts.app')
@section('title','របាយការណ៍')
@section('content')
<div class="flex flex-wrap items-center justify-between gap-3"><div><h1 class="text-2xl font-bold">ផ្ទាំងរបាយការណ៍</h1><p class="mt-1 text-sm text-slate-500">ទិន្នន័យពិតពីប្រព័ន្ធ</p></div><div class="flex gap-2"><button onclick="window.print()" class="rounded-lg border px-4 py-2">បោះពុម្ព</button></div></div>
<form method="GET" class="mt-5 grid gap-3 rounded-xl bg-white p-4 shadow-sm md:grid-cols-6">
<input type="date" name="from_date" value="{{ request('from_date') }}" class="rounded-lg border-slate-300"><input type="date" name="to_date" value="{{ request('to_date') }}" class="rounded-lg border-slate-300">
<select name="product_id" class="rounded-lg border-slate-300"><option value="">-- ផលិតផល --</option>@foreach($products as $product)<option value="{{ $product->id }}" @selected((string)request('product_id')===(string)$product->id)>{{ $product->name }}</option>@endforeach</select>
<select name="category_id" class="rounded-lg border-slate-300"><option value="">-- ប្រភេទ --</option>@foreach($categories as $category)<option value="{{ $category->id }}" @selected((string)request('category_id')===(string)$category->id)>{{ $category->name }}</option>@endforeach</select>
<select name="supplier_id" class="rounded-lg border-slate-300"><option value="">-- អ្នកផ្គត់ផ្គង់ --</option>@foreach($suppliers as $supplier)<option value="{{ $supplier->id }}" @selected((string)request('supplier_id')=== (string)$supplier->id)>{{ $supplier->name }}</option>@endforeach</select>
<select name="cashier_id" class="rounded-lg border-slate-300"><option value="">-- អ្នកគិតលុយ --</option>@foreach($users as $user)<option value="{{ $user->id }}" @selected((string)request('cashier_id')=== (string)$user->id)>{{ $user->name }}</option>@endforeach</select>
<select name="currency" class="rounded-lg border-slate-300"><option value="">-- រូបិយប័ណ្ណទាំងអស់ --</option><option value="USD" @selected(($filters['currency'] ?? '') === 'USD')>USD ($)</option><option value="KHR" @selected(($filters['currency'] ?? '') === 'KHR')>KHR (៛)</option></select>
<div class="flex gap-2 md:col-span-6 md:justify-end"><button class="rounded-lg bg-slate-700 px-4 py-2 text-white">ស្វែងរក</button><a href="{{ route('reports.index') }}" class="rounded-lg border px-4 py-2">សម្អាត</a></div></form>
<div class="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
@foreach([['សរុបការលក់',number_format($salesSummary['sales_count'])],['សរុបការទិញ',number_format($purchaseSummary['purchase_count'])],['ផលិតផលសរុប',number_format($totalProducts)],['តម្លៃស្តុក USD',app(\App\Services\SystemSettingsService::class)->formatAmount($stockValue,'USD')],['ស្តុកតិច / អស់',"$lowStock / $outStock"]] as $card)<div class="rounded-xl bg-white p-5 shadow-sm"><div class="text-sm text-slate-500">{{ $card[0] }}</div><div class="mt-2 text-2xl font-bold">{{ $card[1] }}</div></div>@endforeach
@foreach($salesSummary['by_currency'] as $currency=>$totals)<div class="rounded-xl bg-white p-5 shadow-sm"><div class="text-sm text-slate-500">ចំណូលលក់ {{ $currency }}</div><div class="mt-2 text-2xl font-bold">{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$totals->grand_total, $currency) }}</div></div>@endforeach
@foreach($purchaseSummary['by_currency'] as $currency=>$totals)<div class="rounded-xl bg-white p-5 shadow-sm"><div class="text-sm text-slate-500">តម្លៃទិញ {{ $currency }}</div><div class="mt-2 text-2xl font-bold">{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$totals->grand_total, $currency) }}</div></div>@endforeach
@foreach($profitLoss['by_currency'] as $currency=>$totals)<div class="rounded-xl bg-white p-5 shadow-sm"><div class="text-sm text-slate-500">ចំណេញមូល {{ $currency }}</div><div class="mt-2 text-2xl font-bold">{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$totals['gross_profit'], $currency) }}</div></div>@endforeach
</div>
<div class="mt-5 grid gap-5 xl:grid-cols-2"><div class="rounded-xl bg-white p-5 shadow-sm"><div class="mb-3 flex items-center justify-between"><h2 class="font-semibold">ការលក់តាមថ្ងៃ</h2></div><div class="h-72"><canvas id="report-sales-chart"></canvas></div></div><div class="rounded-xl bg-white p-5 shadow-sm"><div class="mb-3"><h2 class="font-semibold">ផលិតផលលក់ដ៏ល្អបំផុត ១០</h2></div><div class="h-72"><canvas id="report-top-products-chart"></canvas></div></div></div>
<div class="mt-5 flex flex-wrap gap-3"><a href="{{ route('reports.sales', request()->query()) }}" class="rounded-lg bg-blue-700 px-4 py-2 text-white">របាយការណ៍លក់</a><a href="{{ route('reports.purchases', request()->query()) }}" class="rounded-lg border px-4 py-2">របាយការណ៍ទិញ</a><a href="{{ route('reports.stock', request()->query()) }}" class="rounded-lg border px-4 py-2">របាយការណ៍ស្តុក</a><a href="{{ route('reports.profit-loss', request()->query()) }}" class="rounded-lg border px-4 py-2">ចំណេញ និងខាត</a></div>
@php
$reportChartData = [
    'currency' => $filters['currency'] ?? $systemSettings['currency_code'],
    'daily' => [
        'labels' => $dailySales->pluck('period')->map(function ($value) { return (string) $value; })->values()->all(),
        'sales' => $dailySales->pluck('total')->map(function ($value) { return (float) $value; })->values()->all(),
    ],
    'top' => [
        'labels' => $topProducts->pluck('name')->values()->all(),
        'quantities' => $topProducts->pluck('quantity')->map(function ($value) { return (float) $value; })->values()->all(),
    ],
];
@endphp
<script id="reports-data" type="application/json">@json($reportChartData)</script>
@endsection
