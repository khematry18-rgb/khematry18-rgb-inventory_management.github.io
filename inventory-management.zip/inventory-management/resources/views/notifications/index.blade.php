@extends('layouts.app')
@section('title', 'ការជូនដំណឹង')
@section('content')
<div class="flex flex-wrap items-center justify-between gap-3">
    <div>
        <h1 class="text-2xl font-bold">ការជូនដំណឹង</h1>
        <p class="mt-1 text-sm text-slate-500">មិនទាន់អាន {{ number_format($unreadCount) }} ការជូនដំណឹង</p>
    </div>
    <div class="flex gap-2">
        @if($unreadCount > 0)
            <form method="POST" action="{{ route('notifications.read-all') }}">
                @csrf
                <button class="rounded-lg border bg-white px-4 py-2 text-sm">សម្គាល់ទាំងអស់ថាបានអាន</button>
            </form>
        @endif
        @if($notifications->total() > 0)
            <form method="POST" action="{{ route('notifications.clear') }}" onsubmit="return confirm('តើអ្នកប្រាកដថាចង់លុបការជូនដំណឹងទាំងអស់ឬ?')">
                @csrf
                @method('DELETE')
                <button class="rounded-lg border border-red-200 px-4 py-2 text-sm text-red-700">សម្អាតទាំងអស់</button>
            </form>
        @endif
    </div>
</div>
<div class="mt-5 space-y-3">
    @forelse($notifications as $notification)
        <article class="rounded-xl border bg-white p-4 shadow-sm {{ $notification->read_at ? '' : 'border-l-4 border-l-blue-600' }}">
            <div class="flex flex-wrap items-start justify-between gap-3">
                <a href="{{ route('notifications.show', $notification->id) }}" class="min-w-0 flex-1">
                    <div class="flex flex-wrap items-center gap-2">
                        <h2 class="font-semibold">{{ $notification->data['title'] ?? 'ការជូនដំណឹង' }}</h2>
                        <span class="rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-600">{{ \App\Notifications\InventoryNotification::typeLabel($notification->data['event_type'] ?? 'system.alert') }}</span>
                        <span class="rounded-full px-2 py-0.5 text-xs {{ $notification->read_at ? 'bg-slate-100 text-slate-500' : 'bg-blue-100 text-blue-700' }}">{{ $notification->read_at ? 'បានអាន' : 'មិនទាន់អាន' }}</span>
                    </div>
                    <p class="mt-1 text-sm text-slate-600">{{ $notification->data['message'] ?? '' }}</p>
                    <time class="mt-2 block text-xs text-slate-400" datetime="{{ $notification->created_at->toIso8601String() }}">{{ app(\App\Services\SystemSettingsService::class)->formatDate($notification->created_at, true) }} · {{ $notification->created_at->diffForHumans() }}</time>
                </a>
                <div class="flex items-center gap-2">
                    @if($notification->read_at)
                        <form method="POST" action="{{ route('notifications.unread', $notification->id) }}">
                            @csrf
                            @method('PATCH')
                            <button class="text-xs text-blue-700">សម្គាល់មិនទាន់អាន</button>
                        </form>
                    @else
                        <form method="POST" action="{{ route('notifications.read', $notification->id) }}">
                            @csrf
                            @method('PATCH')
                            <button class="text-xs text-slate-600">សម្គាល់ថាបានអាន</button>
                        </form>
                    @endif
                    <form method="POST" action="{{ route('notifications.destroy', $notification->id) }}" onsubmit="return confirm('លុបការជូនដំណឹងនេះ?')">
                        @csrf
                        @method('DELETE')
                        <button class="text-xs text-red-700">លុប</button>
                    </form>
                </div>
            </div>
        </article>
    @empty
        <div class="rounded-xl border border-dashed bg-white px-6 py-12 text-center text-slate-500">មិនមានការជូនដំណឹងទេ។</div>
    @endforelse
</div>
<div class="mt-5">{{ $notifications->links() }}</div>
@endsection
