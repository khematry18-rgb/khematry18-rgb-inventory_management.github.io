<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>{{ $sale->sale_number }}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Khmer:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body{font-family:'Noto Sans Khmer','Khmer OS System','Khmer UI',Arial,sans-serif;line-height:1.65;background:#f1f5f9;color:#111;padding:20px}
        .receipt{margin:auto;background:#fff;padding:20px;box-shadow:0 1px 5px #0002}
        .receipt-58mm{width:58mm}.receipt-80mm{width:80mm}.receipt-A4{width:190mm}
        table{width:100%;border-collapse:collapse;font-size:12px}
        td,th{padding:6px 2px;border-bottom:1px solid #ddd}
        .right{text-align:right}.center{text-align:center}.row{display:flex;justify-content:space-between;margin:5px 0}
        .print-button{margin-bottom:12px;padding:8px 14px}
        @media print{body{padding:0;background:#fff}.print-button,.back-link{display:none}.receipt{box-shadow:none;width:auto;padding:0}}
    </style>
</head>
<body>
<button class="print-button" onclick="window.print()">បោះពុម្ព</button>
<a class="back-link" href="{{ route('sales.show', $sale) }}">ត្រឡប់ទៅការលក់</a>
<main class="receipt receipt-{{ $systemSettings['receipt_paper_size'] }}">
    <header class="center">
        @if($systemSettings['store_logo'])
            <img src="{{ asset('storage/'.$systemSettings['store_logo']) }}" alt="រូបសញ្ញាហាង" style="max-width:100px;max-height:70px">
        @endif
        <h1>{{ $systemSettings['store_name'] ?: $systemSettings['system_name'] }}</h1>
        @if($systemSettings['store_address'])<p>{{ $systemSettings['store_address'] }}</p>@endif
        @if($systemSettings['phone_number'])<p>{{ $systemSettings['phone_number'] }}</p>@endif
        @if($systemSettings['email'])<p>{{ $systemSettings['email'] }}</p>@endif
        <h2>វិក្កយបត្រលក់</h2>
    </header>
    <section>
        <div class="row"><span>លេខវិក្កយបត្រ</span><strong>{{ $sale->sale_number }}</strong></div>
        <div class="row"><span>កាលបរិច្ឆេទ</span><span>{{ app(\App\Services\SystemSettingsService::class)->formatDate($sale->sold_at, true) }}</span></div>
        <div class="row"><span>អ្នកគិតលុយ</span><span>{{ $sale->creator->name ?? '—' }}</span></div>
        <div class="row"><span>អតិថិជន</span><span>{{ $sale->customer_name }}</span></div>
        @if($sale->customer_phone)<div class="row"><span>ទូរសព្ទ</span><span>{{ $sale->customer_phone }}</span></div>@endif
    </section>
    <table>
        <thead><tr><th class="left">ផលិតផល</th><th class="right">ចំនួន</th><th class="right">សរុប</th></tr></thead>
        <tbody>
        @foreach($sale->items as $item)
            <tr>
                <td>{{ $item->product->name }}<br><small>{{ $item->product->sku }}</small></td>
                <td class="right">{{ number_format((float)$item->quantity, 3) }} × {{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$item->unit_price, $sale->currency ?: 'USD') }}</td>
                <td class="right">{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$item->line_total, $sale->currency ?: 'USD') }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <section style="margin-top:12px">
        <div class="row"><span>សរុបរង</span><span>{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$sale->subtotal, $sale->currency ?: 'USD') }}</span></div>
        <div class="row"><span>បញ្ចុះតម្លៃ</span><span>{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$sale->discount, $sale->currency ?: 'USD') }}</span></div>
        <div class="row"><span>ពន្ធ</span><span>{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$sale->tax, $sale->currency ?: 'USD') }}</span></div>
        <div class="row" style="border-top:1px solid #111;padding-top:8px;font-weight:bold"><span>សរុប {{ $sale->currency }}</span><span>{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$sale->grand_total, $sale->currency ?: 'USD') }}</span></div>
        <div class="row"><span>បានទូទាត់</span><span>{{ app(\App\Services\SystemSettingsService::class)->formatAmount($paid, $sale->currency ?: 'USD') }}</span></div>
        <div class="row"><span>នៅសល់</span><span>{{ app(\App\Services\SystemSettingsService::class)->formatAmount($outstanding, $sale->currency ?: 'USD') }}</span></div>
    </section>
    @if($systemSettings['receipt_footer'])
        <footer class="center" style="margin-top:16px">{{ $systemSettings['receipt_footer'] }}</footer>
    @else
        <footer class="center" style="margin-top:16px">សូមអរគុណ!</footer>
    @endif
</main>
@if($systemSettings['print_receipt_automatically'])
<script>window.addEventListener('load',()=>window.print());</script>
@endif
</body>
</html>
