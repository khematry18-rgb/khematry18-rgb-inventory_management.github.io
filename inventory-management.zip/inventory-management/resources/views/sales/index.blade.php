@extends('layouts.app')
@section('title', 'ការលក់')
@section('content')
<div class="flex flex-wrap items-center justify-between gap-3">
    <div><h1 class="text-2xl font-bold">បញ្ជីការលក់</h1><p class="mt-1 text-sm text-slate-500">ប្រតិបត្តិការលក់ និងការទូទាត់</p></div>
    @if(auth()->user()->hasRole('admin') || auth()->user()->hasPermission('sales.manage') || auth()->user()->hasPermission('sales.create'))
        <a href="{{ route('sales.create') }}" class="rounded-lg bg-blue-700 px-4 py-2 text-white">លក់ថ្មី / POS</a>
    @endif
</div>
<form method="GET" class="mt-5 grid gap-3 rounded-xl bg-white p-4 shadow-sm md:grid-cols-6">
    <input type="search" name="search" value="{{ request('search') }}" placeholder="លេខវិក្កយបត្រ ឬអតិថិជន" class="rounded-lg border-slate-300 md:col-span-2">
    <select name="status" class="rounded-lg border-slate-300"><option value="">-- ស្ថានភាព --</option><option value="completed" @selected(request('status')==='completed')>បានបញ្ចប់</option><option value="cancelled" @selected(request('status')==='cancelled')>បានលុបចោល</option></select>
    <select name="payment_status" class="rounded-lg border-slate-300"><option value="">-- ការទូទាត់ --</option><option value="unpaid" @selected(request('payment_status')==='unpaid')>មិនទាន់ទូទាត់</option><option value="partially_paid" @selected(request('payment_status')==='partially_paid')>ទូទាត់មួយផ្នែក</option><option value="paid" @selected(request('payment_status')==='paid')>បានទូទាត់</option></select>
    <select name="payment_method" class="rounded-lg border-slate-300"><option value="">-- វិធីទូទាត់ --</option>@foreach(['cash'=>'សាច់ប្រាក់','bank'=>'ធនាគារ','aba'=>'ABA','acleda'=>'ACLEDA','other'=>'ផ្សេងទៀត'] as $key=>$label)<option value="{{ $key }}" @selected(request('payment_method')=== $key)>{{ $label }}</option>@endforeach</select>
    <input type="date" name="from_date" value="{{ request('from_date') }}" class="rounded-lg border-slate-300">
    <input type="date" name="to_date" value="{{ request('to_date') }}" class="rounded-lg border-slate-300">
    <select name="per_page" class="rounded-lg border-slate-300">@foreach([10,25,50] as $size)<option value="{{ $size }}" @selected((int)request('per_page',10)===$size)>{{ $size }} ជួរ</option>@endforeach</select>
    <div class="flex gap-2 md:col-span-6 md:justify-end"><button class="rounded-lg bg-slate-700 px-4 py-2 text-white">ស្វែងរក</button><a href="{{ route('sales.index') }}" class="rounded-lg border px-4 py-2">សម្អាត</a></div>
</form>
<div class="mt-5 overflow-x-auto rounded-xl bg-white shadow-sm">
<table class="min-w-full divide-y"><thead class="bg-slate-50"><tr><th class="px-3 py-3 text-left text-sm">លេខវិក្កយបត្រ</th><th class="px-3 py-3 text-left text-sm">អតិថិជន</th><th class="px-3 py-3 text-left text-sm">កាលបរិច្ឆេទ</th><th class="px-3 py-3 text-right text-sm">សរុប</th><th class="px-3 py-3 text-left text-sm">ស្ថានភាព</th><th class="px-3 py-3 text-left text-sm">ការទូទាត់</th><th class="px-3 py-3 text-right text-sm">សកម្មភាព</th></tr></thead><tbody class="divide-y">
@forelse($sales as $sale)
<tr><td class="px-3 py-3"><a href="{{ route('sales.show',$sale) }}" class="font-medium text-blue-700">{{ $sale->sale_number }}</a></td><td class="px-3 py-3">{{ $sale->customer_name }}</td><td class="px-3 py-3">{{ app(\App\Services\SystemSettingsService::class)->formatDate($sale->sold_at, true) }}</td><td class="px-3 py-3 text-right">{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$sale->grand_total, $sale->currency ?: 'USD') }}</td><td class="px-3 py-3">{{ $sale->status==='completed'?'បានបញ្ចប់':'បានលុបចោល' }}</td><td class="px-3 py-3">{{ $sale->payment_status==='paid'?'បានទូទាត់':($sale->payment_status==='partially_paid'?'ទូទាត់មួយផ្នែក':'មិនទាន់ទូទាត់') }}</td><td class="px-3 py-3 text-right whitespace-nowrap"><a href="{{ route('sales.show',$sale) }}" class="text-blue-700">មើល</a> <a href="{{ route('sales.print',$sale) }}" target="_blank" class="ml-3 text-slate-700">បោះពុម្ព</a></td></tr>
@empty<tr><td colspan="7" class="px-3 py-8 text-center text-slate-500">មិនមានការលក់</td></tr>@endforelse
</tbody></table></div><div class="mt-4">{{ $sales->links() }}</div>
@endsection
