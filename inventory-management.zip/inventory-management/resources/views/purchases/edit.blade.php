@extends('layouts.app')
@section('title', 'កែសម្រួលការទិញ')
@section('content')
<h1 class="text-2xl font-bold">កែសម្រួលការទិញ {{ $purchase->purchase_number }}</h1>
@include('purchases._form', ['action'=>route('purchases.update',$purchase),'method'=>'PUT','purchase'=>$purchase])
@endsection
