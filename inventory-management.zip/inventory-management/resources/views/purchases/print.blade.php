<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="utf-8">
    <title>បញ្ជាទិញ {{ $purchase->purchase_number }}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Khmer:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body{font-family:'Noto Sans Khmer','Khmer OS System','Khmer UI',Arial,sans-serif;line-height:1.65;color:#111;padding:20px}
        .receipt{max-width:{{ $systemSettings['purchase_receipt_paper_size'] === '80mm' ? '80mm' : '190mm' }};margin:auto}
        table{width:100%;border-collapse:collapse}
        th,td{border:1px solid #ddd;padding:8px}
        .right{text-align:right}
        @media print{body{padding:0}button{display:none}}
    </style>
</head>
<body>
<div class="receipt">
    <button onclick="window.print()">បោះពុម្ព</button>
    @if($systemSettings['store_logo'])<img src="{{ asset('storage/'.$systemSettings['store_logo']) }}" alt="រូបសញ្ញាហាង" style="max-width:100px;max-height:70px">@endif
    <h2>{{ $systemSettings['store_name'] ?: $systemSettings['system_name'] }}</h2>
    @if($systemSettings['store_address'])<p>{{ $systemSettings['store_address'] }}</p>@endif
    @if($systemSettings['phone_number'])<p>{{ $systemSettings['phone_number'] }}</p>@endif
    <h3>បញ្ជាទិញ {{ $purchase->purchase_number }} ({{ $purchase->currency }})</h3>
    <p>អ្នកផ្គត់ផ្គង់៖ {{ $purchase->supplier->name }}</p>
    <p>កាលបរិច្ឆេទ៖ {{ app(\App\Services\SystemSettingsService::class)->formatDate($purchase->purchased_at, true) }}</p>
    <table>
        <thead><tr><th>ផលិតផល</th><th>SKU</th><th class="right">បរិមាណ</th><th class="right">តម្លៃឯកតា</th><th class="right">សរុប</th></tr></thead>
        <tbody>
        @foreach($purchase->items as $item)
            <tr><td>{{ $item->product->name }}</td><td>{{ $item->product->sku }}</td><td class="right">{{ number_format((float)$item->quantity, 3) }}</td><td class="right">{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$item->unit_cost, $purchase->currency ?: 'USD') }}</td><td class="right">{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$item->line_total, $purchase->currency ?: 'USD') }}</td></tr>
        @endforeach
        </tbody>
    </table>
    <p class="right">សរុបរង៖ {{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$purchase->subtotal, $purchase->currency ?: 'USD') }}</p>
    <p class="right">បញ្ចុះតម្លៃ៖ {{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$purchase->discount, $purchase->currency ?: 'USD') }}</p>
    <p class="right">ពន្ធ៖ {{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$purchase->tax, $purchase->currency ?: 'USD') }}</p>
    <h3 class="right">សរុប៖ {{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$purchase->grand_total, $purchase->currency ?: 'USD') }}</h3>
</div>
</body>
</html>
