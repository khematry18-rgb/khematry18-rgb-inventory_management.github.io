@extends('layouts.app')
@section('title', 'ការទិញ')
@section('content')
<div class="flex flex-wrap items-center justify-between gap-3">
    <div><h1 class="text-2xl font-bold">បញ្ជីការទិញ</h1><p class="mt-1 text-sm text-slate-500">គ្រប់គ្រងការទិញ ការទទួល និងការទូទាត់</p></div>
    <a href="{{ route('purchases.create') }}" class="rounded-lg bg-blue-700 px-4 py-2 text-white">បង្កើតការទិញ</a>
</div>
<form method="GET" class="mt-5 grid gap-3 rounded-xl bg-white p-4 shadow-sm md:grid-cols-6">
    <input type="search" name="search" value="{{ request('search') }}" placeholder="លេខបញ្ជាទិញ ឬអ្នកផ្គត់ផ្គង់" class="rounded-lg border-slate-300 md:col-span-2">
    <select name="supplier_id" class="rounded-lg border-slate-300"><option value="">-- អ្នកផ្គត់ផ្គង់ --</option>@foreach($suppliers as $supplier)<option value="{{ $supplier->id }}" @selected((string)request('supplier_id') === (string)$supplier->id)>{{ $supplier->name }}</option>@endforeach</select>
    <select name="status" class="rounded-lg border-slate-300"><option value="">-- ស្ថានភាព --</option>@foreach(['draft'=>'សេចក្តីព្រាង','pending'=>'កំពុងរង់ចាំ','partially_received'=>'ទទួលមួយផ្នែក','received'=>'បានទទួល','cancelled'=>'បានលុបចោល'] as $key=>$label)<option value="{{ $key }}" @selected(request('status') === $key)>{{ $label }}</option>@endforeach</select>
    <select name="payment_status" class="rounded-lg border-slate-300"><option value="">-- ការទូទាត់ --</option>@foreach(['unpaid'=>'មិនទាន់ទូទាត់','partially_paid'=>'ទូទាត់មួយផ្នែក','paid'=>'បានទូទាត់'] as $key=>$label)<option value="{{ $key }}" @selected(request('payment_status') === $key)>{{ $label }}</option>@endforeach</select>
    <input type="date" name="from_date" value="{{ request('from_date') }}" class="rounded-lg border-slate-300">
    <input type="date" name="to_date" value="{{ request('to_date') }}" class="rounded-lg border-slate-300">
    <select name="per_page" class="rounded-lg border-slate-300">@foreach([10,25,50] as $size)<option value="{{ $size }}" @selected((int)request('per_page',10) === $size)>{{ $size }} ជួរ</option>@endforeach</select>
    <div class="flex gap-2 md:col-span-6 md:justify-end"><button class="rounded-lg bg-slate-700 px-4 py-2 text-white">ស្វែងរក</button><a href="{{ route('purchases.index') }}" class="rounded-lg border border-slate-300 px-4 py-2">សម្អាត</a></div>
</form>
<div class="mt-5 overflow-x-auto rounded-xl bg-white shadow-sm">
<table class="min-w-full divide-y"><thead class="bg-slate-50"><tr><th class="px-3 py-3 text-left text-sm">លេខបញ្ជាទិញ</th><th class="px-3 py-3 text-left text-sm">អ្នកផ្គត់ផ្គង់</th><th class="px-3 py-3 text-left text-sm">កាលបរិច្ឆេទ</th><th class="px-3 py-3 text-right text-sm">បរិមាណ</th><th class="px-3 py-3 text-right text-sm">សរុប</th><th class="px-3 py-3 text-left text-sm">ស្ថានភាព</th><th class="px-3 py-3 text-left text-sm">ការទូទាត់</th><th class="px-3 py-3 text-right text-sm">សកម្មភាព</th></tr></thead><tbody class="divide-y">
@forelse($purchases as $purchase)
<tr><td class="px-3 py-3"><a href="{{ route('purchases.show',$purchase) }}" class="font-medium text-blue-700">{{ $purchase->purchase_number }}</a></td><td class="px-3 py-3">{{ $purchase->supplier->name }}</td><td class="px-3 py-3">{{ app(\App\Services\SystemSettingsService::class)->formatDate($purchase->purchased_at) }}</td><td class="px-3 py-3 text-right">{{ number_format((float)$purchase->total_quantity,3) }}</td><td class="px-3 py-3 text-right">{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float)$purchase->grand_total, $purchase->currency ?: 'USD') }}</td><td class="px-3 py-3">{{ $purchase->status }}</td><td class="px-3 py-3">{{ $purchase->payment_status }}</td><td class="px-3 py-3 text-right whitespace-nowrap"><a href="{{ route('purchases.show',$purchase) }}" class="text-blue-700">មើល</a>@if(in_array($purchase->status,['draft','pending'])) <a href="{{ route('purchases.edit',$purchase) }}" class="ml-3 text-blue-700">កែ</a>@endif @if(in_array($purchase->status,['draft','pending','partially_received'])) <a href="{{ route('purchases.receive',$purchase) }}" class="ml-3 text-green-700">ទទួល</a>@endif</td></tr>
@empty<tr><td colspan="8" class="px-3 py-8 text-center text-slate-500">មិនមានការទិញ</td></tr>@endforelse
</tbody></table></div><div class="mt-4">{{ $purchases->links() }}</div>
@endsection
