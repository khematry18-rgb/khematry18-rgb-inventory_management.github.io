@extends('layouts.app')
@section('title', 'បង្កើតការទិញ')
@section('content')
<h1 class="text-2xl font-bold">បង្កើតការទិញ</h1>
@include('purchases._form', ['action'=>route('purchases.store'),'method'=>'POST','purchase'=>null])
@endsection
