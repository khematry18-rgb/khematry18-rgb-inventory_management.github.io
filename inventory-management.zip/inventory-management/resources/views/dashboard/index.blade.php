@extends('layouts.app')

@section('title', 'ផ្ទាំងគ្រប់គ្រង')

@section('content')
<div class="space-y-6 sm:space-y-8" id="dashboard-page">
    <div class="flex flex-col gap-4 rounded-2xl bg-gradient-to-r from-blue-700 to-indigo-700 p-5 text-white shadow-sm sm:flex-row sm:items-center sm:justify-between sm:p-7">
        <div>
            <p class="text-sm text-blue-100">សូមស្វាគមន៍មកកាន់ប្រព័ន្ធ</p>
            <h1 class="mt-1 text-2xl font-bold sm:text-3xl">ផ្ទាំងគ្រប់គ្រង</h1>
            <p class="mt-2 text-sm text-blue-100">ជំរាបសួរ {{ auth()->user()->name }} · {{ app(\App\Services\SystemSettingsService::class)->formatDate(now()) }}</p>
        </div>
        <form method="GET" class="flex items-center gap-3 self-start rounded-xl bg-white/10 p-3 sm:self-auto">
            <label for="period" class="text-sm text-white">រយៈពេល</label>
            <select id="period" name="period" onchange="this.form.submit()" class="rounded-lg border-0 bg-white px-3 py-2 text-sm text-slate-800 focus:ring-2 focus:ring-blue-300">
                <option value="7" @selected($period === 7)>7 ថ្ងៃ</option>
                <option value="30" @selected($period === 30)>30 ថ្ងៃ</option>
                <option value="90" @selected($period === 90)>90 ថ្ងៃ</option>
            </select>
        </form>
    </div>

    @php
        $summaryCards = [
            ['visible' => $canViewProducts, 'label' => 'ផលិតផលសរុប', 'value' => number_format($totalProducts), 'detail' => 'ផលិតផលក្នុងប្រព័ន្ធ', 'iconClass' => 'bg-blue-50 text-blue-700', 'icon' => 'M4 6h16M4 12h16M4 18h16'],
            ['visible' => $canViewCategories, 'label' => 'ប្រភេទទំនិញ', 'value' => number_format($totalCategories), 'detail' => 'ប្រភេទផលិតផល', 'iconClass' => 'bg-violet-50 text-violet-700', 'icon' => 'M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z'],
            ['visible' => $canViewSuppliers, 'label' => 'ចំនួនអ្នកផ្គត់ផ្គង់', 'value' => number_format($totalSuppliers), 'detail' => 'អ្នកផ្គត់ផ្គង់សរុប', 'iconClass' => 'bg-cyan-50 text-cyan-700', 'icon' => 'M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M10 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75'],
            ['visible' => $canViewStock, 'label' => 'តម្លៃស្តុកសរុប', 'value' => app(\App\Services\SystemSettingsService::class)->formatAmount($totalStockValue, $displayCurrency), 'detail' => number_format((float) $totalStockQuantity, 3) . ' ឯកតាក្នុងស្តុក', 'iconClass' => 'bg-indigo-50 text-indigo-700', 'icon' => 'M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6'],
            ['visible' => $canViewSales, 'label' => 'ការលក់ថ្ងៃនេះ', 'value' => app(\App\Services\SystemSettingsService::class)->formatAmount($todaySalesTotal, $displayCurrency), 'detail' => number_format($todaySalesCount) . ' ប្រតិបត្តិការ', 'iconClass' => 'bg-green-50 text-green-700', 'icon' => 'M3 3v18h18M7 14l4-4 4 4 6-7'],
            ['visible' => $canViewPurchases, 'label' => 'ការទិញថ្ងៃនេះ', 'value' => app(\App\Services\SystemSettingsService::class)->formatAmount($todayPurchasesTotal, $displayCurrency), 'detail' => number_format($todayPurchasesCount) . ' ប្រតិបត្តិការ', 'iconClass' => 'bg-sky-50 text-sky-700', 'icon' => 'M3 7h18l-2 13H5L3 7zM8 7l4-4 4 4M9 11v5M15 11v5'],
            ['visible' => $canViewStock, 'label' => 'ទំនិញជិតអស់', 'value' => number_format($lowStock), 'detail' => 'ត្រូវការតាមដានស្តុក', 'iconClass' => 'bg-amber-50 text-amber-700', 'icon' => 'M12 9v4m0 4h.01M10.3 3.8 1.8 18.5A2 2 0 0 0 3.5 21h17a2 2 0 0 0 1.7-2.5L13.7 3.8a2 2 0 0 0-3.4 0z'],
            ['visible' => $canViewStock, 'label' => 'ទំនិញអស់ស្តុក', 'value' => number_format($outOfStock), 'detail' => 'ត្រូវការបំពេញស្តុក', 'iconClass' => 'bg-rose-50 text-rose-700', 'icon' => 'M4 7.5 12 3l8 4.5v9L12 21l-8-4.5v-9zM12 12l8-4.5M12 12v9M12 12 4 7.5'],
        ];
    @endphp
    <div class="grid min-w-0 gap-4 sm:grid-cols-2 2xl:grid-cols-4">
        @foreach($summaryCards as $card)
            @if($card['visible'])
            <article class="min-w-0 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
                <div class="flex items-start justify-between gap-3">
                    <div class="min-w-0">
                        <p class="text-sm font-medium text-slate-500">{{ $card['label'] }}</p>
                        <p class="mt-3 break-words text-xl font-bold text-slate-900 sm:text-2xl">{{ $card['value'] }}</p>
                        <p class="mt-2 text-xs text-slate-500">{{ $card['detail'] }}</p>
                    </div>
                    <span class="grid h-11 w-11 shrink-0 place-items-center rounded-xl {{ $card['iconClass'] }}">
                        <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="{{ $card['icon'] }}"/></svg>
                    </span>
                </div>
            </article>
            @endif
        @endforeach
    </div>

    <div class="grid gap-6 xl:grid-cols-3">
        <section class="min-w-0 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm xl:col-span-2 sm:p-6">
            <div class="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h2 class="font-semibold text-slate-900">វិភាគការលក់ និងការទិញ</h2>
                    <p class="mt-1 text-xs text-slate-500">ទិន្នន័យតាមរូបិយប័ណ្ណ {{ $displayCurrency }}</p>
                </div>
                <div class="flex flex-wrap gap-2">
                    <label class="flex items-center gap-2 text-sm text-slate-600" for="chart-period">មើលតាម
                        <select id="chart-period" class="rounded-lg border border-slate-300 px-3 py-2 text-sm">
                            <option value="daily">ប្រចាំថ្ងៃ</option>
                            <option value="weekly">ប្រចាំសប្តាហ៍</option>
                            <option value="monthly">ប្រចាំខែ</option>
                        </select>
                    </label>
                    <label class="sr-only" for="chart-metric">ប្រភេទទិន្នន័យក្រាប</label>
                    <select id="chart-metric" class="rounded-lg border border-slate-300 px-3 py-2 text-sm" aria-label="ប្រភេទទិន្នន័យក្រាប">
                        <option value="comparisonSeries">ការលក់ និងការទិញ</option>
                        <option value="salesSeries">ចំណូលលក់</option>
                        @if($canViewPurchases && $canViewReports)<option value="purchaseSeries">ចំណាយទិញ</option>@endif
                        @if($canViewReports)<option value="profitSeries">ចំណេញ</option>@endif
                    </select>
                </div>
            </div>
            <div class="relative h-72 min-w-0 sm:h-80"><canvas id="dashboard-chart" role="img" aria-label="ក្រាបប្រៀបធៀបការលក់ និងការទិញ"></canvas></div>
            <div class="mt-3 flex flex-wrap gap-4 text-xs text-slate-500">
                <span>ចំណូល {{ $displayCurrency }} ក្នុង {{ $period }} ថ្ងៃ: <strong>{{ app(\App\Services\SystemSettingsService::class)->formatAmount($periodSalesRevenue, $displayCurrency) }}</strong></span>
                @if($canViewReports)<span>ចំណេញប៉ាន់ស្មាន {{ $displayCurrency }}: <strong>{{ app(\App\Services\SystemSettingsService::class)->formatAmount($profitOverview, $displayCurrency) }}</strong></span>@endif
            </div>
        </section>

        @if($canViewStock)
        <section id="stock-alerts" class="min-w-0 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
            <div class="mb-4 flex items-center justify-between gap-2">
                <div><h2 class="font-semibold text-slate-900">ការជូនដំណឹងស្តុក</h2><p class="mt-1 text-xs text-slate-500">ផលិតផលក្រោមកម្រិតអប្បបរមា</p></div>
                @if($canViewProducts)<a href="{{ route('products.index', ['stock_status' => 'low_stock']) }}" class="text-xs font-medium text-blue-700 hover:text-blue-900">មើលផលិតផល</a>@endif
            </div>
            <div class="overflow-x-auto">
                <table class="w-full min-w-[680px] text-left text-sm">
                    <thead class="border-b text-slate-500"><tr><th class="py-2">ផលិតផល</th><th>SKU</th><th class="text-right">បរិមាណបច្ចុប្បន្ន</th><th class="text-right">ស្តុកអប្បបរមា</th><th>ស្ថានភាព</th><th>សកម្មភាព</th></tr></thead>
                    <tbody>
                    @forelse($stockAlerts ?? collect() as $product)
                        @php $stockStatus = $product->stock_quantity <= 0 ? 'អស់ស្តុក' : 'ស្តុកតិច'; @endphp
                        <tr class="border-b last:border-0">
                            <td class="py-2 font-medium">{{ $product->name }}</td>
                            <td class="font-mono text-xs">{{ $product->sku }}</td>
                            <td class="text-right">{{ number_format((float) $product->stock_quantity, 3) }}</td>
                            <td class="text-right">{{ number_format((float) $product->minimum_stock, 3) }}</td>
                            <td><span class="rounded-full px-2 py-1 text-xs {{ $product->stock_quantity <= 0 ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700' }}">{{ $stockStatus }}</span></td>
                            <td>@if($canViewProducts)<a href="{{ route('products.show', $product) }}" class="font-medium text-blue-700 hover:underline">មើលផលិតផល</a>@else—@endif</td>
                        </tr>
                    @empty
                        <tr><td colspan="6" class="py-5 text-center text-slate-500">គ្មានផលិតផលស្តុកតិច</td></tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
            <div class="mt-3">{{ $stockAlerts?->links() }}</div>
        </section>
        @endif
    </div>

    <section class="grid min-w-0 gap-6 xl:grid-cols-2">
        @if($canViewSales)
        <div id="recent-sales" class="min-w-0 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
            <div class="mb-4 flex items-center justify-between gap-3"><div><h2 class="font-semibold text-slate-900">ការលក់ថ្មីៗ</h2><p class="mt-1 text-xs text-slate-500">ប្រតិបត្តិការលក់ដែលបានបញ្ចប់</p></div><a href="{{ route('sales.index') }}" class="text-xs font-medium text-blue-700 hover:text-blue-900">មើលទាំងអស់</a></div>
            <div class="overflow-x-auto">
                <table class="w-full min-w-[720px] text-left text-sm">
                    <thead class="border-b text-slate-500"><tr><th class="py-2">លេខវិក្កយបត្រ</th><th>អតិថិជន</th><th>កាលបរិច្ឆេទ</th><th>សរុប</th><th>ការទូទាត់</th><th>ស្ថានភាព</th><th>សកម្មភាព</th></tr></thead>
                    <tbody>
                    @forelse($recentSales as $sale)
                        <tr class="border-b last:border-0">
                            <td class="py-3 font-medium"><a href="{{ route('sales.show', $sale) }}" class="text-blue-700 hover:underline">{{ $sale->sale_number }}</a></td>
                            <td>{{ $sale->customer_name ?: '-' }}</td>
                            <td>{{ app(\App\Services\SystemSettingsService::class)->formatDate($sale->completed_at ?? $sale->sold_at) }}</td>
                            <td>{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float) $sale->grand_total, $sale->currency ?: 'USD') }}</td>
                            <td><span class="rounded-full px-2 py-1 text-xs {{ $sale->payment_status === 'paid' ? 'bg-green-100 text-green-700' : ($sale->payment_status === 'partially_paid' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700') }}">{{ $sale->payment_status === 'paid' ? 'បានបង់' : ($sale->payment_status === 'partially_paid' ? 'បង់មួយភាគ' : 'មិនទាន់បង់') }}</span></td>
                            <td><span class="rounded-full px-2 py-1 text-xs {{ in_array($sale->status, ['completed', 'confirmed'], true) ? 'bg-blue-50 text-blue-700' : 'bg-slate-100 text-slate-700' }}">{{ $sale->status === 'completed' ? 'បានបញ្ចប់' : 'បានបញ្ជាក់' }}</span></td>
                            <td><a href="{{ route('sales.show', $sale) }}" class="font-medium text-blue-700 hover:underline">មើល</a></td>
                        </tr>
                    @empty
                        <tr><td colspan="7" class="py-8 text-center text-slate-500">មិនទាន់មានទិន្នន័យការលក់</td></tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
            <div class="mt-3">{{ $recentSales->links() }}</div>
        </div>
        @endif

        @if($canViewPurchases && $recentPurchases)
        <div class="min-w-0 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
            <div class="mb-4 flex items-center justify-between gap-3"><div><h2 class="font-semibold text-slate-900">ការទិញថ្មីៗ</h2><p class="mt-1 text-xs text-slate-500">ការទិញដែលបានបញ្ជាក់</p></div><a href="{{ route('purchases.index') }}" class="text-xs font-medium text-blue-700 hover:text-blue-900">មើលទាំងអស់</a></div>
            <div class="overflow-x-auto">
                <table class="w-full min-w-[600px] text-left text-sm">
                    <thead class="border-b text-slate-500"><tr><th class="py-2">លេខទិញ</th><th>អ្នកផ្គត់ផ្គង់</th><th>កាលបរិច្ឆេទ</th><th>សរុប</th><th>ស្ថានភាព</th></tr></thead>
                    <tbody>
                    @forelse($recentPurchases as $purchase)
                        <tr class="border-b last:border-0">
                            <td class="py-3 font-medium">{{ $purchase->purchase_number }}</td>
                            <td>{{ $purchase->supplier->name ?? '-' }}</td>
                            <td>{{ app(\App\Services\SystemSettingsService::class)->formatDate($purchase->confirmed_at ?? $purchase->purchased_at) }}</td>
                            <td>{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float) $purchase->grand_total, $purchase->currency ?: 'USD') }}</td>
                            <td><span class="rounded-full bg-green-100 px-2 py-1 text-xs text-green-700">បានបញ្ជាក់</span></td>
                        </tr>
                    @empty
                        <tr><td colspan="5" class="py-5 text-center text-slate-500">គ្មានទិន្នន័យការទិញ</td></tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
            <div class="mt-3">{{ $recentPurchases->links() }}</div>
        </div>
        @endif
    </section>

    @if($canViewStock && $recentMovements)
    <section class="min-w-0 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
        <h2 class="mb-4 font-semibold text-slate-900">ចលនាស្តុកថ្មីៗ</h2>
        <div class="overflow-x-auto">
            <table class="w-full min-w-[560px] text-left text-sm">
                <thead class="border-b text-slate-500"><tr><th class="py-2">ផលិតផល</th><th>ប្រភេទចលនារ</th><th>បរិមាណ</th><th>កាលបរិច្ឆេទ</th></tr></thead>
                <tbody>
                @forelse($recentMovements as $movement)
                    <tr class="border-b last:border-0">
                        <td class="py-3">{{ $movement->product->name ?? '-' }} <span class="text-xs text-slate-400">({{ $movement->product->sku ?? '-' }})</span></td>
                        <td>{{ $movement->movement_type }}</td>
                        <td class="{{ in_array($movement->movement_type, ['in', 'adjustment_in']) ? 'text-green-700' : 'text-red-700' }}">{{ number_format((float) $movement->quantity, 3) }}</td>
                        <td>{{ app(\App\Services\SystemSettingsService::class)->formatDate($movement->created_at, true) }}</td>
                    </tr>
                @empty
                    <tr><td colspan="4" class="py-5 text-center text-slate-500">គ្មានចលនាស្តុក</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
        <div class="mt-3">{{ $recentMovements->links() }}</div>
    </section>
    @endif

    <section class="grid min-w-0 gap-6 xl:grid-cols-2">
        @if($canViewSales)
        <div id="top-selling-products" class="min-w-0 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
            <div class="mb-4"><h2 class="font-semibold text-slate-900">ផលិតផលលក់ដាច់</h2><p class="mt-1 text-xs text-slate-500">ក្នុងរយៈពេល {{ $period }} ថ្ងៃ · {{ $displayCurrency }}</p></div>
            <div class="overflow-x-auto">
                <table class="w-full min-w-[560px] text-left text-sm">
                    <thead class="border-b text-slate-500"><tr><th class="py-2">ផលិតផល</th><th>SKU</th><th class="text-right">បរិមាណលក់</th><th class="text-right">តម្លៃលក់</th></tr></thead>
                    <tbody>
                    @forelse($topSellingProducts as $product)
                        <tr class="border-b last:border-0">
                            <td class="py-3 font-medium">@if($canViewProducts)<a href="{{ route('products.show', $product->product_id) }}" class="text-blue-700 hover:underline">{{ $product->name }}</a>@else{{ $product->name }}@endif</td>
                            <td class="font-mono text-xs text-slate-500">{{ $product->sku }}</td>
                            <td class="text-right">{{ number_format((float) $product->quantity_sold, 3) }}</td>
                            <td class="text-right">{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float) $product->total_sales, $displayCurrency) }}</td>
                        </tr>
                    @empty
                        <tr><td colspan="4" class="py-8 text-center text-slate-500">មិនមានការលក់ក្នុងរយៈពេលនេះទេ</td></tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        @endif

        <div class="min-w-0 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
            <div class="mb-4 flex items-center justify-between gap-3">
                <div><h2 class="font-semibold text-slate-900">សកម្មភាពថ្មីៗ</h2><p class="mt-1 text-xs text-slate-500">{{ $canViewActivityLogs ? 'សកម្មភាពក្នុងប្រព័ន្ធ' : 'សកម្មភាពរបស់អ្នក' }}</p></div>
                @if($canViewActivityLogs)<a href="{{ route('activity-logs.index') }}" class="text-xs font-medium text-blue-700 hover:text-blue-900">មើលទាំងអស់</a>@endif
            </div>
            <div class="overflow-x-auto">
                <table class="w-full min-w-[520px] text-left text-sm">
                    <thead class="border-b text-slate-500"><tr><th class="py-2">អ្នកប្រើប្រាស់</th><th>សកម្មភាព</th><th>ព័ត៌មានលម្អិត</th><th>កាលបរិច្ឆេទ</th></tr></thead>
                    <tbody>
                    @forelse($recentActivities as $activity)
                        <tr class="border-b last:border-0">
                            <td class="py-3 font-medium">{{ $activity->user?->name ?? 'ប្រព័ន្ធ' }}</td>
                            <td>{{ $activity->actionLabel() }}</td>
                            <td class="max-w-xs truncate" title="{{ $activity->description }}">{{ $activity->description }}</td>
                            <td class="whitespace-nowrap text-xs text-slate-500">{{ app(\App\Services\SystemSettingsService::class)->formatDate($activity->created_at, true) }}</td>
                        </tr>
                    @empty
                        <tr><td colspan="4" class="py-8 text-center text-slate-500">មិនទាន់មានសកម្មភាព</td></tr>
                    @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>

<script id="dashboard-data" type="application/json">@json(['currency' => $displayCurrency, 'canViewPurchases' => $canViewPurchases && $canViewReports, 'series' => $chartData])</script>
@endsection
