@extends('layouts.app')
@section('title', 'ប្រវត្តិរូប')
@section('content')
<h1 class="text-2xl font-bold">ប្រវត្តិរូប</h1>
<div class="mt-5 grid gap-5 lg:grid-cols-2">
    <form method="POST" action="{{ route('profile.update') }}" class="rounded-xl bg-white p-5 shadow-sm">
        @csrf @method('PATCH')
        <h2 class="font-semibold">ព័ត៌មានផ្ទាល់ខ្លួន</h2>
        <div class="mt-4 space-y-4">
            <div><label class="mb-1 block text-sm">ឈ្មោះ</label><input name="name" required value="{{ old('name', $user->name) }}" class="w-full rounded-lg border-slate-300"></div>
            <div><label class="mb-1 block text-sm">លេខទូរស័ព្ទ</label><input name="phone" value="{{ old('phone', $user->phone) }}" class="w-full rounded-lg border-slate-300"></div>
            <div><label class="mb-1 block text-sm">អ៊ីមែល</label><input value="{{ $user->email }}" disabled class="w-full rounded-lg border-slate-200 bg-slate-100"></div>
            <div><label class="mb-1 block text-sm">តួនាទី</label><input value="{{ $user->role?->name ?? '—' }}" disabled class="w-full rounded-lg border-slate-200 bg-slate-100"></div>
        </div>
        <button class="mt-5 rounded-lg bg-blue-700 px-4 py-2 text-white">រក្សាទុក</button>
    </form>
    <form method="POST" action="{{ route('password.update') }}" class="rounded-xl bg-white p-5 shadow-sm">
        @csrf @method('PUT')
        <h2 class="font-semibold">ផ្លាស់ប្តូរលេខសម្ងាត់</h2>
        <div class="mt-4 space-y-4">
            <div><label class="mb-1 block text-sm">លេខសម្ងាត់បច្ចុប្បន្ន</label><input type="password" name="current_password" required class="w-full rounded-lg border-slate-300"></div>
            <div><label class="mb-1 block text-sm">លេខសម្ងាត់ថ្មី</label><input type="password" name="password" required minlength="8" class="w-full rounded-lg border-slate-300"></div>
            <div><label class="mb-1 block text-sm">បញ្ជាក់លេខសម្ងាត់ថ្មី</label><input type="password" name="password_confirmation" required class="w-full rounded-lg border-slate-300"></div>
        </div>
        <button class="mt-5 rounded-lg bg-slate-800 px-4 py-2 text-white">ផ្លាស់ប្តូរលេខសម្ងាត់</button>
    </form>
</div>
@endsection
