@extends('layouts.app')
@section('title', 'កំណត់ហេតុសកម្មភាព')
@section('content')
@php
    $moduleLabels = ['auth' => 'ការផ្ទៀងផ្ទាត់', 'users' => 'អ្នកប្រើប្រាស់', 'products' => 'ផលិតផល', 'categories' => 'ប្រភេទផលិតផល', 'suppliers' => 'អ្នកផ្គត់ផ្គង់', 'stock' => 'ស្តុក', 'purchases' => 'ការទិញ', 'sales' => 'ការលក់', 'payments' => 'ការទូទាត់', 'settings' => 'ការកំណត់'];
    $actionLabels = ['login' => 'ចូលប្រើប្រព័ន្ធ', 'logout' => 'ចាកចេញពីប្រព័ន្ធ', 'created' => 'បង្កើត', 'updated' => 'កែប្រែ', 'deleted' => 'លុប', 'stock.in' => 'បញ្ចូលស្តុក', 'stock.out' => 'ដកស្តុក', 'stock.adjustment' => 'កែតម្រូវស្តុក', 'purchase.received' => 'ទទួលការទិញ', 'purchase.cancelled' => 'លុបចោលការទិញ', 'sale.cancelled' => 'លុបចោលការលក់', 'payment.recorded' => 'កត់ត្រាការទូទាត់'];
@endphp
<div>
    <h1 class="text-2xl font-bold">កំណត់ហេតុសកម្មភាព</h1>
    <p class="mt-1 text-sm text-slate-500">កំណត់ត្រាសវនកម្មសម្រាប់សកម្មភាពសំខាន់ៗ។ មិនអាចកែប្រែ ឬលុបបានទេ។</p>
</div>
<form method="GET" class="mt-5 grid gap-3 rounded-xl bg-white p-4 shadow-sm md:grid-cols-4">
    <input type="search" name="search" value="{{ request('search') }}" placeholder="ស្វែងរកក្នុងការពិពណ៌នា" class="rounded-lg border-slate-300">
    <select name="user_id" class="rounded-lg border-slate-300">
        <option value="">-- អ្នកប្រើប្រាស់ --</option>
        @foreach($users as $user)
            <option value="{{ $user->id }}" @selected((string) request('user_id') === (string) $user->id)>{{ $user->name }}</option>
        @endforeach
    </select>
    <select name="module" class="rounded-lg border-slate-300">
        <option value="">-- ម៉ូឌុល --</option>
        @foreach($modules as $module)
            <option value="{{ $module }}" @selected(request('module') === $module)>{{ $moduleLabels[$module] ?? $module }}</option>
        @endforeach
    </select>
    <select name="action" class="rounded-lg border-slate-300">
        <option value="">-- សកម្មភាព --</option>
        @foreach($actions as $action)
            <option value="{{ $action }}" @selected(request('action') === $action)>{{ $actionLabels[$action] ?? $action }}</option>
        @endforeach
    </select>
    <input type="date" name="from_date" value="{{ request('from_date') }}" class="rounded-lg border-slate-300">
    <input type="date" name="to_date" value="{{ request('to_date') }}" class="rounded-lg border-slate-300">
    <select name="per_page" class="rounded-lg border-slate-300">
        @foreach([10, 25, 50] as $size)
            <option value="{{ $size }}" @selected((int) request('per_page', 10) === $size)>{{ $size }} ជួរ</option>
        @endforeach
    </select>
    <div class="flex gap-2 md:col-span-4 md:justify-end">
        <button class="rounded-lg bg-slate-700 px-4 py-2 text-white">ស្វែងរក</button>
        <a href="{{ route('activity-logs.index') }}" class="rounded-lg border px-4 py-2">សម្អាត</a>
    </div>
</form>
<div class="mt-5 overflow-x-auto rounded-xl bg-white shadow-sm">
    <table class="min-w-full divide-y">
        <thead class="bg-slate-50"><tr>
            <th class="px-3 py-3 text-left text-sm">កាលបរិច្ឆេទ</th>
            <th class="px-3 py-3 text-left text-sm">អ្នកប្រើប្រាស់</th>
            <th class="px-3 py-3 text-left text-sm">សកម្មភាព</th>
            <th class="px-3 py-3 text-left text-sm">ម៉ូឌុល</th>
            <th class="px-3 py-3 text-left text-sm">ការពិពណ៌នា</th>
            <th class="px-3 py-3 text-left text-sm">IP</th>
            <th class="px-3 py-3 text-right text-sm">ព័ត៌មាន</th>
        </tr></thead>
        <tbody class="divide-y">
            @forelse($logs as $log)
                <tr>
                    <td class="whitespace-nowrap px-3 py-3 text-sm">{{ app(\App\Services\SystemSettingsService::class)->formatDate($log->created_at, true) }}</td>
                    <td class="px-3 py-3 text-sm">{{ $log->user?->name ?? 'ប្រព័ន្ធ / គណនីត្រូវបានលុប' }}</td>
                    <td class="px-3 py-3 text-sm">{{ $log->actionLabel() }}</td>
                    <td class="px-3 py-3 text-sm">{{ $log->moduleLabel() }}</td>
                    <td class="max-w-md px-3 py-3 text-sm">{{ $log->description }}</td>
                    <td class="px-3 py-3 text-sm">{{ $log->ip_address ?? '-' }}</td>
                    <td class="px-3 py-3 text-right"><a href="{{ route('activity-logs.show', $log) }}" class="text-blue-700">មើល</a></td>
                </tr>
            @empty
                <tr><td colspan="7" class="px-3 py-10 text-center text-slate-500">មិនមានកំណត់ហេតុសកម្មភាពទេ។</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
<div class="mt-4">{{ $logs->links() }}</div>
@endsection
