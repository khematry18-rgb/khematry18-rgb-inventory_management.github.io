@extends('layouts.app')
@section('title', 'ប្រវត្តិស្តុក')
@section('content')
<div class="flex flex-wrap items-center justify-between gap-3">
    <div><h1 class="text-2xl font-bold">ប្រវត្តិចលនាស្តុក</h1><p class="mt-1 text-sm text-slate-500">ប្រតិបត្តិការចូល ដក និងកែតម្រូវស្តុក</p></div>
    <a href="{{ route('stock.index') }}" class="rounded-lg border border-slate-300 px-4 py-2">ត្រឡប់ស្តុក</a>
</div>

<form method="GET" class="mt-5 grid gap-3 rounded-xl bg-white p-4 shadow-sm md:grid-cols-6">
    <input type="search" name="search" value="{{ request('search') }}" placeholder="ឈ្មោះ ឬ SKU" class="rounded-lg border-slate-300 md:col-span-2">
    <select name="movement_type" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់ប្រភេទ --</option>
        <option value="stock_in" @selected(request('movement_type') === 'stock_in')>បញ្ចូលស្តុក</option>
        <option value="stock_out" @selected(request('movement_type') === 'stock_out')>ដកស្តុក</option>
        <option value="adjustment" @selected(request('movement_type') === 'adjustment')>កែតម្រូវស្តុក</option>
    </select>
    <select name="stock_status" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់ស្ថានភាព --</option>
        <option value="in_stock" @selected(request('stock_status') === 'in_stock')>មានស្តុក</option>
        <option value="low_stock" @selected(request('stock_status') === 'low_stock')>ស្តុកតិច</option>
        <option value="out_of_stock" @selected(request('stock_status') === 'out_of_stock')>អស់ស្តុក</option>
    </select>
    <select name="user_id" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់អ្នកប្រើប្រាស់ --</option>
        @foreach($users as $user)
            <option value="{{ $user->id }}" @selected((string) request('user_id') === (string) $user->id)>{{ $user->name }}</option>
        @endforeach
    </select>
    <input type="date" name="from_date" value="{{ request('from_date') }}" class="rounded-lg border-slate-300">
    <input type="date" name="to_date" value="{{ request('to_date') }}" class="rounded-lg border-slate-300">
    <select name="per_page" class="rounded-lg border-slate-300">
        @foreach([10,25,50] as $size)
            <option value="{{ $size }}" @selected((int) request('per_page', 10) === $size)>{{ $size }} ជួរ</option>
        @endforeach
    </select>
    <div class="flex gap-2 md:col-span-6 md:justify-end">
        <button type="submit" class="rounded-lg bg-slate-700 px-4 py-2 text-white">ស្វែងរក</button>
        <a href="{{ route('stock.history') }}" class="rounded-lg border border-slate-300 px-4 py-2">សម្អាត</a>
    </div>
</form>

<div class="mt-5 overflow-x-auto rounded-xl bg-white shadow-sm">
    <table class="min-w-full divide-y divide-slate-200">
        <thead class="bg-slate-50">
            <tr>
                <th class="px-3 py-3 text-left text-sm text-slate-600">លេខប្រតិបត្តិការ</th>
                <th class="px-3 py-3 text-left text-sm text-slate-600">ផលិតផល</th>
                <th class="px-3 py-3 text-left text-sm text-slate-600">ប្រភេទ</th>
                <th class="px-3 py-3 text-left text-sm text-slate-600">បរិមាណ</th>
                <th class="px-3 py-3 text-left text-sm text-slate-600">មុន → ក្រោយ</th>
                <th class="px-3 py-3 text-left text-sm text-slate-600">លេខយោង / មូលហេតុ</th>
                <th class="px-3 py-3 text-left text-sm text-slate-600">អ្នកធ្វើ</th>
                <th class="px-3 py-3 text-left text-sm text-slate-600">កាលបរិច្ឆេទ</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
        @forelse($movements as $movement)
            @php
                $movementLabel = match($movement->movement_type) {
                    'stock_in' => ['បញ្ចូលស្តុក', 'bg-green-100 text-green-700'],
                    'stock_out' => ['ដកស្តុក', 'bg-red-100 text-red-700'],
                    'adjustment' => ['កែតម្រូវស្តុក', 'bg-blue-100 text-blue-700'],
                    default => [$movement->movement_type, 'bg-slate-100 text-slate-700'],
                };
            @endphp
            <tr>
                <td class="px-3 py-3 font-mono text-xs">#{{ $movement->id }}</td>
                <td class="px-3 py-3"><div class="font-medium">{{ $movement->product->name }}</div><div class="font-mono text-xs text-slate-500">SKU: {{ $movement->product->sku }}</div></td>
                <td class="px-3 py-3"><span class="rounded-full px-2 py-1 text-xs {{ $movementLabel[1] }}">{{ $movementLabel[0] }}</span></td>
                <td class="px-3 py-3">{{ number_format((float) $movement->quantity, 3) }}</td>
                <td class="px-3 py-3">{{ number_format((float) $movement->stock_before, 3) }} → {{ number_format((float) $movement->stock_after, 3) }}</td>
                <td class="px-3 py-3 text-sm"><div>{{ $movement->reference_number ?: '—' }}</div><div class="text-slate-500">{{ $movement->reason ?: $movement->notes ?: '—' }}</div></td>
                <td class="px-3 py-3">{{ $movement->user->name ?? '—' }}</td>
                <td class="px-3 py-3 whitespace-nowrap">{{ app(\App\Services\SystemSettingsService::class)->formatDate($movement->transaction_date ?: $movement->created_at, true) }}</td>
            </tr>
        @empty
            <tr><td colspan="8" class="px-3 py-8 text-center text-slate-500">មិនមានប្រវត្តិស្តុក</td></tr>
        @endforelse
        </tbody>
    </table>
</div>
<div class="mt-4">{{ $movements->links() }}</div>
@endsection
