@extends('layouts.app')
@section('title', 'បញ្ចូលស្តុក')
@section('content')
<div><h1 class="text-2xl font-bold">បញ្ចូលស្តុក</h1><p class="mt-1 text-sm text-slate-500">បន្ថែមបរិមាណស្តុកទៅផលិតផល</p></div>
@include('stock._transaction_form', ['mode' => 'in', 'action' => route('stock.in.store'), 'confirmText' => 'តើអ្នកពិតជាចង់បញ្ចូលស្តុកមែនទេ?'])
@endsection
