@extends('layouts.app')
@section('title', 'ដកស្តុក')
@section('content')
<div><h1 class="text-2xl font-bold">ដកស្តុក</h1><p class="mt-1 text-sm text-slate-500">កាត់បន្ថយបរិមាណស្តុក</p></div>
@include('stock._transaction_form', ['mode' => 'out', 'action' => route('stock.out.store'), 'confirmText' => 'តើអ្នកពិតជាចង់ដកស្តុកមែនទេ?'])
@endsection
