@php($submissionKey = old('submission_key', (string) \Illuminate\Support\Str::uuid()))
<form method="POST" action="{{ $action }}" onsubmit="return confirm('{{ $confirmText }}')" class="mt-5 max-w-4xl rounded-xl bg-white p-5 shadow-sm">
    @csrf
    <input type="hidden" name="submission_key" value="{{ $submissionKey }}">

    <div class="grid gap-4 md:grid-cols-2">
        <div class="md:col-span-2">
            <label for="product_id" class="mb-1 block text-sm font-medium">ផលិតផល <span class="text-red-600">*</span></label>
            <select id="product_id" name="product_id" required class="w-full rounded-lg border-slate-300">
                <option value="">-- ជ្រើសរើសផលិតផល --</option>
                @foreach($products as $product)
                    <option value="{{ $product->id }}" data-quantity="{{ $product->stock_quantity }}" data-unit="{{ $product->unit }}" @selected((string) old('product_id') === (string) $product->id)>
                        {{ $product->name }} (SKU: {{ $product->sku }})
                    </option>
                @endforeach
            </select>
            @error('product_id')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
            <p class="mt-2 text-sm text-slate-500">បរិមាណបច្ចុប្បន្ន: <strong id="current-quantity">—</strong></p>
        </div>

        @if($mode === 'adjustment')
            <div>
                <label for="actual_quantity" class="mb-1 block text-sm font-medium">បរិមាណស្តុកពិតប្រាកដ <span class="text-red-600">*</span></label>
                <input id="actual_quantity" name="actual_quantity" type="number" step="0.001" min="0" required value="{{ old('actual_quantity') }}" class="w-full rounded-lg border-slate-300">
                @error('actual_quantity')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
            </div>
        @else
            <div>
                <label for="quantity" class="mb-1 block text-sm font-medium">បរិមាណ <span class="text-red-600">*</span></label>
                <input id="quantity" name="quantity" type="number" step="0.001" min="0.001" required value="{{ old('quantity') }}" class="w-full rounded-lg border-slate-300">
                @error('quantity')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
            </div>
        @endif

        @if($mode === 'in')
            <div>
                <label for="unit_cost" class="mb-1 block text-sm font-medium">តម្លៃឯកតា (USD)</label>
                <input id="unit_cost" name="unit_cost" type="number" step="0.01" min="0" value="{{ old('unit_cost') }}" class="w-full rounded-lg border-slate-300">
            </div>
        @endif

        <div>
            <label for="reference_number" class="mb-1 block text-sm font-medium">លេខយោង</label>
            <input id="reference_number" name="reference_number" maxlength="255" value="{{ old('reference_number') }}" class="w-full rounded-lg border-slate-300">
        </div>
        <div>
            <label for="transaction_date" class="mb-1 block text-sm font-medium">កាលបរិច្ឆេទប្រតិបត្តិការ <span class="text-red-600">*</span></label>
            <input id="transaction_date" name="transaction_date" type="datetime-local" required value="{{ old('transaction_date', now()->format('Y-m-d\TH:i')) }}" class="w-full rounded-lg border-slate-300">
            @error('transaction_date')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
        </div>

        @if($mode !== 'in')
            <div class="md:col-span-2">
                <label for="reason" class="mb-1 block text-sm font-medium">{{ $mode === 'out' ? 'មូលហេតុដកស្តុក' : 'មូលហេតុកែតម្រូវ' }} <span class="text-red-600">*</span></label>
                <input id="reason" name="reason" maxlength="255" required value="{{ old('reason') }}" class="w-full rounded-lg border-slate-300">
                @error('reason')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
            </div>
        @else
            <div class="md:col-span-2">
                <label for="reason" class="mb-1 block text-sm font-medium">មូលហេតុ</label>
                <input id="reason" name="reason" maxlength="255" value="{{ old('reason') }}" class="w-full rounded-lg border-slate-300">
            </div>
        @endif

        <div class="md:col-span-2">
            <label for="notes" class="mb-1 block text-sm font-medium">កំណត់ចំណាំ</label>
            <textarea id="notes" name="notes" rows="4" maxlength="5000" class="w-full rounded-lg border-slate-300">{{ old('notes') }}</textarea>
        </div>
    </div>
    <div class="mt-6 flex flex-wrap gap-3">
        <button type="submit" class="rounded-lg bg-blue-700 px-4 py-2 text-white">រក្សាទុកប្រតិបត្តិការ</button>
        <a href="{{ route('stock.index') }}" class="rounded-lg border border-slate-300 px-4 py-2 text-slate-700">បោះបង់</a>
    </div>
</form>
<script>
document.getElementById('product_id')?.addEventListener('change', function () {
    const option = this.options[this.selectedIndex];
    document.getElementById('current-quantity').textContent = option.value
        ? Number(option.dataset.quantity).toFixed(3) + ' ' + (option.dataset.unit || '')
        : '—';
});
</script>
