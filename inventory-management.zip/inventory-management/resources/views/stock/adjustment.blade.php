@extends('layouts.app')
@section('title', 'កែតម្រូវស្តុក')
@section('content')
<div><h1 class="text-2xl font-bold">កែតម្រូវស្តុក</h1><p class="mt-1 text-sm text-slate-500">កំណត់ស្តុកតាមបរិមាណពិត</p></div>
@include('stock._transaction_form', ['mode' => 'adjustment', 'action' => route('stock.adjustment.store'), 'confirmText' => 'តើអ្នកពិតជាចង់កែតម្រូវស្តុកមែនទេ?'])
@endsection
