<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'ប្រព័ន្ធគ្រប់គ្រងសារពើភ័ណ្ឌ')</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Khmer:wght@400;500;600;700&display=swap" rel="stylesheet">
    @vite(['resources/css/app.css', 'resources/js/app.js', 'resources/js/dashboard.js'])
</head>
<body class="min-h-screen bg-slate-100 text-slate-800 antialiased">
@auth
<div class="min-h-screen lg:flex">
    <aside id="sidebar" class="fixed inset-y-0 left-0 z-40 flex w-64 -translate-x-full flex-col overflow-y-auto bg-slate-950 text-white shadow-xl transition-transform lg:sticky lg:top-0 lg:h-screen lg:translate-x-0 lg:flex-shrink-0 lg:shadow-none">
        <div class="flex items-center justify-between border-b border-white/10 px-5 py-5">
            <a href="{{ route('dashboard') }}" class="flex min-w-0 items-center gap-3 font-bold text-lg">
                @if(!empty($systemSettings['store_logo']))<img src="{{ asset('storage/'.$systemSettings['store_logo']) }}" alt="" class="h-8 w-8 rounded object-contain">@endif
                <span class="truncate">{{ $systemSettings['store_name'] ?: ($systemSettings['system_name'] ?? 'សារពើភ័ណ្ឌ') }}</span>
            </a>
            <button id="sidebar-close" type="button" class="rounded p-2 lg:hidden" aria-label="បិទម៉ឺនុយ">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <nav aria-label="ម៉ឺនុយចម្បង" class="flex-1 space-y-1 px-3 py-4">
            <a href="{{ route('dashboard') }}" @if(request()->routeIs('dashboard')) aria-current="page" @endif class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition {{ request()->routeIs('dashboard') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"><svg class="h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/></svg>ផ្ទាំងគ្រប់គ្រង</a>
            @if(auth()->user()->hasRole('admin') || auth()->user()->hasPermission('users.manage'))
                <a href="{{ route('users.index') }}" @if(request()->routeIs('users.*')) aria-current="page" @endif class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition {{ request()->routeIs('users.*') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"><svg class="h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2m6-10a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm7-3h6m-3-3v6"/></svg>គណនីអ្នកប្រើប្រាស់</a>
            @endif
            @if(auth()->user()->hasRole('admin') || auth()->user()->hasPermission('roles.manage'))
                <a href="{{ route('roles.index') }}" @if(request()->routeIs('roles.*')) aria-current="page" @endif class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition {{ request()->routeIs('roles.*') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"><svg class="h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 3 4 7v5c0 5 3.5 8 8 9 4.5-1 8-4 8-9V7zm-3 9 2 2 4-4"/></svg>តួនាទី និងសិទ្ធិ</a>
            @endif
            @if(auth()->user()->hasRole('admin') || auth()->user()->hasPermission('categories.manage'))
                <a href="{{ route('categories.index') }}" @if(request()->routeIs('categories.*')) aria-current="page" @endif class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition {{ request()->routeIs('categories.*') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"><svg class="h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/></svg>ប្រភេទផលិតផល</a>
            @endif
            @if(auth()->user()->hasRole('admin') || auth()->user()->hasPermission('products.manage') || auth()->user()->hasPermission('products.view'))
                <a href="{{ route('products.index') }}" @if(request()->routeIs('products.*')) aria-current="page" @endif class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition {{ request()->routeIs('products.*') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"><svg class="h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="m12 3 9 5-9 5-9-5zm-9 9 9 5 9-5m-18 5 9 5 9-5"/></svg>ផលិតផល</a>
            @endif
            @if(auth()->user()->hasRole('admin') || auth()->user()->hasPermission('suppliers.manage'))
                <a href="{{ route('suppliers.index') }}" @if(request()->routeIs('suppliers.*')) aria-current="page" @endif class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition {{ request()->routeIs('suppliers.*') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"><svg class="h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2m6-10a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm7-5h5m-2.5-2.5v5"/></svg>អ្នកផ្គត់ផ្គង់</a>
            @endif
            @if(auth()->user()->hasPermission('stock.manage') || auth()->user()->hasPermission('stock.view') || auth()->user()->hasRole('admin'))
                <a href="{{ route('stock.index') }}" @if(request()->routeIs('stock.*')) aria-current="page" @endif class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition {{ request()->routeIs('stock.*') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"><svg class="h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M3 7 12 3l9 4-9 4zm0 5 9 4 9-4m-18 5 9 4 9-4M3 7v10m18-10v10M12 11v10"/></svg>គ្រប់គ្រងស្តុក</a>
            @endif
            @if(auth()->user()->hasRole('admin') || auth()->user()->hasPermission('purchases.manage'))
                <a href="{{ route('purchases.index') }}" @if(request()->routeIs('purchases.*')) aria-current="page" @endif class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition {{ request()->routeIs('purchases.*') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"><svg class="h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M3 7h18l-2 13H5zm5 0 4-4 4 4m-4 4v5"/></svg>ការទិញ</a>
            @endif
            @if(auth()->user()->hasPermission('sales.manage') || auth()->user()->hasPermission('sales.view') || auth()->user()->hasPermission('sales.create') || auth()->user()->hasRole('admin'))
                <a href="{{ route('sales.index') }}" @if(request()->routeIs('sales.*')) aria-current="page" @endif class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition {{ request()->routeIs('sales.*') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"><svg class="h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M3 3v18h18M7 14l4-4 4 4 6-7"/></svg>ការលក់ / POS</a>
            @endif
            @if(auth()->user()->hasRole('admin') || auth()->user()->hasRole('manager') || auth()->user()->hasPermission('reports.view'))
                <a href="{{ route('reports.index') }}" @if(request()->routeIs('reports.*')) aria-current="page" @endif class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition {{ request()->routeIs('reports.*') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"><svg class="h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 19V5m0 14h17M8 15l4-4 3 3 5-7"/></svg>របាយការណ៍</a>
            @endif
            <a href="{{ route('notifications.index') }}" @if(request()->routeIs('notifications.*')) aria-current="page" @endif class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition {{ request()->routeIs('notifications.*') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"><svg class="h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9m-8 13h4"/></svg>ការជូនដំណឹង</a>
            @if(auth()->user()->hasRole('admin') || auth()->user()->hasPermission('activity-logs.view') || auth()->user()->hasPermission('activity-logs.manage'))
                <a href="{{ route('activity-logs.index') }}" @if(request()->routeIs('activity-logs.*')) aria-current="page" @endif class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition {{ request()->routeIs('activity-logs.*') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"><svg class="h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/></svg>កំណត់ហេតុសកម្មភាព</a>
            @endif
            @if(auth()->user()->hasRole('admin') || auth()->user()->hasPermission('products.manage') || auth()->user()->hasPermission('products.view'))
                <a href="{{ route('barcodes.index') }}" @if(request()->routeIs('barcodes.*') || request()->routeIs('products.barcode*') || request()->routeIs('products.qr*')) aria-current="page" @endif class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition {{ request()->routeIs('barcodes.*') || request()->routeIs('products.barcode*') || request()->routeIs('products.qr*') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"><svg class="h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 5v14m3-14v14m4-14v14m3-14v14m3-14v14m3-14v14"/></svg>Barcode និង QR</a>
            @endif
            @if(auth()->user()->hasRole('admin'))
                <a href="{{ route('settings.edit') }}" @if(request()->routeIs('settings.*')) aria-current="page" @endif class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition {{ request()->routeIs('settings.*') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"><svg class="h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.7a8 8 0 0 1-1.5.9l-.3 1.8h-2.8l-.3-1.8a8 8 0 0 1-1.5-.9l-1.7.7-1.4-2.4 1.4-1.1a8 8 0 0 1 0-1.8l-1.4-1.1 1.4-2.4 1.7.7a8 8 0 0 1 1.5-.9l.3-1.8h2.8l.3 1.8a8 8 0 0 1 1.5.9l1.7-.7 1.4 2.4-1.4 1.1a8 8 0 0 1-.1 1.8z"/></svg>ការកំណត់ប្រព័ន្ធ</a>
            @endif
            <a href="{{ route('profile.edit') }}" @if(request()->routeIs('profile.*')) aria-current="page" @endif class="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition {{ request()->routeIs('profile.*') ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white' }}"><svg class="h-5 w-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M5 21a7 7 0 0 1 14 0"/></svg>ប្រវត្តិរូប</a>
        </nav>
    </aside>
    <div id="sidebar-overlay" class="fixed inset-0 z-30 hidden bg-black/40 lg:hidden"></div>
    <main class="flex-1 min-w-0">
        <header class="relative bg-white border-b px-4 py-3 flex items-center justify-between gap-4">
            <button id="sidebar-open" type="button" class="rounded-lg border p-2 lg:hidden" aria-label="បើកម៉ឺនុយ">
                <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
            </button>
            <div class="ml-auto flex items-center gap-2">
                <div class="relative">
                    <button id="notification-button" type="button" class="relative rounded-full p-2 text-slate-600 hover:bg-slate-100" aria-label="ការជូនដំណឹង" aria-expanded="false">
                        <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></svg>
                        @php($unreadNotificationsCount = auth()->user()->unreadNotifications()->count())
                        @if($unreadNotificationsCount > 0)
                            <span class="absolute -right-1 -top-1 min-w-5 rounded-full bg-red-600 px-1 text-center text-xs leading-5 text-white">{{ $unreadNotificationsCount > 99 ? '99+' : $unreadNotificationsCount }}</span>
                        @endif
                    </button>
                    <div id="notification-menu" class="absolute right-0 z-50 mt-2 hidden w-80 max-w-[90vw] rounded-xl border bg-white shadow-xl">
                        <div class="flex items-center justify-between border-b px-4 py-3">
                            <strong class="text-sm">ការជូនដំណឹង</strong>
                            <a href="{{ route('notifications.index') }}" class="text-xs text-blue-700">មើលទាំងអស់</a>
                        </div>
                        <div id="notification-items" class="max-h-80 overflow-y-auto" data-endpoint="{{ route('notifications.recent') }}">
                            <p class="px-4 py-6 text-center text-sm text-slate-500">ចុចដើម្បីផ្ទុកការជូនដំណឹង។</p>
                        </div>
                    </div>
                </div>
                <div class="relative">
                    <button id="profile-button" type="button" class="flex items-center gap-2 rounded-lg px-2 py-1 hover:bg-slate-100" aria-expanded="false">
                        <span class="grid h-8 w-8 place-items-center rounded-full bg-slate-800 text-xs text-white">{{ mb_substr(auth()->user()->name, 0, 1) }}</span>
                        <span class="hidden text-sm sm:block">{{ auth()->user()->name }}</span>
                        <svg class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.51a.75.75 0 01-1.08 0l-4.25-4.51a.75.75 0 01.02-1.06z"/></svg>
                    </button>
                    <div id="profile-menu" class="absolute right-0 mt-2 hidden w-44 rounded-lg border bg-white py-1 shadow-lg">
                        <a href="{{ route('profile.edit') }}" class="block px-4 py-2 text-sm hover:bg-slate-100">ប្រវត្តិរូប</a>
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <button type="submit" class="block w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-slate-100">ចាកចេញ</button>
                        </form>
                    </div>
                </div>
            </div>
        </header>
        <div class="p-5 md:p-8">
            @if(session('success'))
                <div class="mb-5 rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-green-800">{{ session('success') }}</div>
            @endif
            @if(session('error'))
                <div class="mb-5 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-red-800">{{ session('error') }}</div>
            @endif
            @if($errors->any())
                <div class="mb-5 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-red-800">
                    <ul class="list-disc pl-5">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
                </div>
            @endif
            @yield('content')
        </div>
    </main>
</div>
@else
@yield('content')
@endauth
</body>
</html>
