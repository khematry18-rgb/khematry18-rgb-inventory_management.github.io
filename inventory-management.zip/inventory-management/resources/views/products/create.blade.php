@extends('layouts.app')
@section('title', 'បង្កើតផលិតផល')
@section('content')
<div>
    <h1 class="text-2xl font-bold text-slate-900">បង្កើតផលិតផល</h1>
    <p class="mt-1 text-sm text-slate-500">បរិមាណដំបូងនឹងត្រូវបានកត់ត្រាទៅប្រវត្តិស្តុក</p>
</div>
@include('products._form', [
    'action' => route('products.store'),
    'method' => 'POST',
    'product' => null,
    'categories' => $categories,
])
@endsection
