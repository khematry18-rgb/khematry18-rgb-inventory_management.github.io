@extends('layouts.app')
@section('title', 'កែសម្រួលផលិតផល')
@section('content')
<div>
    <h1 class="text-2xl font-bold text-slate-900">កែសម្រួលផលិតផល</h1>
    <p class="mt-1 text-sm text-slate-500">{{ $product->name }} · {{ $product->sku }}</p>
    @if(!$product->barcode)
        <form method="POST" action="{{ route('products.barcode.generate', $product) }}" class="mt-3">
            @csrf
            <button class="rounded-lg border border-blue-700 px-4 py-2 text-sm text-blue-700">បង្កើត Barcode ផ្ទៃក្នុងពី SKU</button>
        </form>
    @endif
</div>
@include('products._form', [
    'action' => route('products.update', $product),
    'method' => 'PUT',
    'product' => $product,
    'categories' => $categories,
])
@endsection
