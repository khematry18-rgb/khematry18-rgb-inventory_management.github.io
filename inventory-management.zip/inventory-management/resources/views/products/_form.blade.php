<form method="POST" action="{{ $action }}" enctype="multipart/form-data" class="mt-5 grid gap-5 lg:grid-cols-3">
    @csrf
    @if($method !== 'POST') @method($method) @endif

    <div class="rounded-xl bg-white p-5 shadow-sm lg:col-span-2">
        <div class="grid gap-4 md:grid-cols-2">
            <div class="md:col-span-2">
                <label for="name" class="mb-1 block text-sm font-medium">ឈ្មោះផលិតផល <span class="text-red-600">*</span></label>
                <input id="name" name="name" required maxlength="255" value="{{ old('name', $product?->name) }}" class="w-full rounded-lg border-slate-300">
                @error('name')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
            </div>
            <div>
                <label for="sku" class="mb-1 block text-sm font-medium">SKU <span class="text-red-600">*</span></label>
                <input id="sku" name="sku" @required($product || !($settings['auto_generate_sku'] ?? false)) maxlength="100" value="{{ old('sku', $product?->sku) }}" placeholder="{{ !$product && ($settings['auto_generate_sku'] ?? false) ? 'ទុកទទេ ដើម្បីបង្កើត SKU' : '' }}" class="w-full rounded-lg border-slate-300 font-mono">
                @error('sku')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
            </div>
            <div>
                <label for="barcode" class="mb-1 block text-sm font-medium">Barcode</label>
                <input id="barcode" name="barcode" maxlength="100" value="{{ old('barcode', $product?->barcode) }}" class="w-full rounded-lg border-slate-300 font-mono">
                @if(!$product)<p class="mt-1 text-xs text-slate-500">ទុកទទេ ដើម្បីបង្កើត Barcode ផ្ទៃក្នុង CODE128 ពី SKU ដោយស្វ័យប្រវត្តិ។</p>@endif
                @error('barcode')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
            </div>
            <div>
                <label for="category_id" class="mb-1 block text-sm font-medium">ប្រភេទ <span class="text-red-600">*</span></label>
                <select id="category_id" name="category_id" required class="w-full rounded-lg border-slate-300">
                    <option value="">-- ជ្រើសរើសប្រភេទ --</option>
                    @foreach($categories as $category)
                        <option value="{{ $category->id }}" @selected((string) old('category_id', $product?->category_id) === (string) $category->id)>{{ $category->name }}</option>
                    @endforeach
                </select>
                @error('category_id')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
            </div>
            <div>
                <label for="unit" class="mb-1 block text-sm font-medium">ឯកតា <span class="text-red-600">*</span></label>
                <input id="unit" name="unit" required maxlength="30" value="{{ old('unit', $product?->unit ?? ($settings['default_product_unit'] ?? 'pcs')) }}" placeholder="pcs, box, kg" class="w-full rounded-lg border-slate-300">
                @error('unit')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
            </div>
            <div>
                <label for="cost_price" class="mb-1 block text-sm font-medium">តម្លៃដើម (USD) <span class="text-red-600">*</span></label>
                <input id="cost_price" name="cost_price" type="number" step="0.01" min="0" required value="{{ old('cost_price', $product?->cost_price) }}" class="w-full rounded-lg border-slate-300">
                @error('cost_price')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
            </div>
            <div>
                <label for="selling_price" class="mb-1 block text-sm font-medium">តម្លៃលក់ (USD) <span class="text-red-600">*</span></label>
                <input id="selling_price" name="selling_price" type="number" step="0.01" min="0" required value="{{ old('selling_price', $product?->selling_price) }}" class="w-full rounded-lg border-slate-300">
                @error('selling_price')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
            </div>
            @if(!$product)
            <div>
                <label for="stock_quantity" class="mb-1 block text-sm font-medium">បរិមាណស្តុកដំបូង <span class="text-red-600">*</span></label>
                <input id="stock_quantity" name="stock_quantity" type="number" step="0.001" min="0" required value="{{ old('stock_quantity', 0) }}" class="w-full rounded-lg border-slate-300">
                @error('stock_quantity')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
            </div>
            @else
            <div>
                <label class="mb-1 block text-sm font-medium">បរិមាណស្តុកបច្ចុប្បន្ន</label>
                <div class="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2">{{ number_format((float) $product->stock_quantity, 3) }} {{ $product->unit }}</div>
                <p class="mt-1 text-xs text-slate-500">ស្តុកត្រូវកែតាម Purchase/Sales module ឬការកែតម្រូវស្តុកបន្ទាប់។</p>
            </div>
            @endif
            <div>
                <label for="minimum_stock" class="mb-1 block text-sm font-medium">ស្តុកអប្បបរមា <span class="text-red-600">*</span></label>
                <input id="minimum_stock" name="minimum_stock" type="number" step="0.001" min="0" required value="{{ old('minimum_stock', $product?->minimum_stock ?? ($settings['default_minimum_stock'] ?? 0)) }}" class="w-full rounded-lg border-slate-300">
                @error('minimum_stock')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
            </div>
            <div>
                <label for="is_active" class="mb-1 block text-sm font-medium">ស្ថានភាព</label>
                <select id="is_active" name="is_active" required class="w-full rounded-lg border-slate-300">
                    <option value="1" @selected((string) old('is_active', $product?->is_active ?? 1) === '1')>សកម្ម</option>
                    <option value="0" @selected((string) old('is_active', $product?->is_active ?? 1) === '0')>អសកម្ម</option>
                </select>
            </div>
            <div class="md:col-span-2">
                <label for="description" class="mb-1 block text-sm font-medium">សេចក្តីពណ៌នា</label>
                <textarea id="description" name="description" rows="5" maxlength="5000" class="w-full rounded-lg border-slate-300">{{ old('description', $product?->description) }}</textarea>
                @error('description')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
            </div>
        </div>
    </div>

    <div class="rounded-xl bg-white p-5 shadow-sm">
        <label for="image" class="mb-2 block text-sm font-medium">រូបភាពផលិតផល</label>
        <input id="image" name="image" type="file" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" class="block w-full text-sm">
        @error('image')<p class="mt-1 text-sm text-red-600">{{ $message }}</p>@enderror
        <div class="mt-4 overflow-hidden rounded-lg border border-slate-200 bg-slate-50">
            <img id="image-preview" src="{{ $product?->image ? asset('storage/'.$product->image) : '' }}" alt="មើលរូបភាពផលិតផល" class="{{ $product?->image ? 'h-64 w-full object-contain' : 'hidden h-64 w-full object-contain' }}">
            <div id="image-placeholder" class="{{ $product?->image ? 'hidden' : '' }} grid h-64 place-items-center text-sm text-slate-400">មិនទាន់មានរូបភាព</div>
        </div>
        <div class="mt-6 flex flex-wrap gap-3">
            <button type="submit" class="rounded-lg bg-blue-700 px-4 py-2 text-white hover:bg-blue-800">រក្សាទុក</button>
            <a href="{{ route('products.index') }}" class="rounded-lg border border-slate-300 px-4 py-2">បោះបង់</a>
        </div>
    </div>
</form>
<script>
document.getElementById('image')?.addEventListener('change', function () {
    const file = this.files?.[0];
    const preview = document.getElementById('image-preview');
    const placeholder = document.getElementById('image-placeholder');
    if (!file) return;
    preview.src = URL.createObjectURL(file);
    preview.classList.remove('hidden');
    placeholder.classList.add('hidden');
});
</script>
