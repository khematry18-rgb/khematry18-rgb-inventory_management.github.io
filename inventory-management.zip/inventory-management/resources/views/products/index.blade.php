@extends('layouts.app')
@section('title', 'ផលិតផល')
@section('content')
@php
    $canManage = auth()->user()->hasPermission('products.manage');
@endphp
<div class="flex flex-wrap items-center justify-between gap-3">
    <div>
        <h1 class="text-2xl font-bold text-slate-900">បញ្ជីផលិតផល</h1>
        <p class="mt-1 text-sm text-slate-500">ស្វែងរក តម្រង និងត្រួតពិនិត្យស្តុកផលិតផល</p>
    </div>
    @if($canManage)
        <div class="flex flex-wrap gap-2">
            <a href="{{ route('barcodes.index') }}" class="rounded-lg border border-slate-300 px-4 py-2 text-slate-700">បោះពុម្ព Barcode / QR</a>
            <a href="{{ route('products.create') }}" class="rounded-lg bg-blue-700 px-4 py-2 text-white hover:bg-blue-800">បង្កើតផលិតផល</a>
        </div>
    @endif
</div>

<form method="GET" class="mt-5 grid gap-3 rounded-xl bg-white p-4 shadow-sm md:grid-cols-6">
    <input type="search" name="search" value="{{ request('search') }}" placeholder="ឈ្មោះ, SKU ឬ Barcode" class="rounded-lg border-slate-300 md:col-span-2">
    <select name="category_id" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់ប្រភេទ --</option>
        @foreach($categories as $category)
            <option value="{{ $category->id }}" @selected((string) request('category_id') === (string) $category->id)>{{ $category->name }}</option>
        @endforeach
    </select>
    <select name="is_active" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់ស្ថានភាព --</option>
        <option value="1" @selected(request('is_active') === '1')>សកម្ម</option>
        <option value="0" @selected(request('is_active') === '0')>អសកម្ម</option>
    </select>
    <select name="stock_status" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់ស្តុក --</option>
        <option value="in_stock" @selected(request('stock_status') === 'in_stock')>មានស្តុក</option>
        <option value="low_stock" @selected(request('stock_status') === 'low_stock')>ស្តុកតិច</option>
        <option value="out_of_stock" @selected(request('stock_status') === 'out_of_stock')>អស់ស្តុក</option>
    </select>
    <select name="per_page" class="rounded-lg border-slate-300">
        @foreach([10, 25, 50] as $size)
            <option value="{{ $size }}" @selected((int) request('per_page', 10) === $size)>{{ $size }} ជួរ</option>
        @endforeach
    </select>
    <div class="flex gap-2 md:col-span-6 md:justify-end">
        <button type="submit" class="rounded-lg bg-slate-700 px-4 py-2 text-white">ស្វែងរក</button>
        <a href="{{ route('products.index') }}" class="rounded-lg border border-slate-300 px-4 py-2 text-slate-700">សម្អាត</a>
    </div>
</form>

<div class="mt-5 overflow-x-auto rounded-xl bg-white shadow-sm">
    <table class="min-w-full divide-y divide-slate-200">
        <thead class="bg-slate-50">
            <tr>
                <th class="px-4 py-3 text-left text-sm text-slate-600">រូបភាព</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">ផលិតផល</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">ប្រភេទ</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">តម្លៃលក់</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">ស្តុក</th>
                <th class="px-4 py-3 text-left text-sm text-slate-600">ស្ថានភាព</th>
                @if($canManage)<th class="px-4 py-3 text-right text-sm text-slate-600">សកម្មភាព</th>@endif
            </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
        @forelse($products as $product)
            @php
                if ((float) $product->stock_quantity <= 0) {
                    $stockLabel = 'អស់ស្តុក'; $stockClass = 'bg-red-100 text-red-700';
                } elseif ((float) $product->stock_quantity <= (float) $product->minimum_stock) {
                    $stockLabel = 'ស្តុកតិច'; $stockClass = 'bg-amber-100 text-amber-700';
                } else {
                    $stockLabel = 'មានស្តុក'; $stockClass = 'bg-green-100 text-green-700';
                }
            @endphp
            <tr>
                <td class="px-4 py-3">
                    @if($product->image)
                        <img src="{{ asset('storage/'.$product->image) }}" alt="{{ $product->name }}" class="h-12 w-12 rounded-lg object-cover">
                    @else
                        <div class="grid h-12 w-12 place-items-center rounded-lg bg-slate-100 text-xs text-slate-400">N/A</div>
                    @endif
                </td>
                <td class="px-4 py-3">
                    <a href="{{ route('products.show', $product) }}" class="font-medium text-blue-700 hover:text-blue-900">{{ $product->name }}</a>
                    <div class="mt-1 font-mono text-xs text-slate-500">SKU: {{ $product->sku }}</div>
                    <div class="mt-1 font-mono text-xs text-slate-500">Barcode: {{ $product->barcode ?: '—' }}</div>
                </td>
                <td class="px-4 py-3">{{ $product->category->name ?? '—' }}</td>
                <td class="px-4 py-3">{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float) $product->selling_price, 'USD') }}</td>
                <td class="px-4 py-3">
                    <div>{{ number_format((float) $product->stock_quantity, 3) }} {{ $product->unit }}</div>
                    <div class="mt-1 text-xs text-slate-500">អប្បបរមា {{ number_format((float) $product->minimum_stock, 3) }}</div>
                    <span class="mt-1 inline-block rounded-full px-2 py-1 text-xs {{ $stockClass }}">{{ $stockLabel }}</span>
                </td>
                <td class="px-4 py-3">
                    <span class="rounded-full px-2 py-1 text-xs {{ $product->is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' }}">{{ $product->is_active ? 'សកម្ម' : 'អសកម្ម' }}</span>
                </td>
                @if($canManage)
                <td class="px-4 py-3 text-right whitespace-nowrap">
                    <a href="{{ route('products.edit', $product) }}" class="text-blue-700 hover:text-blue-900">កែសម្រួល</a>
                    <form method="POST" action="{{ route('products.destroy', $product) }}" class="inline" onsubmit="return confirm('តើអ្នកពិតជាចង់លុបផលិតផល {{ addslashes($product->name) }} មែនទេ?')">
                        @csrf @method('DELETE')
                        <button type="submit" class="ml-3 text-red-700 hover:text-red-900">លុប</button>
                    </form>
                </td>
                @endif
            </tr>
        @empty
            <tr><td colspan="{{ $canManage ? 7 : 6 }}" class="px-4 py-8 text-center text-slate-500">មិនមានទិន្នន័យផលិតផល</td></tr>
        @endforelse
        </tbody>
    </table>
</div>
<div class="mt-4">{{ $products->links() }}</div>
@endsection
