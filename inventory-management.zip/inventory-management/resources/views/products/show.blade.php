@extends('layouts.app')
@section('title', 'ព័ត៌មានផលិតផល')
@section('content')
@php
    if ((float) $product->stock_quantity <= 0) {
        $stockLabel = 'អស់ស្តុក'; $stockClass = 'bg-red-100 text-red-700';
    } elseif ((float) $product->stock_quantity <= (float) $product->minimum_stock) {
        $stockLabel = 'ស្តុកតិច'; $stockClass = 'bg-amber-100 text-amber-700';
    } else {
        $stockLabel = 'មានស្តុក'; $stockClass = 'bg-green-100 text-green-700';
    }
    $canManage = auth()->user()->hasPermission('products.manage');
@endphp
<div class="grid gap-5 lg:grid-cols-3">
    <div class="rounded-xl bg-white p-6 shadow-sm lg:col-span-1">
        @if($product->image)
            <img src="{{ asset('storage/'.$product->image) }}" alt="{{ $product->name }}" class="h-64 w-full rounded-lg object-contain">
        @else
            <div class="grid h-64 place-items-center rounded-lg bg-slate-100 text-slate-400">មិនមានរូបភាព</div>
        @endif
    </div>
    <div class="rounded-xl bg-white p-6 shadow-sm lg:col-span-2">
        <div class="flex flex-wrap items-start justify-between gap-3">
            <div>
                <h1 class="text-2xl font-bold text-slate-900">{{ $product->name }}</h1>
                <p class="mt-1 font-mono text-sm text-slate-500">SKU: {{ $product->sku }}</p>
            </div>
            <span class="rounded-full px-2 py-1 text-xs {{ $stockClass }}">{{ $stockLabel }}</span>
        </div>
        <dl class="mt-6 grid gap-5 sm:grid-cols-2">
            <div><dt class="text-sm text-slate-500">ប្រភេទ</dt><dd class="mt-1 font-medium">{{ $product->category->name ?? '—' }}</dd></div>
            <div class="sm:col-span-2">
                <dt class="text-sm text-slate-500">Barcode</dt>
                <dd class="mt-1 font-mono">{{ $product->barcode ?: '—' }}</dd>
                @if($product->barcode)
                    <div class="mt-3 flex flex-wrap items-center gap-4">
                        <img src="{{ route('products.barcode', $product) }}" alt="Barcode {{ $product->barcode }}" class="max-h-20 max-w-xs bg-white">
                        <a href="{{ route('products.barcode.download', $product) }}" class="text-sm text-blue-700">ទាញយក Barcode SVG</a>
                    </div>
                @elseif($canManage)
                    <p class="mt-2 text-sm text-slate-500">មិនទាន់មានលេខ Barcode សម្រាប់ផលិតផលនេះទេ។</p>
                @endif
            </div>
            <div><dt class="text-sm text-slate-500">តម្លៃដើម</dt><dd class="mt-1">{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float) $product->cost_price, 'USD') }}</dd></div>
            <div><dt class="text-sm text-slate-500">តម្លៃលក់</dt><dd class="mt-1">{{ app(\App\Services\SystemSettingsService::class)->formatAmount((float) $product->selling_price, 'USD') }}</dd></div>
            <div><dt class="text-sm text-slate-500">បរិមាណបច្ចុប្បន្ន</dt><dd class="mt-1">{{ number_format((float) $product->stock_quantity, 3) }} {{ $product->unit }}</dd></div>
            <div><dt class="text-sm text-slate-500">ស្តុកអប្បបរមា</dt><dd class="mt-1">{{ number_format((float) $product->minimum_stock, 3) }} {{ $product->unit }}</dd></div>
            <div><dt class="text-sm text-slate-500">ស្ថានភាព</dt><dd class="mt-1">{{ $product->is_active ? 'សកម្ម' : 'អសកម្ម' }}</dd></div>
            <div><dt class="text-sm text-slate-500">កាលបរិច្ឆេទបង្កើត</dt><dd class="mt-1">{{ app(\App\Services\SystemSettingsService::class)->formatDate($product->created_at, true) }}</dd></div>
            <div class="sm:col-span-2"><dt class="text-sm text-slate-500">សេចក្តីពណ៌នា</dt><dd class="mt-1 whitespace-pre-line">{{ $product->description ?: '—' }}</dd></div>
        </dl>
        <div class="mt-6 flex flex-wrap gap-3">
            @if($canManage)<a href="{{ route('products.edit', $product) }}" class="rounded-lg bg-blue-700 px-4 py-2 text-white">កែសម្រួល</a>@endif
            @if($canManage && !$product->barcode)
                <form method="POST" action="{{ route('products.barcode.generate', $product) }}">
                    @csrf
                    <button class="rounded-lg border border-blue-700 px-4 py-2 text-blue-700">បង្កើត Barcode</button>
                </form>
            @endif
            <a href="{{ route('products.index') }}" class="rounded-lg border border-slate-300 px-4 py-2">ត្រឡប់ក្រោយ</a>
        </div>
    </div>
</div>

<section class="mt-5 grid gap-5 rounded-xl bg-white p-6 shadow-sm md:grid-cols-[1fr_auto]">
    <div>
        <h2 class="text-lg font-semibold">QR Code ផលិតផល</h2>
        <p class="mt-1 text-sm text-slate-500">QR Code នេះភ្ជាប់ទៅកាន់ទំព័រផលិតផលដែលទាមទារការចូលប្រើ និងសិទ្ធិមើលផលិតផល។</p>
        <a href="{{ route('products.qr.download', $product) }}" class="mt-4 inline-block text-sm text-blue-700">ទាញយក QR Code SVG</a>
    </div>
    <img src="{{ route('products.qr', $product) }}" alt="QR Code សម្រាប់ {{ $product->name }}" class="h-40 w-40">
</section>

<section class="mt-5 rounded-xl bg-white p-6 shadow-sm">
    <h2 class="text-lg font-semibold">ប្រវត្តិស្តុក</h2>
    <div class="mt-4 overflow-x-auto">
        <table class="min-w-full divide-y">
            <thead class="bg-slate-50"><tr><th class="px-3 py-3 text-left text-sm">ប្រភេទ</th><th class="px-3 py-3 text-left text-sm">បរិមាណ</th><th class="px-3 py-3 text-left text-sm">មុន</th><th class="px-3 py-3 text-left text-sm">ក្រោយ</th><th class="px-3 py-3 text-left text-sm">មូលហេតុ</th><th class="px-3 py-3 text-left text-sm">កាលបរិច្ឆេទ</th></tr></thead>
            <tbody class="divide-y">
            @forelse($product->stockMovements as $movement)
                <tr><td class="px-3 py-3">{{ $movement->movement_type }}</td><td class="px-3 py-3">{{ number_format((float) $movement->quantity, 3) }}</td><td class="px-3 py-3">{{ number_format((float) $movement->stock_before, 3) }}</td><td class="px-3 py-3">{{ number_format((float) $movement->stock_after, 3) }}</td><td class="px-3 py-3">{{ $movement->reason ?: '—' }}</td><td class="px-3 py-3">{{ app(\App\Services\SystemSettingsService::class)->formatDate($movement->created_at, true) }}</td></tr>
            @empty
                <tr><td colspan="6" class="px-3 py-8 text-center text-slate-500">គ្មានប្រវត្តិស្តុក</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
</section>
@endsection
