<form method="POST" action="{{ $action }}" class="mt-5 max-w-3xl rounded-xl bg-white p-5 shadow-sm">
    @csrf @if($method !== 'POST') @method($method)
    <div class="grid gap-4 md:grid-cols-2">
        <div><label class="mb-1 block text-sm font-medium">ឈ្មោះ</label><input name="name" required value="{{ old('name', $user?->name) }}" class="w-full rounded-lg border-slate-300"></div>
        <div><label class="mb-1 block text-sm font-medium">អ៊ីមែល</label><input type="email" name="email" required value="{{ old('email', $user?->email) }}" class="w-full rounded-lg border-slate-300"></div>
        <div><label class="mb-1 block text-sm font-medium">លេខទូរស័ព្ទ</label><input name="phone" value="{{ old('phone', $user?->phone) }}" class="w-full rounded-lg border-slate-300"></div>
        <div><label class="mb-1 block text-sm font-medium">តួនាទី</label><select name="role_id" required class="w-full rounded-lg border-slate-300"><option value="">-- ជ្រើសរើស --</option>@foreach($roles as $role)<option value="{{ $role->id }}" @selected(old('role_id', $user?->role_id) == $role->id)>{{ $role->name }}</option>@endforeach</select></div>
        @if(!$user)
            <div><label class="mb-1 block text-sm font-medium">លេខសម្ងាត់</label><input type="password" name="password" required minlength="8" class="w-full rounded-lg border-slate-300"></div>
            <div><label class="mb-1 block text-sm font-medium">បញ្ជាក់លេខសម្ងាត់</label><input type="password" name="password_confirmation" required class="w-full rounded-lg border-slate-300"></div>
        @endif
        <div><label class="mb-1 block text-sm font-medium">ស្ថានភាព</label><select name="is_active" class="w-full rounded-lg border-slate-300"><option value="1" @selected(old('is_active', $user?->is_active ?? 1) == 1)>សកម្ម</option><option value="0" @selected(old('is_active', $user?->is_active ?? 1) == 0)>អសកម្ម</option></select></div>
    </div>
    <div class="mt-6 flex gap-3"><button class="rounded-lg bg-blue-700 px-4 py-2 text-white">រក្សាទុក</button><a href="{{ route('users.index') }}" class="rounded-lg border px-4 py-2">បោះបង់</a></div>
</form>
