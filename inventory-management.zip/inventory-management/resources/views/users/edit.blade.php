@extends('layouts.app')
@section('title', 'កែសម្រួលអ្នកប្រើប្រាស់')
@section('content')
<h1 class="text-2xl font-bold">កែសម្រួលអ្នកប្រើប្រាស់</h1>
@include('users._form', ['action' => route('users.update', $user), 'method' => 'PUT', 'user' => $user, 'roles' => $roles])
@endsection
