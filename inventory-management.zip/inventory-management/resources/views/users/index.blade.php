@extends('layouts.app')
@section('title', 'អ្នកប្រើប្រាស់')
@section('content')
<div class="flex flex-wrap items-center justify-between gap-3">
    <h1 class="text-2xl font-bold">បញ្ជីអ្នកប្រើប្រាស់</h1>
    <a href="{{ route('users.create') }}" class="rounded-lg bg-blue-700 px-4 py-2 text-white hover:bg-blue-800">បង្កើតអ្នកប្រើប្រាស់</a>
</div>
<form method="GET" class="mt-5 grid gap-3 rounded-xl bg-white p-4 shadow-sm md:grid-cols-4">
    <input type="search" name="search" value="{{ request('search') }}" placeholder="ស្វែងរកឈ្មោះ ឬអ៊ីមែល" class="rounded-lg border-slate-300 md:col-span-2">
    <select name="role_id" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់តួនាទី --</option>
        @foreach($roles as $role)<option value="{{ $role->id }}" @selected(request('role_id') == $role->id)>{{ $role->name }}</option>@endforeach
    </select>
    <select name="is_active" class="rounded-lg border-slate-300">
        <option value="">-- គ្រប់ស្ថានភាព --</option>
        <option value="1" @selected(request('is_active') === '1')>សកម្ម</option>
        <option value="0" @selected(request('is_active') === '0')>អសកម្ម</option>
    </select>
    <button class="rounded-lg bg-slate-700 px-4 py-2 text-white md:col-start-4">ស្វែងរក</button>
</form>
<div class="mt-5 overflow-x-auto rounded-xl bg-white shadow-sm">
    <table class="min-w-full divide-y divide-slate-200">
        <thead class="bg-slate-50"><tr><th class="px-4 py-3 text-left">ឈ្មោះ</th><th class="px-4 py-3 text-left">អ៊ីមែល</th><th class="px-4 py-3 text-left">តួនាទី</th><th class="px-4 py-3 text-left">ស្ថានភាព</th><th class="px-4 py-3 text-right">សកម្មភាព</th></tr></thead>
        <tbody class="divide-y">
        @forelse($users as $user)
            <tr>
                <td class="px-4 py-3"><a href="{{ route('users.show', $user) }}" class="font-medium text-blue-700">{{ $user->name }}</a></td>
                <td class="px-4 py-3">{{ $user->email }}</td>
                <td class="px-4 py-3">{{ $user->role?->name ?? '—' }}</td>
                <td class="px-4 py-3"><span class="rounded-full px-2 py-1 text-xs {{ $user->is_active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' }}">{{ $user->is_active ? 'សកម្ម' : 'អសកម្ម' }}</span></td>
                <td class="px-4 py-3 text-right">
                    <a href="{{ route('users.edit', $user) }}" class="text-blue-700">កែសម្រួល</a>
                    <form method="POST" action="{{ route('users.destroy', $user) }}" class="inline" onsubmit="return confirm('តើអ្នកពិតជាចង់លុបអ្នកប្រើប្រាស់នេះមែនទេ?')">
                        @csrf @method('DELETE')
                        <button class="ml-3 text-red-700">លុប</button>
                    </form>
                </td>
            </tr>
        @empty
            <tr><td colspan="5" class="px-4 py-8 text-center text-slate-500">មិនមានទិន្នន័យ</td></tr>
        @endforelse
        </tbody>
    </table>
</div>
<div class="mt-4">{{ $users->links() }}</div>
@endsection
