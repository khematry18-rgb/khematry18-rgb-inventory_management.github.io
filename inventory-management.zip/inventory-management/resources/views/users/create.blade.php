@extends('layouts.app')
@section('title', 'បង្កើតអ្នកប្រើប្រាស់')
@section('content')
<h1 class="text-2xl font-bold">បង្កើតអ្នកប្រើប្រាស់</h1>
@include('users._form', ['action' => route('users.store'), 'method' => 'POST', 'user' => null, 'roles' => $roles])
@endsection
