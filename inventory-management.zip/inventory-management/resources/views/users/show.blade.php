@extends('layouts.app')
@section('title', 'ព័ត៌មានអ្នកប្រើប្រាស់')
@section('content')
<div class="max-w-2xl rounded-xl bg-white p-6 shadow-sm">
    <h1 class="text-2xl font-bold">{{ $user->name }}</h1>
    <dl class="mt-5 grid gap-4 sm:grid-cols-2">
        <div><dt class="text-sm text-slate-500">អ៊ីមែល</dt><dd>{{ $user->email }}</dd></div>
        <div><dt class="text-sm text-slate-500">លេខទូរស័ព្ទ</dt><dd>{{ $user->phone ?? '—' }}</dd></div>
        <div><dt class="text-sm text-slate-500">តួនាទី</dt><dd>{{ $user->role?->name ?? '—' }}</dd></div>
        <div><dt class="text-sm text-slate-500">ស្ថានភាព</dt><dd>{{ $user->is_active ? 'សកម្ម' : 'អសកម្ម' }}</dd></div>
    </dl>
    <a href="{{ route('users.edit', $user) }}" class="mt-6 inline-block rounded-lg bg-blue-700 px-4 py-2 text-white">កែសម្រួល</a>
</div>
@endsection
