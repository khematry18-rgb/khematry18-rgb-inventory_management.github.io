<?php

namespace App\Observers;

use App\Models\Category;
use App\Models\Payment;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\Sale;
use App\Models\StockMovement;
use App\Models\Supplier;
use App\Models\User;
use App\Services\ActivityLogService;
use App\Services\BusinessNotificationService;
use App\Services\StockAlertService;
use Illuminate\Database\Eloquent\Model;

class InventoryActivityObserver
{
    public function __construct(
        private readonly ActivityLogService $activityLogs,
        private readonly BusinessNotificationService $notifications,
        private readonly StockAlertService $stockAlerts,
    ) {
    }

    public function created(Model $model): void
    {
        if ($model instanceof Product) {
            $this->record($model, 'created', 'products', "បានបង្កើតផលិតផល {$model->name}។");
            $this->notifications->sendToPermissions(
                ['products.view', 'products.manage'],
                'product.created',
                'ផលិតផលថ្មី',
                "បានបង្កើតផលិតផល {$model->name}។",
                route('products.show', $model),
                Product::class,
                $model->id,
            );
            $this->stockAlerts->check($model);

            return;
        }

        if ($model instanceof Category) {
            $this->record($model, 'created', 'categories', "បានបង្កើតប្រភេទ {$model->name}។");
            return;
        }

        if ($model instanceof Supplier) {
            $this->record($model, 'created', 'suppliers', "បានបង្កើតអ្នកផ្គត់ផ្គង់ {$model->name}។");
            return;
        }

        if ($model instanceof User) {
            $this->record($model, 'created', 'users', "បានបង្កើតគណនីអ្នកប្រើប្រាស់ {$model->name}។");
            return;
        }

        if ($model instanceof Purchase) {
            $this->record($model, 'created', 'purchases', "បានបង្កើតបញ្ជាទិញ {$model->purchase_number}។");
            $this->notifications->sendToPermissions(
                ['purchases.manage'],
                'purchase.created',
                'បញ្ជាទិញថ្មី',
                "បានបង្កើតបញ្ជាទិញ {$model->purchase_number}។",
                route('purchases.show', $model),
                Purchase::class,
                $model->id,
            );
            return;
        }

        if ($model instanceof Sale) {
            $this->record($model, 'created', 'sales', "បានបង្កើតការលក់ {$model->sale_number}។");
            $this->notifications->sendToPermissions(
                ['sales.view', 'sales.manage'],
                'sale.created',
                'ការលក់ថ្មី',
                "បានបង្កើតវិក្កយបត្រ {$model->sale_number}។",
                route('sales.show', $model),
                Sale::class,
                $model->id,
            );
            return;
        }

        if ($model instanceof Payment) {
            $this->record($model, 'payment.recorded', 'payments', "បានកត់ត្រាការទូទាត់ {$model->payment_number}។");
            $sale = $model->sale;
            $purchase = $model->purchase;
            $this->notifications->sendToPermissions(
                $sale ? ['sales.view', 'sales.manage'] : ['purchases.manage'],
                'payment.received',
                'បានទទួលការទូទាត់',
                "បានកត់ត្រាការទូទាត់ {$model->payment_number} ចំនួន {$model->amount} {$model->currency}។",
                $sale ? route('sales.show', $sale) : ($purchase ? route('purchases.show', $purchase) : null),
                $sale ? Sale::class : ($purchase ? Purchase::class : null),
                $sale?->id ?? $purchase?->id,
            );
            return;
        }

        if ($model instanceof StockMovement) {
            if ($model->movement_type === 'initial') {
                return;
            }

            $productName = Product::withTrashed()->whereKey($model->product_id)->value('name') ?? 'ផលិតផល';
            $action = match ($model->movement_type) {
                'stock_in' => 'stock.in',
                'stock_out' => 'stock.out',
                default => 'stock.adjustment',
            };
            $movementLabel = match ($model->movement_type) {
                'stock_in' => 'បញ្ចូលស្តុក',
                'stock_out' => 'ដកស្តុក',
                default => 'កែតម្រូវស្តុក',
            };
            $description = "បានកត់ត្រា{$movementLabel}សម្រាប់ {$productName} ចំនួន {$model->quantity}។";
            $this->activityLogs->record($action, 'stock', $description, $model, $model->user_id);
        }
    }

    public function updated(Model $model): void
    {
        if ($model instanceof Product) {
            if ($model->wasChanged(['name', 'sku', 'barcode', 'category_id', 'cost_price', 'selling_price', 'minimum_stock', 'unit', 'is_active', 'description'])) {
                $this->record($model, 'updated', 'products', "បានកែប្រែផលិតផល {$model->name}។");
                $this->notifications->sendToPermissions(
                    ['products.view', 'products.manage'],
                    'product.updated',
                    'បានកែប្រែផលិតផល',
                    "បានកែប្រែផលិតផល {$model->name}។",
                    route('products.show', $model),
                    Product::class,
                    $model->id,
                );
            }

            if ($model->wasChanged(['stock_quantity', 'minimum_stock'])) {
                $this->stockAlerts->check($model);
            }
            return;
        }

        if ($model instanceof Category && $model->wasChanged(['name', 'description', 'is_active'])) {
            $this->record($model, 'updated', 'categories', "បានកែប្រែប្រភេទ {$model->name}។");
            return;
        }

        if ($model instanceof Supplier && $model->wasChanged(['name', 'company_name', 'contact_person', 'phone', 'email', 'address', 'is_active'])) {
            $this->record($model, 'updated', 'suppliers', "បានកែប្រែអ្នកផ្គត់ផ្គង់ {$model->name}។");
            return;
        }

        if ($model instanceof User && $model->wasChanged(['name', 'email', 'phone', 'role_id', 'is_active'])) {
            $this->record($model, 'updated', 'users', "បានកែប្រែគណនីអ្នកប្រើប្រាស់ {$model->name}។");
            return;
        }

        if ($model instanceof Purchase && $model->wasChanged('status')) {
            if (in_array($model->status, ['received', 'partially_received'], true)) {
                $this->record($model, 'purchase.received', 'purchases', "បានទទួលទំនិញពីបញ្ជាទិញ {$model->purchase_number}។", $model->received_by);
                $this->notifications->sendToPermissions(
                    ['purchases.manage'],
                    'purchase.received',
                    'បានទទួលការទិញ',
                    "បានទទួលទំនិញពីបញ្ជាទិញ {$model->purchase_number}។",
                    route('purchases.show', $model),
                    Purchase::class,
                    $model->id,
                );
            } elseif ($model->status === 'cancelled') {
                $this->record($model, 'purchase.cancelled', 'purchases', "បានលុបចោលបញ្ជាទិញ {$model->purchase_number}។");
                $this->notifications->sendToPermissions(
                    ['purchases.manage'],
                    'purchase.cancelled',
                    'បានលុបចោលបញ្ជាទិញ',
                    "បញ្ជាទិញ {$model->purchase_number} ត្រូវបានលុបចោល។",
                    route('purchases.show', $model),
                    Purchase::class,
                    $model->id,
                );
            }
            return;
        }

        if ($model instanceof Sale && $model->wasChanged('status') && $model->status === 'cancelled') {
            $this->record($model, 'sale.cancelled', 'sales', "បានលុបចោលការលក់ {$model->sale_number}។");
            $this->notifications->sendToPermissions(
                ['sales.view', 'sales.manage'],
                'sale.cancelled',
                'បានលុបចោលការលក់',
                "ការលក់ {$model->sale_number} ត្រូវបានលុបចោល។",
                route('sales.show', $model),
                Sale::class,
                $model->id,
            );
        }
    }

    public function deleted(Model $model): void
    {
        if ($model instanceof Product) {
            $this->record($model, 'deleted', 'products', "បានលុបផលិតផល {$model->name}។");
            $this->notifications->sendToPermissions(
                ['products.view', 'products.manage'],
                'product.deleted',
                'បានលុបផលិតផល',
                "បានលុបផលិតផល {$model->name}។",
                route('products.index'),
                Product::class,
                $model->id,
            );
            return;
        }

        if ($model instanceof Category) {
            $this->record($model, 'deleted', 'categories', "បានលុបប្រភេទ {$model->name}។");
            return;
        }

        if ($model instanceof Supplier) {
            $this->record($model, 'deleted', 'suppliers', "បានលុបអ្នកផ្គត់ផ្គង់ {$model->name}។");
            return;
        }

        if ($model instanceof User) {
            $this->record($model, 'deleted', 'users', "បានលុបគណនីអ្នកប្រើប្រាស់ {$model->name}។");
        }
    }

    private function record(Model $model, string $action, string $module, string $description, ?int $userId = null): void
    {
        $this->activityLogs->record($action, $module, $description, $model, $userId);
    }
}
