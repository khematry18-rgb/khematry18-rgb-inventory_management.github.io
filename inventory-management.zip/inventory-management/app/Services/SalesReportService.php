<?php

namespace App\Services;

use App\Models\Sale;
use App\Models\Product;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class SalesReportService
{
    public function query(array $filters = []): Builder
    {
        return Sale::query()
            ->with(['creator:id,name', 'items.product.category:id,name'])
            ->where('status', '!=', 'cancelled')
            ->when($filters['from_date'] ?? null, fn ($q) => $q->whereDate('sold_at', '>=', $filters['from_date']))
            ->when($filters['to_date'] ?? null, fn ($q) => $q->whereDate('sold_at', '<=', $filters['to_date']))
            ->when($filters['status'] ?? null, fn ($q, $status) => $q->where('status', $status))
            ->when($filters['payment_status'] ?? null, fn ($q, $status) => $q->where('payment_status', $status))
            ->when($filters['currency'] ?? null, fn ($q, $currency) => $q->where('currency', $currency))
            ->when($filters['cashier_id'] ?? null, fn ($q, $id) => $q->where('created_by', $id))
            ->when($filters['customer'] ?? null, fn ($q, $customer) => $q->where(function ($sq) use ($customer) {
                $sq->where('customer_name', 'like', "%{$customer}%")->orWhere('customer_phone', 'like', "%{$customer}%");
            }))
            ->when($filters['product_id'] ?? null, fn ($q, $id) => $q->whereHas('items', fn ($iq) => $iq->where('product_id', $id)))
            ->when($filters['category_id'] ?? null, fn ($q, $id) => $q->whereHas('items.product.category', fn ($cq) => $cq->whereKey($id)))
            ->when($filters['payment_method'] ?? null, fn ($q, $method) => $q->whereHas('payments', fn ($pq) => $pq->where('method', $method)));
    }

    public function paginate(array $filters = [], int $perPage = 25)
    {
        return $this->query($filters)->latest('sold_at')->paginate($perPage)->withQueryString();
    }

    public function summary(array $filters = []): array
    {
        $query = $this->query($filters);
        return [
            'sales_count' => (clone $query)->count(),
            'by_currency' => (clone $query)
                ->reorder()
                ->selectRaw('currency, SUM(subtotal) AS subtotal, SUM(discount) AS discount, SUM(tax) AS tax, SUM(grand_total) AS grand_total')
                ->groupBy('currency')
                ->get()
                ->keyBy('currency'),
        ];
    }

    public function dailyTotals(array $filters, string $defaultCurrency): Collection
    {
        $filters['currency'] ??= $defaultCurrency;

        return $this->query($filters)
            ->setEagerLoads([])
            ->reorder()
            ->selectRaw('DATE(sold_at) as period, COALESCE(SUM(subtotal - discount), 0) as total')
            ->groupBy('period')
            ->orderBy('period')
            ->get();
    }

    public function topProducts(array $filters, int $limit = 10): Collection
    {
        $sales = $this->query($filters)
            ->setEagerLoads([])
            ->reorder()
            ->select('sales.id');

        return Product::query()
            ->join('sale_items', 'sale_items.product_id', '=', 'products.id')
            ->whereIn('sale_items.sale_id', $sales)
            ->select('products.name', DB::raw('SUM(sale_items.quantity) as quantity'))
            ->groupBy('products.id', 'products.name')
            ->orderByDesc('quantity')
            ->limit($limit)
            ->get();
    }
}
