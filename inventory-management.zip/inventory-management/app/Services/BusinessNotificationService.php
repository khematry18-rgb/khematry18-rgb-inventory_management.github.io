<?php

namespace App\Services;

use App\Models\User;
use App\Notifications\InventoryNotification;
use Illuminate\Support\Facades\Notification;

class BusinessNotificationService
{
    /**
     * @param  list<string>  $permissions
     */
    public function sendToPermissions(
        array $permissions,
        string $eventType,
        string $title,
        string $message,
        ?string $url = null,
        ?string $recordType = null,
        int|string|null $recordId = null,
    ): void {
        if ($permissions === []) {
            return;
        }

        $recipients = User::query()
            ->where('is_active', true)
            ->where(function ($query) use ($permissions) {
                $query->whereHas('role', fn ($roleQuery) => $roleQuery->where('slug', 'admin'))
                    ->orWhereHas('role.permissions', fn ($permissionQuery) => $permissionQuery->whereIn('slug', $permissions));
            })
            ->get();

        Notification::send($recipients, new InventoryNotification(
            $eventType,
            $title,
            $message,
            $url,
            $recordType,
            $recordId,
        ));
    }
}
