<?php

namespace App\Services;

use App\Models\Product;
use BaconQrCode\Renderer\Image\SvgImageBackEnd;
use BaconQrCode\Renderer\ImageRenderer;
use BaconQrCode\Renderer\RendererStyle\RendererStyle;
use BaconQrCode\Writer;
use Illuminate\Support\Str;
use Picqer\Barcode\BarcodeGenerator;
use Picqer\Barcode\BarcodeGeneratorSVG;
use RuntimeException;
use Illuminate\Support\Facades\Storage;

class BarcodeService
{
    public function generateInternalValue(Product $product): string
    {
        $base = 'INV-' . Str::upper(Str::slug($product->sku, '-'));
        $candidate = substr($base, 0, 90);

        if ($candidate !== 'INV-' && ! Product::withTrashed()->where('barcode', $candidate)->whereKeyNot($product->id)->exists()) {
            return $candidate;
        }

        do {
            $candidate = 'INV-' . Str::upper(Str::random(20));
        } while (Product::withTrashed()->where('barcode', $candidate)->whereKeyNot($product->id)->exists());

        return $candidate;
    }

    public function barcodeFormat(string $value): string
    {
        if (preg_match('/^\d{13}$/', $value) === 1 && $this->hasValidCheckDigit($value, 13)) {
            return BarcodeGenerator::TYPE_EAN_13;
        }

        if (preg_match('/^\d{12}$/', $value) === 1 && $this->hasValidCheckDigit($value, 12)) {
            return BarcodeGenerator::TYPE_UPC_A;
        }

        return BarcodeGenerator::TYPE_CODE_128;
    }

    public function barcodeSvg(string $value, float $height = 48): string
    {
        if ($value === '' || preg_match('/^[\x20-\x7E]{1,100}$/', $value) !== 1) {
            throw new RuntimeException('លេខ Barcode ត្រូវតែមានតួអក្សរដែលអាចបោះពុម្ពបាន និងមិនលើស 100 តួ។');
        }

        return (new BarcodeGeneratorSVG())->getBarcode($value, $this->barcodeFormat($value), 2, $height);
    }

    public function storeBarcodeSvg(Product $product, float $height = 48): string
    {
        $svg = $this->barcodeSvg($product->barcode, $height);
        $this->storePrivateSvg("barcodes/products/{$product->id}/barcode.svg", $svg);

        return $svg;
    }

    public function storeQrCodeSvg(Product $product, string $url, int $size = 220): string
    {
        $svg = $this->qrCodeSvg($url, $size);
        $this->storePrivateSvg("barcodes/products/{$product->id}/qr.svg", $svg);

        return $svg;
    }

    public function qrCodeSvg(string $value, int $size = 220): string
    {
        $renderer = new ImageRenderer(new RendererStyle($size, 2), new SvgImageBackEnd());

        return (new Writer($renderer))->writeString($value);
    }

    private function storePrivateSvg(string $path, string $svg): void
    {
        if (! Storage::disk('local')->put($path, $svg)) {
            throw new RuntimeException('មិនអាចរក្សាទុករូបភាព SVG បានទេ។');
        }
    }

    private function hasValidCheckDigit(string $value, int $length): bool
    {
        $digits = array_map('intval', str_split($value));
        $checkDigit = array_pop($digits);
        $sum = 0;

        foreach (array_reverse($digits) as $index => $digit) {
            $sum += $digit * ($index % 2 === 0 ? 3 : 1);
        }

        return (10 - ($sum % 10)) % 10 === $checkDigit && count($digits) + 1 === $length;
    }
}
