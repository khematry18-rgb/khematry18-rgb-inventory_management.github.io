<?php

namespace App\Services;

use App\Models\Payment;
use App\Models\Product;
use App\Models\Sale;
use App\Models\SystemSetting;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class SaleService
{
    public function __construct(
        private readonly StockService $stockService,
        private readonly SystemSettingsService $settings,
    ) {
    }

    public function create(array $data, User $user): Sale
    {
        return DB::transaction(function () use ($data, $user) {
            $existing = Sale::where('submission_key', $data['submission_key'])->first();
            if ($existing) {
                return $existing->load(['items.product', 'payments', 'creator']);
            }

            $currency = $data['currency'] ?? $this->settings->get('currency_code');
            $exchangeRate = $this->transactionExchangeRate($currency);
            $calculated = $this->calculate($data['items'], (float) $data['discount'], (float) $data['tax'], $currency, $exchangeRate);
            if ($calculated['grand_total'] < 0) {
                throw new RuntimeException('សរុបការលក់មិនអាចតិចជាងសូន្យ។');
            }
            $amountPaid = round((float) $data['amount_paid'], 2);
            if ($amountPaid > $calculated['grand_total']) {
                throw new RuntimeException('ចំនួនទូទាត់លើសសមតុល្យ។');
            }

            $sale = Sale::create([
                'sale_number' => $this->nextSaleNumber(),
                'currency' => $currency,
                'exchange_rate' => $exchangeRate,
                'created_by' => $user->id,
                'customer_name' => trim((string) ($data['customer_name'] ?? $this->settings->get('default_customer')))
                    ?: $this->settings->get('default_customer'),
                'customer_phone' => $data['customer_phone'] ?? null,
                'customer_email' => $data['customer_email'] ?? null,
                'customer_address' => $data['customer_address'] ?? null,
                'sold_at' => $data['sold_at'],
                'status' => 'completed',
                'payment_status' => $this->paymentStatus($amountPaid, $calculated['grand_total']),
                'subtotal' => $calculated['subtotal'],
                'discount' => $calculated['discount'],
                'tax' => $calculated['tax'],
                'grand_total' => $calculated['grand_total'],
                'notes' => $data['notes'] ?? null,
                'submission_key' => $data['submission_key'],
                'completed_at' => now(),
            ]);

            foreach ($calculated['items'] as $item) {
                $sale->items()->create([
                    'product_id' => $item['product_id'],
                    'quantity' => $item['quantity'],
                    'unit_price' => $item['unit_price'],
                    'cost_price' => $item['cost_price'],
                    'line_total' => $item['line_total'],
                ]);
            }

            foreach ($calculated['items'] as $item) {
                $product = Product::query()->whereKey($item['product_id'])->firstOrFail();
                $this->stockService->stockOut($product, $user, [
                    'quantity' => $item['quantity'],
                    'reference_number' => $sale->sale_number,
                    'transaction_date' => $data['sold_at'],
                    'reason' => 'លក់ទំនិញ',
                    'notes' => $data['notes'] ?? null,
                    'submission_key' => $this->movementSubmissionKey($data['submission_key'], $item['product_id'], 'sale'),
                    'reference_type' => Sale::class,
                    'reference_id' => $sale->id,
                ]);
            }

            if ($amountPaid > 0) {
                $sale->payments()->create([
                    'recorded_by' => $user->id,
                    'payment_number' => $this->nextPaymentNumber(),
                    'method' => $data['payment_method'] ?? 'cash',
                    'status' => 'completed',
                    'amount' => $amountPaid,
                    'currency' => $currency,
                    'exchange_rate' => $exchangeRate,
                    'paid_at' => $data['sold_at'],
                    'reference' => $data['payment_reference'] ?? null,
                    'notes' => $data['payment_notes'] ?? null,
                ]);
            }

            return $sale->load(['items.product', 'payments', 'creator']);
        });
    }

    public function amountPaid(Sale $sale): float
    {
        $paidUsd = $sale->payments()->where('status', 'completed')->get()
            ->sum(fn (Payment $payment) => $this->settings->toUsd(
                (float) $payment->amount,
                $payment->currency ?: 'USD',
                (float) $payment->exchange_rate,
            ));

        return round($this->settings->fromUsd((float) $paidUsd, $sale->currency ?: 'USD', (float) $sale->exchange_rate), 2);
    }

    public function addPayment(Sale $sale, array $data, User $user): Payment
    {
        return DB::transaction(function () use ($sale, $data, $user) {
            $locked = Sale::whereKey($sale->id)->lockForUpdate()->firstOrFail();
            if ($locked->status === 'cancelled') {
                throw new RuntimeException('ការលក់នេះបានលុបចោលហើយ។');
            }
            $existing = Payment::where('sale_id', $locked->id)->where('reference', $data['submission_key'])->first();
            if ($existing) {
                return $existing;
            }

            $paid = $this->amountPaid($locked);
            $outstanding = round((float) $locked->grand_total - $paid, 2);
            $amount = round((float) $data['amount'], 2);
            $currency = $data['currency'] ?? $locked->currency ?? 'USD';
            $paymentRate = $this->transactionExchangeRate($currency);
            $amountInSaleCurrency = $this->settings->fromUsd(
                $this->settings->toUsd($amount, $currency, $paymentRate),
                $locked->currency ?: 'USD',
                (float) $locked->exchange_rate,
            );
            if ($amountInSaleCurrency > $outstanding) {
                throw new RuntimeException('ចំនួនទូទាត់លើសសមតុល្យ។');
            }

            $payment = $locked->payments()->create([
                'recorded_by' => $user->id,
                'payment_number' => $this->nextPaymentNumber(),
                'method' => $data['method'],
                'status' => 'completed',
                'amount' => $amount,
                'currency' => $currency,
                'exchange_rate' => $paymentRate,
                'paid_at' => $data['paid_at'],
                'reference' => $data['reference'] ?? $data['submission_key'],
                'notes' => $data['notes'] ?? null,
            ]);

            $newPaid = round($paid + $amountInSaleCurrency, 2);
            $locked->update(['payment_status' => $this->paymentStatus($newPaid, (float) $locked->grand_total)]);
            return $payment;
        });
    }

    public function cancel(Sale $sale, User $user, ?string $reason = null): Sale
    {
        return DB::transaction(function () use ($sale, $user, $reason) {
            $locked = Sale::whereKey($sale->id)->lockForUpdate()->firstOrFail();
            if ($locked->status === 'cancelled') {
                throw new RuntimeException('ការលក់នេះបានលុបចោលរួចហើយ។');
            }
            if ($locked->payments()->exists()) {
                throw new RuntimeException('មិនអាចលុបចោលការលក់ដែលបានទូទាត់។');
            }

            foreach ($locked->items()->with('product')->lockForUpdate()->get() as $item) {
                $this->stockService->stockIn($item->product, $user, [
                    'quantity' => (float) $item->quantity,
                    'reference_number' => $locked->sale_number,
                    'transaction_date' => now(),
                    'reason' => 'លុបចោលការលក់ និងស្តុកត្រឡប់',
                    'notes' => $reason,
                    'submission_key' => $this->movementSubmissionKey((string) $locked->id, $item->product_id, 'cancel-sale'),
                    'reference_type' => Sale::class,
                    'reference_id' => $locked->id,
                ]);
            }
            $locked->update([
                'status' => 'cancelled',
                'cancelled_at' => now(),
                'cancel_reason' => $reason,
                'payment_status' => 'unpaid',
            ]);
            return $locked->load(['items.product', 'payments', 'creator']);
        });
    }

    private function calculate(array $items, float $discount, float $tax, string $currency, float $exchangeRate): array
    {
        if ($discount < 0 || $tax < 0) {
            throw new RuntimeException('បញ្ចុះតម្លៃ និងពន្ធមិនអាចជាលេខអវិជ្ជមាន។');
        }
        if (! $this->settings->get('discounts_allowed') && $discount > 0) {
            throw new RuntimeException('ការកំណត់ប្រព័ន្ធមិនអនុញ្ញាតឱ្យប្រើការបញ្ចុះតម្លៃទេ។');
        }

        $subtotal = 0.0;
        $calculatedItems = [];
        foreach ($items as $item) {
            $quantity = round((float) $item['quantity'], 3);
            if ($quantity <= 0) {
                throw new RuntimeException('បរិមាណលក់ត្រូវធំជាងសូន្យ។');
            }
            $product = Product::query()->whereKey((int) $item['product_id'])->where('is_active', true)->first();
            if (! $product) {
                throw new RuntimeException('ផលិតផលមិនសកម្ម ឬមិនមានក្នុងប្រព័ន្ធ។');
            }
            if ($quantity > (float) $product->stock_quantity && ! $this->settings->get('allow_negative_stock')) {
                throw new RuntimeException("បរិមាណស្តុកផលិតផល {$product->name} មិនគ្រប់គ្រាន់។");
            }
            $unitPrice = $this->settings->fromUsd((float) $product->selling_price, $currency, $exchangeRate);
            $lineTotal = round($quantity * $unitPrice, 2);
            $subtotal += $lineTotal;
            $calculatedItems[] = [
                'product_id' => $product->id,
                'quantity' => $quantity,
                'unit_price' => $unitPrice,
                'cost_price' => $this->settings->fromUsd((float) $product->cost_price, $currency, $exchangeRate),
                'line_total' => $lineTotal,
            ];
        }

        $subtotal = round($subtotal, 2);
        $discount = round($discount, 2);
        $taxRate = (float) $this->settings->get('tax_rate');
        $tax = ! $this->settings->get('tax_enabled')
            ? 0.0
            : ($taxRate > 0
                ? round(max(0, $subtotal - $discount) * $taxRate / 100, 2)
                : round($tax, 2));
        $grandTotal = round($subtotal - $discount + $tax, 2);
        return compact('subtotal', 'discount', 'tax', 'grandTotal') + ['grand_total' => $grandTotal, 'items' => $calculatedItems];
    }

    private function paymentStatus(float $paid, float $grandTotal): string
    {
        if ($paid <= 0) {
            return 'unpaid';
        }
        return $paid + 0.0001 >= $grandTotal ? 'paid' : 'partially_paid';
    }

    private function nextSaleNumber(): string
    {
        $prefix = $this->settings->get('invoice_prefix');
        $date = now()->format('Ymd');

        if ($this->settings->get('invoice_numbering') === 'sequential') {
            SystemSetting::query()->lockForUpdate()->find(1);
            $pattern = "{$prefix}-{$date}-";
            $numbers = Sale::withTrashed()->where('sale_number', 'like', $pattern . '%')->pluck('sale_number');
            $next = $numbers->map(fn ($number) => (int) substr($number, strlen($pattern)))
                ->filter(fn ($number) => $number > 0)->max() + 1;

            return $pattern . str_pad((string) $next, 6, '0', STR_PAD_LEFT);
        }

        do {
            $number = $prefix . '-' . $date . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
        } while (Sale::withTrashed()->where('sale_number', $number)->exists());

        return $number;
    }

    private function transactionExchangeRate(string $currency): float
    {
        if (! in_array($currency, ['USD', 'KHR'], true)) {
            throw new RuntimeException('រូបិយប័ណ្ណប្រតិបត្តិការមិនត្រឹមត្រូវ។');
        }

        if ($currency === 'USD') {
            return 1;
        }

        $rate = (float) $this->settings->get('exchange_rate');
        if ($rate <= 0) {
            throw new RuntimeException('សូមកំណត់អត្រាប្តូរប្រាក់ USD/KHR ជាមុនសិន។');
        }

        return round($rate, 4);
    }

    private function nextPaymentNumber(): string
    {
        return 'PAY-' . now()->format('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
    }

    private function movementSubmissionKey(string $base, int $productId, string $suffix): string
    {
        $hex = substr(hash('sha256', $base . ':' . $productId . ':' . $suffix), 0, 32);
        return substr($hex, 0, 8) . '-' . substr($hex, 8, 4) . '-4' . substr($hex, 13, 3) . '-8' . substr($hex, 17, 3) . '-' . substr($hex, 20, 12);
    }
}
