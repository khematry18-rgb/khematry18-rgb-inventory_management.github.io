<?php

namespace App\Services;

use App\Models\Product;
use App\Models\StockMovement;
use App\Models\User;
use App\Services\SystemSettingsService;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class StockService
{
    public function __construct(private readonly SystemSettingsService $settings)
    {
    }

    public function stockIn(Product $product, User $user, array $data): StockMovement
    {
        return $this->apply($product, 'stock_in', $user, $data, 'increase');
    }

    public function stockOut(Product $product, User $user, array $data): StockMovement
    {
        return $this->apply($product, 'stock_out', $user, $data, 'decrease');
    }

    public function adjustment(Product $product, User $user, array $data): StockMovement
    {
        return $this->apply($product, 'adjustment', $user, $data, 'set');
    }

    public function recordOpeningBalance(Product $product, User $user, float $quantity): ?StockMovement
    {
        if ($quantity <= 0) {
            return null;
        }

        return DB::transaction(function () use ($product, $user, $quantity) {
            $lockedProduct = Product::query()->whereKey($product->id)->lockForUpdate()->firstOrFail();
            $currentQuantity = (float) $lockedProduct->stock_quantity;

            if (abs($currentQuantity - $quantity) > 0.0001) {
                throw new RuntimeException('ស្តុកដំបូងបានផ្លាស់ប្តូរ មុនពេលកត់ត្រាប្រវត្តិស្តុក។');
            }

            return StockMovement::create([
                'product_id' => $lockedProduct->id,
                'user_id' => $user->id,
                'movement_type' => 'initial',
                'quantity' => $quantity,
                'stock_before' => 0,
                'stock_after' => $quantity,
                'reason' => 'ស្តុកដំបូងនៅពេលបង្កើតផលិតផល',
                'transaction_date' => now(),
            ]);
        });
    }

    /**
     * Reusable stock operation for this module and future purchase/sale modules.
     */
    public function apply(Product $product, string $operation, User $user, array $data, string $mode): StockMovement
    {
        return DB::transaction(function () use ($product, $operation, $user, $data, $mode) {
            if (! empty($data['submission_key'])) {
                $existing = StockMovement::where('submission_key', $data['submission_key'])->first();
                if ($existing) {
                    return $existing;
                }
            }

            $lockedProduct = Product::query()->whereKey($product->id)->lockForUpdate()->firstOrFail();
            if (! empty($data['submission_key'])) {
                $existing = StockMovement::where('submission_key', $data['submission_key'])->first();
                if ($existing) {
                    return $existing;
                }
            }
            $before = (float) $lockedProduct->stock_quantity;

            if ($mode === 'increase') {
                $quantity = (float) $data['quantity'];
                $after = $before + $quantity;
            } elseif ($mode === 'decrease') {
                $quantity = (float) $data['quantity'];
                $after = $before - $quantity;
                if ($after < 0 && ! $this->settings->get('allow_negative_stock')) {
                    throw new RuntimeException('បរិមាណស្តុកមិនគ្រប់គ្រាន់។');
                }
            } else {
                $after = (float) $data['actual_quantity'];
                if ($after < 0 && ! $this->settings->get('allow_negative_stock')) {
                    throw new RuntimeException('បរិមាណស្តុកពិតប្រាកដមិនអាចជាលេខអវិជ្ជមាន។');
                }
                $difference = $after - $before;
                if (abs($difference) < 0.0001) {
                    throw new RuntimeException('មិនមានភាពខុសគ្នារវាងស្តុកទំនុកចិត្ត និងស្តុកពិតប្រាកដ។');
                }
                $quantity = abs($difference);
            }

            $lockedProduct->update(['stock_quantity' => $after]);

            return StockMovement::create([
                'product_id' => $lockedProduct->id,
                'user_id' => $user->id,
                'movement_type' => $operation,
                'quantity' => $quantity,
                'stock_before' => $before,
                'stock_after' => $after,
                'reason' => $data['reason'] ?? null,
                'reference_number' => $data['reference_number'] ?? null,
                'notes' => $data['notes'] ?? null,
                'transaction_date' => $data['transaction_date'],
                'unit_cost' => $data['unit_cost'] ?? null,
                'submission_key' => $data['submission_key'] ?? null,
                'reference_type' => $data['reference_type'] ?? null,
                'reference_id' => $data['reference_id'] ?? null,
            ]);
        });
    }
}
