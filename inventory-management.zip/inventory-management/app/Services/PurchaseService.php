<?php

namespace App\Services;

use App\Models\Payment;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\SystemSetting;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class PurchaseService
{
    public function __construct(
        private readonly StockService $stockService,
        private readonly SystemSettingsService $settings,
    ) {
    }

    public function create(array $data, User $user): Purchase
    {
        return DB::transaction(function () use ($data, $user) {
            $currency = $data['currency'] ?? $this->settings->get('currency_code');
            $exchangeRate = $this->transactionExchangeRate($currency);
            $calculated = $this->calculate($data['items'], $data['discount'], $data['tax']);
            $purchase = Purchase::create([
                'purchase_number' => $this->nextPurchaseNumber(),
                'currency' => $currency,
                'exchange_rate' => $exchangeRate,
                'supplier_id' => $data['supplier_id'],
                'created_by' => $user->id,
                'purchased_at' => $data['purchased_at'],
                'expected_delivery_at' => $data['expected_delivery_at'] ?? null,
                'reference_number' => $data['reference_number'] ?? null,
                'status' => $data['status'],
                'payment_status' => 'unpaid',
                'subtotal' => $calculated['subtotal'],
                'discount' => $calculated['discount'],
                'tax' => $calculated['tax'],
                'grand_total' => $calculated['grand_total'],
                'notes' => $data['notes'] ?? null,
                'confirmed_at' => $data['status'] === 'pending' ? now() : null,
            ]);

            foreach ($calculated['items'] as $item) {
                $purchase->items()->create($item + ['received_quantity' => 0]);
            }

            return $purchase->load(['supplier', 'items.product']);
        });
    }

    public function update(Purchase $purchase, array $data): Purchase
    {
        if (! in_array($purchase->status, ['draft', 'pending'], true) || $purchase->payments()->exists() || $purchase->stockMovements()->exists()) {
            throw new RuntimeException('បញ្ជាទិញនេះមិនអាចកែសម្រួលបានទេ។');
        }

        return DB::transaction(function () use ($purchase, $data) {
            $locked = Purchase::whereKey($purchase->id)->lockForUpdate()->firstOrFail();
            if (! in_array($locked->status, ['draft', 'pending'], true) || $locked->payments()->exists() || $locked->stockMovements()->exists()) {
                throw new RuntimeException('បញ្ជាទិញនេះមិនអាចកែសម្រួលបានទេ។');
            }
            $calculated = $this->calculate($data['items'], $data['discount'], $data['tax']);
            $currency = $data['currency'] ?? $locked->currency ?? 'USD';
            $exchangeRate = $this->transactionExchangeRate($currency);
            $locked->update([
                'currency' => $currency,
                'exchange_rate' => $exchangeRate,
                'supplier_id' => $data['supplier_id'],
                'purchased_at' => $data['purchased_at'],
                'expected_delivery_at' => $data['expected_delivery_at'] ?? null,
                'reference_number' => $data['reference_number'] ?? null,
                'status' => $data['status'],
                'confirmed_at' => $data['status'] === 'pending' ? ($locked->confirmed_at ?: now()) : null,
                'subtotal' => $calculated['subtotal'],
                'discount' => $calculated['discount'],
                'tax' => $calculated['tax'],
                'grand_total' => $calculated['grand_total'],
                'notes' => $data['notes'] ?? null,
            ]);
            $locked->items()->delete();
            foreach ($calculated['items'] as $item) {
                $locked->items()->create($item + ['received_quantity' => 0]);
            }
            return $locked->load(['supplier', 'items.product']);
        });
    }

    public function receive(Purchase $purchase, array $data, User $user): Purchase
    {
        return DB::transaction(function () use ($purchase, $data, $user) {
            $locked = Purchase::whereKey($purchase->id)->lockForUpdate()->firstOrFail();
            $items = $locked->items()->with('product')->lockForUpdate()->get();
            foreach ($items as $item) {
                $submissionKey = $this->receiveSubmissionKey($data['submission_key'], $item->id, 'receive');
                if ($item->received_quantity > 0 && \App\Models\StockMovement::query()->where('submission_key', $submissionKey)->exists()) {
                    return $locked->load(['supplier', 'items.product', 'payments']);
                }
            }
            if (! in_array($locked->status, ['draft', 'pending', 'partially_received'], true)) {
                throw new RuntimeException('បញ្ជាទិញនេះមិនអាចទទួលស្តុកបានទេ។');
            }

            $receivedTotal = 0.0;
            foreach ($items as $item) {
                $quantity = (float) ($data['items'][$item->id]['received_quantity'] ?? 0);
                $outstanding = (float) $item->quantity - (float) $item->received_quantity;
                if ($quantity < 0 || $quantity > $outstanding + 0.0001) {
                    throw new RuntimeException("បរិមាណទទួលលើផលិតផល {$item->product->name} លើសបរិមាណនៅសល់។");
                }
                if ($quantity > 0) {
                    $receivedTotal += $quantity;
                    $this->stockService->stockIn($item->product, $user, [
                        'quantity' => $quantity,
                        'reference_number' => $locked->purchase_number,
                        'transaction_date' => $data['received_at'],
                        'reason' => 'ទទួលទំនិញពីបញ្ជាទិញ',
                        'notes' => $data['notes'] ?? null,
                        'submission_key' => $this->receiveSubmissionKey($data['submission_key'], $item->id, 'receive'),
                        'reference_type' => Purchase::class,
                        'reference_id' => $locked->id,
                    ]);
                    $item->update(['received_quantity' => (float) $item->received_quantity + $quantity]);
                }
            }

            if ($receivedTotal <= 0) {
                throw new RuntimeException('សូមបញ្ចូលបរិមាណទទួលយ៉ាងហោចណាស់មួយ។');
            }

            $fullyReceived = $locked->items()->get()->every(fn ($item) =>
                abs((float) $item->quantity - (float) $item->received_quantity) < 0.0001
            );
            $locked->update([
                'status' => $fullyReceived ? 'received' : 'partially_received',
                'received_at' => $data['received_at'],
                'received_by' => $user->id,
                'confirmed_at' => $locked->confirmed_at ?: now(),
            ]);

            return $locked->load(['supplier', 'items.product', 'payments']);
        });
    }

    public function cancel(Purchase $purchase, User $user, ?string $reason = null): Purchase
    {
        return DB::transaction(function () use ($purchase, $user, $reason) {
            $locked = Purchase::whereKey($purchase->id)->lockForUpdate()->firstOrFail();
            if ($locked->status === 'cancelled') {
                throw new RuntimeException('បញ្ជាទិញនេះបានលុបចោលរួចហើយ។');
            }
            if ($locked->payments()->exists()) {
                throw new RuntimeException('មិនអាចលុបចោលបញ្ជាទិញដែលបានមានការទូទាត់។');
            }

            foreach ($locked->items()->with('product')->lockForUpdate()->get() as $item) {
                $received = (float) $item->received_quantity;
                if ($received > 0) {
                    $this->stockService->stockOut($item->product, $user, [
                        'quantity' => $received,
                        'reference_number' => $locked->purchase_number,
                        'transaction_date' => now(),
                        'reason' => 'លុបចោលបញ្ជាទិញ និងដកស្តុកដែលបានទទួល',
                        'notes' => $reason,
                        'submission_key' => $this->receiveSubmissionKey((string) $user->id, $item->id, 'cancel:' . $locked->id),
                        'reference_type' => Purchase::class,
                        'reference_id' => $locked->id,
                    ]);
                    $item->update(['received_quantity' => 0]);
                }
            }

            $locked->update([
                'status' => 'cancelled',
                'cancelled_at' => now(),
                'cancel_reason' => $reason,
                'payment_status' => 'unpaid',
            ]);
            return $locked->load(['supplier', 'items.product']);
        });
    }

    public function addPayment(Purchase $purchase, array $data, User $user): Payment
    {
        return DB::transaction(function () use ($purchase, $data, $user) {
            $locked = Purchase::whereKey($purchase->id)->lockForUpdate()->firstOrFail();
            if ($locked->status === 'cancelled') {
                throw new RuntimeException('មិនអាចទូទាត់បញ្ជាទិញដែលបានលុបចោល។');
            }

            $paid = $this->amountPaid($locked);
            $paymentCurrency = $data['currency'];
            $paymentRate = $this->transactionExchangeRate($paymentCurrency);
            $amount = (float) $data['amount'];
            $amountInPurchaseCurrency = $this->settings->fromUsd(
                $this->settings->toUsd($amount, $paymentCurrency, $paymentRate),
                $locked->currency ?: 'USD',
                (float) $locked->exchange_rate,
            );
            $outstanding = (float) $locked->grand_total - $paid;
            if ($amountInPurchaseCurrency > $outstanding + 0.01) {
                throw new RuntimeException('ចំនួនទូទាត់លើសសមតុល្យនៅសល់។');
            }

            $payment = $locked->payments()->create([
                'recorded_by' => $user->id,
                'payment_number' => 'PAY-' . strtoupper(str()->random(10)),
                'method' => $data['method'],
                'status' => 'completed',
                'amount' => $amount,
                'currency' => $paymentCurrency,
                'exchange_rate' => $paymentRate,
                'paid_at' => $data['paid_at'],
                'reference' => $data['reference'] ?? null,
                'notes' => $data['notes'] ?? null,
            ]);

            $paidAfter = $paid + $amountInPurchaseCurrency;
            $locked->update(['payment_status' => $paidAfter >= (float) $locked->grand_total - 0.01 ? 'paid' : ($paidAfter > 0 ? 'partially_paid' : 'unpaid')]);
            return $payment;
        });
    }

    public function amountPaid(Purchase $purchase): float
    {
        $paidUsd = $purchase->payments()->where('status', 'completed')->get()
            ->sum(fn (Payment $payment) => $this->settings->toUsd(
                (float) $payment->amount,
                $payment->currency ?: 'USD',
                (float) $payment->exchange_rate,
            ));

        return round($this->settings->fromUsd((float) $paidUsd, $purchase->currency ?: 'USD', (float) $purchase->exchange_rate), 2);
    }

    public function calculate(array $items, float $discount, float $tax): array
    {
        $subtotal = 0.0;
        $calculatedItems = [];
        foreach ($items as $item) {
            $quantity = (float) $item['quantity'];
            $unitCost = (float) $item['unit_cost'];
            if ($quantity <= 0 || $unitCost < 0) {
                throw new RuntimeException('ទិន្នន័យបរិមាណ ឬតម្លៃទិញមិនត្រឹមត្រូវ។');
            }
            $lineTotal = round($quantity * $unitCost, 2);
            $subtotal += $lineTotal;
            $calculatedItems[] = [
                'product_id' => (int) $item['product_id'],
                'quantity' => $quantity,
                'unit_cost' => $unitCost,
                'line_total' => $lineTotal,
            ];
        }
        if ($discount < 0 || $tax < 0) {
            throw new RuntimeException('បញ្ចុះតម្លៃ និងពន្ធមិនអាចជាលេខអវិជ្ជមាន។');
        }
        $subtotal = round($subtotal, 2);
        $discount = round($discount, 2);
        $tax = round($tax, 2);
        $grandTotal = round($subtotal - $discount + $tax, 2);
        if ($grandTotal < 0) {
            throw new RuntimeException('សរុបការទិញមិនអាចតិចជាងសូន្យ។');
        }
        return compact('subtotal', 'discount', 'tax', 'grandTotal') + ['grand_total' => $grandTotal, 'items' => $calculatedItems];
    }

    private function nextPurchaseNumber(): string
    {
        $prefix = $this->settings->get('purchase_order_prefix');
        $date = now()->format('Ymd');

        if ($this->settings->get('purchase_order_numbering') === 'sequential') {
            SystemSetting::query()->lockForUpdate()->find(1);
            $pattern = "{$prefix}-{$date}-";
            $numbers = Purchase::withTrashed()->where('purchase_number', 'like', $pattern . '%')->pluck('purchase_number');
            $next = $numbers->map(fn ($number) => (int) substr($number, strlen($pattern)))
                ->filter(fn ($number) => $number > 0)->max() + 1;

            return $pattern . str_pad((string) $next, 6, '0', STR_PAD_LEFT);
        }

        do {
            $number = $prefix . '-' . $date . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
        } while (Purchase::withTrashed()->where('purchase_number', $number)->exists());

        return $number;
    }

    private function transactionExchangeRate(string $currency): float
    {
        if (! in_array($currency, ['USD', 'KHR'], true)) {
            throw new RuntimeException('រូបិយប័ណ្ណប្រតិបត្តិការមិនត្រឹមត្រូវ។');
        }

        if ($currency === 'USD') {
            return 1;
        }

        $rate = (float) $this->settings->get('exchange_rate');
        if ($rate <= 0) {
            throw new RuntimeException('សូមកំណត់អត្រាប្តូរប្រាក់ USD/KHR ជាមុនសិន។');
        }

        return round($rate, 4);
    }

    private function receiveSubmissionKey(string $base, int $itemId, string $suffix): string
    {
        $hex = substr(hash('sha256', $base . ':' . $itemId . ':' . $suffix), 0, 32);
        return substr($hex, 0, 8) . '-' . substr($hex, 8, 4) . '-4' . substr($hex, 13, 3) . '-8' . substr($hex, 17, 3) . '-' . substr($hex, 20, 12);
    }
}
