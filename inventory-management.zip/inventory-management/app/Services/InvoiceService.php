<?php

namespace App\Services;

use App\Models\Sale;

class InvoiceService
{
    public function __construct(private readonly SaleService $saleService)
    {
    }

    public function receipt(Sale $sale): array
    {
        $paid = $this->saleService->amountPaid($sale);
        return [
            'paid' => $paid,
            'outstanding' => max(0, round((float) $sale->grand_total - $paid, 2)),
        ];
    }
}
