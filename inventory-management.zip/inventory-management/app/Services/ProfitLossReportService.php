<?php

namespace App\Services;

use App\Models\Sale;
use App\Services\SystemSettingsService;
use Illuminate\Support\Facades\DB;

class ProfitLossReportService
{
    public function __construct(private readonly SystemSettingsService $settings)
    {
    }

    public function calculate(array $filters = []): array
    {
        $sales = Sale::query()
            ->with('items')
            ->where('status', '!=', 'cancelled')
            ->when($filters['from_date'] ?? null, fn ($q) => $q->whereDate('sold_at', '>=', $filters['from_date']))
            ->when($filters['to_date'] ?? null, fn ($q) => $q->whereDate('sold_at', '<=', $filters['to_date']))
            ->when($filters['currency'] ?? null, fn ($q, $currency) => $q->where('currency', $currency))
            ->when($filters['cashier_id'] ?? null, fn ($q, $id) => $q->where('created_by', $id))
            ->when($filters['product_id'] ?? null, fn ($q, $id) => $q->whereHas('items', fn ($iq) => $iq->where('product_id', $id)))
            ->when($filters['category_id'] ?? null, fn ($q, $id) => $q->whereHas('items.product.category', fn ($cq) => $cq->whereKey($id)))
            ->get();

        $unknownCostCount = 0;
        $byCurrency = [];

        foreach ($sales as $sale) {
            $currency = $sale->currency ?: 'USD';
            $byCurrency[$currency] ??= [
                'revenue' => 0.0,
                'discounts' => 0.0,
                'tax' => 0.0,
                'cogs' => 0.0,
            ];
            $byCurrency[$currency]['revenue'] += (float) $sale->subtotal;
            $byCurrency[$currency]['discounts'] += (float) $sale->discount;
            $byCurrency[$currency]['tax'] += (float) $sale->tax;

            foreach ($sale->items as $item) {
                if ($item->cost_price === null) {
                    $unknownCostCount++;
                    continue;
                }
                $byCurrency[$currency]['cogs'] += (float) $item->quantity * (float) $item->cost_price;
            }
        }

        foreach ($byCurrency as &$totals) {
            $totals = array_map(fn ($value) => round($value, 2), $totals);
            $totals['gross_profit'] = round($totals['revenue'] - $totals['discounts'] - $totals['cogs'], 2);
        }
        unset($totals);

        $usd = $byCurrency['USD'] ?? ['revenue' => 0, 'discounts' => 0, 'tax' => 0, 'cogs' => 0, 'gross_profit' => 0];

        return [
            'revenue' => $usd['revenue'],
            'cogs' => $usd['cogs'],
            'gross_profit' => $usd['gross_profit'],
            'discounts' => $usd['discounts'],
            'tax' => $usd['tax'],
            'by_currency' => $byCurrency,
            'net_profit' => null,
            'unknown_cost_items' => $unknownCostCount,
        ];
    }
}
