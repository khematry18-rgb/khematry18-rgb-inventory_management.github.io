<?php

namespace App\Services;

use App\Models\Product;

class StockAlertService
{
    public function __construct(private readonly BusinessNotificationService $notifications)
    {
    }

    public function check(Product $product): void
    {
        $quantity = (float) $product->stock_quantity;
        $minimum = (float) $product->minimum_stock;
        $currentStatus = $quantity <= 0
            ? 'out'
            : ($quantity <= $minimum ? 'low' : 'normal');

        $settings = app(SystemSettingsService::class);
        $enabled = $currentStatus === 'out'
            ? $settings->get('out_of_stock_alert')
            : ($currentStatus === 'low' && $settings->get('low_stock_alert'));

        if ($product->stock_alert_status === $currentStatus && $enabled) {
            return;
        }

        $product->forceFill(['stock_alert_status' => $enabled ? $currentStatus : 'normal'])->saveQuietly();

        if ($currentStatus === 'normal' || ! $enabled) {
            return;
        }

        $isOutOfStock = $currentStatus === 'out';
        $this->notifications->sendToPermissions(
            ['stock.view', 'stock.manage'],
            $isOutOfStock ? 'stock.out_of_stock' : 'stock.low',
            $isOutOfStock ? 'អស់ស្តុក' : 'ស្តុកជិតអស់',
            $isOutOfStock
                ? "ផលិតផល {$product->name} អស់ពីស្តុក។"
                : "ផលិតផល {$product->name} នៅសល់ {$product->stock_quantity} {$product->unit}។",
            route('products.index', ['stock_status' => $isOutOfStock ? 'out_of_stock' : 'low_stock']),
            Product::class,
            $product->id,
        );
    }

    public function checkAll(): void
    {
        Product::query()->where('is_active', true)->chunkById(200, function ($products) {
            foreach ($products as $product) {
                $this->check($product);
            }
        });
    }
}
