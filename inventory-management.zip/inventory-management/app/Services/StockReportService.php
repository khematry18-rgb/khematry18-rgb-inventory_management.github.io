<?php

namespace App\Services;

use App\Models\Product;
use App\Models\StockMovement;
use Illuminate\Database\Eloquent\Builder;

class StockReportService
{
    public function products(array $filters = []): Builder
    {
        return Product::query()
            ->with('category:id,name')
            ->when($filters['product_id'] ?? null, fn ($q, $id) => $q->whereKey($id))
            ->when($filters['category_id'] ?? null, fn ($q, $id) => $q->where('category_id', $id))
            ->when(($filters['stock_status'] ?? null) === 'low', fn ($q) => $q->where('stock_quantity', '>', 0)->whereColumn('stock_quantity', '<=', 'minimum_stock'))
            ->when(($filters['stock_status'] ?? null) === 'out', fn ($q) => $q->where('stock_quantity', '=', 0))
            ->when(($filters['stock_status'] ?? null) === 'in', fn ($q) => $q->whereColumn('stock_quantity', '>', 'minimum_stock'));
    }

    public function movements(array $filters = [])
    {
        return StockMovement::query()
            ->with(['product.category:id,name', 'user:id,name'])
            ->when($filters['product_id'] ?? null, fn ($q, $id) => $q->where('product_id', $id))
            ->when($filters['movement_type'] ?? null, fn ($q, $type) => $q->where('movement_type', $type))
            ->when($filters['from_date'] ?? null, fn ($q) => $q->whereDate('transaction_date', '>=', $filters['from_date']))
            ->when($filters['to_date'] ?? null, fn ($q) => $q->whereDate('transaction_date', '<=', $filters['to_date']))
            ->latest('transaction_date');
    }
}
