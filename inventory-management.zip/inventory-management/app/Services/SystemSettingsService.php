<?php

namespace App\Services;

use App\Models\SystemSetting;
use App\Models\Product;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class SystemSettingsService
{
    private const CACHE_KEY = 'system.settings';

    public function defaults(): array
    {
        return [
            'store_name' => '',
            'store_logo' => null,
            'store_address' => '',
            'phone_number' => '',
            'email' => '',
            'website' => '',
            'receipt_footer' => '',
            'system_name' => 'ប្រព័ន្ធគ្រប់គ្រងសារពើភ័ណ្ឌ',
            'default_language' => 'km',
            'timezone' => 'Asia/Phnom_Penh',
            'date_format' => 'd/m/Y',
            'time_format' => 'H:i',
            'currency_code' => 'USD',
            'currency_symbol' => '$',
            'decimal_separator' => '.',
            'thousands_separator' => ',',
            'exchange_rate' => null,
            'allow_negative_stock' => false,
            'default_minimum_stock' => '0.000',
            'low_stock_alert' => true,
            'out_of_stock_alert' => true,
            'auto_generate_sku' => false,
            'sku_prefix' => 'SKU',
            'auto_generate_barcode' => true,
            'default_product_unit' => 'pcs',
            'invoice_prefix' => 'INV',
            'invoice_numbering' => 'date_random',
            'default_customer' => 'អតិថិជនរត់ចូល',
            'tax_enabled' => true,
            'tax_rate' => '0.00',
            'discounts_allowed' => true,
            'receipt_paper_size' => '80mm',
            'print_receipt_automatically' => false,
            'purchase_order_prefix' => 'PO',
            'purchase_order_numbering' => 'date_random',
            'default_purchase_status' => 'draft',
            'purchase_receipt_paper_size' => 'A4',
        ];
    }

    public function all(): array
    {
        return Cache::rememberForever(self::CACHE_KEY, function () {
            $stored = SystemSetting::query()->find(1)?->settings_data ?? [];

            return array_replace($this->defaults(), $stored);
        });
    }

    public function get(string $key): mixed
    {
        return $this->all()[$key] ?? null;
    }

    public function save(array $settings): array
    {
        $saved = DB::transaction(function () use ($settings) {
            $record = SystemSetting::query()->lockForUpdate()->find(1);
            $values = array_replace($this->defaults(), $record?->settings_data ?? [], $settings);
            $values['currency_symbol'] = $values['currency_code'] === 'KHR' ? '៛' : '$';

            SystemSetting::query()->updateOrCreate(
                ['id' => 1],
                ['settings_data' => $values],
            );

            return $values;
        });

        Cache::forget(self::CACHE_KEY);

        return $saved;
    }

    public function toUsd(float $amount, string $currency, ?float $exchangeRate = null): float
    {
        if ($currency === 'USD') {
            return $amount;
        }

        $rate = $exchangeRate ?? (float) $this->get('exchange_rate');
        abort_if($rate <= 0, 422, 'សូមកំណត់អត្រាប្តូរប្រាក់ USD/KHR ជាមុនសិន។');

        return $amount / $rate;
    }

    public function fromUsd(float $amount, string $currency, ?float $exchangeRate = null): float
    {
        if ($currency === 'USD') {
            return $amount;
        }

        $rate = $exchangeRate ?? (float) $this->get('exchange_rate');
        abort_if($rate <= 0, 422, 'សូមកំណត់អត្រាប្តូរប្រាក់ USD/KHR ជាមុនសិន។');

        return $amount * $rate;
    }

    public function formatAmount(float $amount, string $currency): string
    {
        $settings = $this->all();
        $symbol = $currency === 'KHR' ? '៛' : '$';
        $formatted = number_format(
            $amount,
            $currency === 'KHR' ? 0 : 2,
            $settings['decimal_separator'],
            $settings['thousands_separator'],
        );

        return $currency === 'KHR' ? $formatted . $symbol : $symbol . $formatted;
    }

    public function formatDate(mixed $value, bool $includeTime = false): string
    {
        if (! $value) {
            return '—';
        }

        $date = $value instanceof \DateTimeInterface
            ? \Illuminate\Support\Carbon::instance($value)
            : \Illuminate\Support\Carbon::parse($value);

        $format = $this->get('date_format');

        if ($includeTime) {
            $format .= ' ' . $this->get('time_format');
        }

        return $date->timezone($this->get('timezone'))->format($format);
    }

    public function generateSku(): string
    {
        do {
            $sku = strtoupper($this->get('sku_prefix')) . '-' . now()->format('ymd') . '-' . strtoupper(\Illuminate\Support\Str::random(6));
        } while (Product::withTrashed()->where('sku', $sku)->exists());

        return $sku;
    }
}
