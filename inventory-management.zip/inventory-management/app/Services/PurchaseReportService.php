<?php

namespace App\Services;

use App\Models\Purchase;
use Illuminate\Database\Eloquent\Builder;

class PurchaseReportService
{
    public function query(array $filters = []): Builder
    {
        return Purchase::query()
            ->with(['supplier:id,name', 'creator:id,name', 'items.product:id,name,sku'])
            ->where('status', '!=', 'cancelled')
            ->when($filters['from_date'] ?? null, fn ($q) => $q->whereDate('purchased_at', '>=', $filters['from_date']))
            ->when($filters['to_date'] ?? null, fn ($q) => $q->whereDate('purchased_at', '<=', $filters['to_date']))
            ->when($filters['supplier_id'] ?? null, fn ($q, $id) => $q->where('supplier_id', $id))
            ->when($filters['status'] ?? null, fn ($q, $status) => $q->where('status', $status))
            ->when($filters['payment_status'] ?? null, fn ($q, $status) => $q->where('payment_status', $status))
            ->when($filters['currency'] ?? null, fn ($q, $currency) => $q->where('currency', $currency))
            ->when($filters['product_id'] ?? null, fn ($q, $id) => $q->whereHas('items', fn ($iq) => $iq->where('product_id', $id)));
    }

    public function paginate(array $filters = [], int $perPage = 25)
    {
        return $this->query($filters)->latest('purchased_at')->paginate($perPage)->withQueryString();
    }

    public function summary(array $filters = []): array
    {
        $query = $this->query($filters);
        return [
            'purchase_count' => (clone $query)->count(),
            'by_currency' => (clone $query)
                ->reorder()
                ->selectRaw('currency, SUM(subtotal) AS subtotal, SUM(discount) AS discount, SUM(tax) AS tax, SUM(grand_total) AS grand_total')
                ->groupBy('currency')
                ->get()
                ->keyBy('currency'),
        ];
    }
}
