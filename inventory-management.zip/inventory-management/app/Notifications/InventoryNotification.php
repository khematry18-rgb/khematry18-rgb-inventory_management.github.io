<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class InventoryNotification extends Notification
{
    use Queueable;

    public static function typeLabel(string $type): string
    {
        return match ($type) {
            'stock.low' => 'ស្តុកជិតអស់',
            'stock.out_of_stock' => 'អស់ស្តុក',
            'purchase.created' => 'បញ្ជាទិញថ្មី',
            'purchase.received' => 'បានទទួលការទិញ',
            'purchase.cancelled' => 'បញ្ជាទិញត្រូវបានលុបចោល',
            'sale.created' => 'ការលក់ថ្មី',
            'sale.cancelled' => 'ការលក់ត្រូវបានលុបចោល',
            'payment.received' => 'បានទទួលការទូទាត់',
            'product.created' => 'ផលិតផលថ្មី',
            'product.updated' => 'បានកែប្រែផលិតផល',
            'product.deleted' => 'បានលុបផលិតផល',
            'system.alert' => 'ការជូនដំណឹងសំខាន់',
            default => 'ការជូនដំណឹង',
        };
    }

    public function __construct(
        private readonly string $eventType,
        private readonly string $title,
        private readonly string $message,
        private readonly ?string $url = null,
        private readonly ?string $recordType = null,
        private readonly int|string|null $recordId = null,
    ) {
    }

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toDatabase(object $notifiable): array
    {
        return [
            'event_type' => $this->eventType,
            'title' => $this->title,
            'message' => $this->message,
            'url' => $this->url,
            'record_type' => $this->recordType,
            'record_id' => $this->recordId,
        ];
    }
}
