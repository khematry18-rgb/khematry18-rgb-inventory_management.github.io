<?php

namespace App\Providers;

use App\Database\Query\Grammars\MariaDbGrammar;
use App\Models\Category;
use App\Models\Payment;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\Sale;
use App\Models\StockMovement;
use App\Models\Supplier;
use App\Models\User;
use App\Observers\InventoryActivityObserver;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        foreach ([Category::class, Payment::class, Product::class, Purchase::class, Sale::class, StockMovement::class, Supplier::class, User::class] as $model) {
            $model::observe(InventoryActivityObserver::class);
        }

        Gate::before(function ($user, string $ability) {
            if ($user->hasRole('admin')) {
                return true;
            }

            return null;
        });

        Gate::define('manage-settings', fn ($user) => $user->hasRole('admin'));

        if (DB::getDriverName() === 'mysql') {
            $connection = DB::connection();
            $version = (string) $connection->getPdo()->getAttribute(\PDO::ATTR_SERVER_VERSION);

            if (stripos($version, 'MariaDB') !== false) {
                $connection->setQueryGrammar(new MariaDbGrammar($connection));
            }
        }
    }
}
