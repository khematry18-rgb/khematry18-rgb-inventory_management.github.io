<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreCategoryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->hasPermission('categories.manage') ?? false;
    }

    public function rules(): array
    {
        return [
            'name' => [
                'required',
                'string',
                'max:255',
                Rule::unique('categories', 'name')->where(fn ($query) => $query->whereNull('deleted_at')),
            ],
            'description' => ['nullable', 'string', 'max:5000'],
            'is_active' => ['required', 'boolean'],
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'សូមបញ្ចូលឈ្មោះប្រភេទ។',
            'name.unique' => 'ឈ្មោះប្រភេទនេះមានរួចហើយ។',
            'name.max' => 'ឈ្មោះប្រភេទមិនអាចលើសពី 255 តួអក្សរ។',
            'is_active.required' => 'សូមជ្រើសរើសស្ថានភាពប្រភេទ។',
            'is_active.boolean' => 'ស្ថានភាពប្រភេទមិនត្រឹមត្រូវ។',
        ];
    }
}
