<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use App\Services\SystemSettingsService;

class PurchaseRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->hasRole('admin')
            || $this->user()?->hasPermission('purchases.manage')
            || false;
    }

    public function rules(): array
    {
        return [
            'supplier_id' => ['required', 'integer', 'exists:suppliers,id'],
            'currency' => ['required', Rule::in(['USD', 'KHR'])],
            'purchased_at' => ['required', 'date'],
            'expected_delivery_at' => ['nullable', 'date', 'after_or_equal:purchased_at'],
            'reference_number' => ['nullable', 'string', 'max:255'],
            'status' => ['required', 'in:draft,pending'],
            'discount' => ['required', 'numeric', 'min:0', 'max:999999999999.99'],
            'tax' => ['required', 'numeric', 'min:0', 'max:999999999999.99'],
            'notes' => ['nullable', 'string', 'max:5000'],
            'items' => ['required', 'array', 'min:1'],
            'items.*.product_id' => ['required', 'integer', 'distinct', 'exists:products,id'],
            'items.*.quantity' => ['required', 'numeric', 'min:0.001', 'max:999999999999.999'],
            'items.*.unit_cost' => ['required', 'numeric', 'min:0', 'max:999999999999.99'],
        ];
    }

    public function messages(): array
    {
        return [
            'supplier_id.required' => 'សូមជ្រើសរើសអ្នកផ្គត់ផ្គង់។',
            'items.required' => 'សូមបន្ថែមផលិតផលយ៉ាងហោចណាស់មួយ។',
            'items.*.product_id.distinct' => 'ផលិតផលស្ទួនក្នុងបញ្ជាទិញ។',
            'items.*.quantity.min' => 'បរិមាណទិញត្រូវធំជាងសូន្យ។',
            'items.*.unit_cost.min' => 'តម្លៃឯកតាមិនអាចជាលេខអវិជ្ជមាន។',
        ];
    }

    protected function prepareForValidation(): void
    {
        $settings = app(SystemSettingsService::class);
        $purchase = $this->route('purchase');

        $this->merge([
            'currency' => $this->input('currency', $purchase?->currency ?? $settings->get('currency_code')),
            'status' => $this->input('status', $purchase?->status ?? $settings->get('default_purchase_status')),
        ]);
    }
}
