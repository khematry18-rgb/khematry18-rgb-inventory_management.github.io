<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use DateTimeZone;

class UpdateSystemSettingsRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->hasRole('admin') ?? false;
    }

    public function rules(): array
    {
        return [
            'store_name' => ['nullable', 'string', 'max:255'],
            'store_address' => ['nullable', 'string', 'max:1000'],
            'phone_number' => ['nullable', 'string', 'max:40'],
            'email' => ['nullable', 'email', 'max:255'],
            'website' => ['nullable', 'url', 'max:255'],
            'receipt_footer' => ['nullable', 'string', 'max:1000'],
            'system_name' => ['required', 'string', 'max:255'],
            'default_language' => ['required', Rule::in(['km'])],
            'timezone' => ['required', Rule::in(DateTimeZone::listIdentifiers())],
            'date_format' => ['required', Rule::in(['d/m/Y', 'Y-m-d', 'd-m-Y'])],
            'time_format' => ['required', Rule::in(['H:i', 'h:i A', 'H:i:s'])],
            'currency_code' => ['required', Rule::in(['USD', 'KHR'])],
            'decimal_separator' => ['required', Rule::in(['.', ',']), 'different:thousands_separator'],
            'thousands_separator' => ['required', Rule::in([',', '.', ' '])],
            'exchange_rate' => ['nullable', 'numeric', 'regex:/^\d+(?:\.\d{1,4})?$/', 'gt:0', 'max:999999999999.9999', 'required_if:currency_code,KHR'],
            'allow_negative_stock' => ['required', 'boolean'],
            'default_minimum_stock' => ['required', 'numeric', 'decimal:0,3', 'min:0', 'max:999999999999.999'],
            'low_stock_alert' => ['required', 'boolean'],
            'out_of_stock_alert' => ['required', 'boolean'],
            'auto_generate_sku' => ['required', 'boolean'],
            'sku_prefix' => ['required', 'string', 'max:20', 'regex:/^[A-Za-z0-9_-]+$/'],
            'auto_generate_barcode' => ['required', 'boolean'],
            'default_product_unit' => ['required', 'string', 'max:30'],
            'invoice_prefix' => ['required', 'string', 'max:20', 'regex:/^[A-Za-z0-9_-]+$/'],
            'invoice_numbering' => ['required', Rule::in(['date_random', 'sequential'])],
            'default_customer' => ['required', 'string', 'max:255'],
            'tax_enabled' => ['required', 'boolean'],
            'tax_rate' => ['required', 'numeric', 'min:0', 'max:100'],
            'discounts_allowed' => ['required', 'boolean'],
            'receipt_paper_size' => ['required', Rule::in(['58mm', '80mm', 'A4'])],
            'print_receipt_automatically' => ['required', 'boolean'],
            'purchase_order_prefix' => ['required', 'string', 'max:20', 'regex:/^[A-Za-z0-9_-]+$/'],
            'purchase_order_numbering' => ['required', Rule::in(['date_random', 'sequential'])],
            'default_purchase_status' => ['required', Rule::in(['draft', 'pending'])],
            'purchase_receipt_paper_size' => ['required', Rule::in(['A4', '80mm'])],
            'store_logo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
        ];
    }

    public function messages(): array
    {
        return [
            'store_logo.image' => 'រូបសញ្ញាត្រូវជាឯកសាររូបភាព។',
            'store_logo.mimes' => 'រូបសញ្ញាត្រូវជា JPG, PNG ឬ WEBP។',
            'store_logo.max' => 'រូបសញ្ញាមិនអាចលើសពី 2MB។',
            'email.email' => 'សូមបញ្ចូលអាសយដ្ឋានអ៊ីមែលឱ្យបានត្រឹមត្រូវ។',
            'website.url' => 'សូមបញ្ចូល URL គេហទំព័រឱ្យបានត្រឹមត្រូវ។',
            'exchange_rate.required_if' => 'សូមបញ្ចូលអត្រាប្តូរប្រាក់ 1 USD = ប៉ុន្មាន KHR។',
            'decimal_separator.different' => 'សញ្ញាទសភាគ និងសញ្ញាបំបែកខ្ទង់ពាន់ត្រូវតែខុសគ្នា។',
        ];
    }

    protected function prepareForValidation(): void
    {
        foreach ([
            'allow_negative_stock',
            'low_stock_alert',
            'out_of_stock_alert',
            'auto_generate_sku',
            'auto_generate_barcode',
            'tax_enabled',
            'discounts_allowed',
            'print_receipt_automatically',
        ] as $field) {
            $this->merge([$field => $this->boolean($field)]);
        }
    }
}
