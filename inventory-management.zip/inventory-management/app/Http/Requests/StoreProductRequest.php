<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use App\Services\SystemSettingsService;

class StoreProductRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->hasRole('admin')
            || $this->user()?->hasPermission('products.manage')
            || false;
    }

    public function rules(): array
    {
        $autoGenerateSku = app(SystemSettingsService::class)->get('auto_generate_sku');

        return [
            'category_id' => ['required', 'integer', 'exists:categories,id'],
            'name' => ['required', 'string', 'max:255'],
            'sku' => [
                $autoGenerateSku ? 'nullable' : 'required',
                'string',
                'max:100',
                Rule::unique('products', 'sku')->where(fn ($query) => $query->whereNull('deleted_at')),
            ],
            'barcode' => [
                'nullable',
                'string',
                'max:100',
                'regex:/^[\x20-\x7E]+$/',
                Rule::unique('products', 'barcode'),
            ],
            'description' => ['nullable', 'string', 'max:5000'],
            'cost_price' => ['required', 'numeric', 'min:0', 'max:9999999999999.99'],
            'selling_price' => ['required', 'numeric', 'min:0', 'max:9999999999999.99'],
            'stock_quantity' => ['required', 'numeric', 'decimal:0,3', 'min:0', 'max:999999999999.999'],
            'minimum_stock' => ['required', 'numeric', 'decimal:0,3', 'min:0', 'max:999999999999.999'],
            'unit' => ['required', 'string', 'max:30'],
            'image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
            'is_active' => ['required', 'boolean'],
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'សូមបញ្ចូលឈ្មោះផលិតផល។',
            'sku.required' => 'សូមបញ្ចូលលេខ SKU។',
            'sku.unique' => 'លេខ SKU នេះមានរួចហើយ។',
            'barcode.unique' => 'លេខ Barcode នេះមានរួចហើយ។',
            'barcode.regex' => 'លេខ Barcode ត្រូវប្រើតែតួអក្សរអង់គ្លេសដែលអាចបោះពុម្ពបាន។',
            'category_id.exists' => 'ប្រភេទផលិតផលមិនត្រឹមត្រូវ។',
            'cost_price.min' => 'តម្លៃដើមមិនអាចជាលេខអវិជ្ជមាន។',
            'selling_price.min' => 'តម្លៃលក់មិនអាចជាលេខអវិជ្ជមាន។',
            'stock_quantity.min' => 'បរិមាណស្តុកមិនអាចជាលេខអវិជ្ជមាន។',
            'minimum_stock.min' => 'បរិមាណស្តុកអប្បបរមាមិនអាចជាលេខអវិជ្ជមាន។',
            'image.image' => 'ឯកសារផ្ទុកត្រូវតែជារូបភាព។',
            'image.mimes' => 'រូបភាពត្រូវជា JPG, JPEG, PNG ឬ WEBP។',
            'image.max' => 'រូបភាពមិនអាចលើសពី 2MB។',
        ];
    }

    protected function prepareForValidation(): void
    {
        $settings = app(SystemSettingsService::class);
        $this->merge([
            'barcode' => filled($this->barcode) ? trim((string) $this->barcode) : null,
            'minimum_stock' => $this->input('minimum_stock', $settings->get('default_minimum_stock')),
            'unit' => $this->input('unit', $settings->get('default_product_unit')),
        ]);
    }
}
