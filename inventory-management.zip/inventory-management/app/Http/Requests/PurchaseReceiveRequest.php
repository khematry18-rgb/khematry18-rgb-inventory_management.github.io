<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PurchaseReceiveRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->hasRole('admin')
            || $this->user()?->hasPermission('purchases.manage')
            || false;
    }

    public function rules(): array
    {
        return [
            'received_at' => ['required', 'date'],
            'items' => ['required', 'array', 'min:1'],
            'items.*.received_quantity' => ['required', 'numeric', 'min:0', 'max:999999999999.999'],
            'submission_key' => ['required', 'string', 'size:36'],
            'notes' => ['nullable', 'string', 'max:5000'],
        ];
    }
}
