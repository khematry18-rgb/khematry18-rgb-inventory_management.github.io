<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PurchasePaymentRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->hasRole('admin')
            || $this->user()?->hasPermission('purchases.manage')
            || false;
    }

    public function rules(): array
    {
        return [
            'amount' => ['required', 'numeric', 'min:0.01', 'max:999999999999.99'],
            'method' => ['required', 'in:cash,bank,card,other'],
            'paid_at' => ['required', 'date'],
            'currency' => ['required', 'in:USD,KHR'],
            'exchange_rate' => ['required', 'numeric', 'min:0.0001', 'max:999999999999.9999'],
            'reference' => ['nullable', 'string', 'max:255'],
            'notes' => ['nullable', 'string', 'max:5000'],
        ];
    }
}
