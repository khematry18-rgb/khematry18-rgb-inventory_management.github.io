<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StockTransactionRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->hasRole('admin')
            || $this->user()?->hasPermission('stock.manage')
            || false;
    }

    public function rules(): array
    {
        $operation = $this->routeIs('stock.in.store')
            ? 'in'
            : ($this->routeIs('stock.out.store') ? 'out' : 'adjustment');

        $rules = [
            'product_id' => ['required', 'integer', 'exists:products,id'],
            'reference_number' => ['nullable', 'string', 'max:255'],
            'transaction_date' => ['required', 'date'],
            'notes' => ['nullable', 'string', 'max:5000'],
            'submission_key' => ['required', 'string', 'size:36'],
        ];

        if ($operation === 'adjustment') {
            $rules['actual_quantity'] = ['required', 'numeric', 'min:0', 'max:999999999999.999'];
            $rules['reason'] = ['required', 'string', 'max:255'];
        } else {
            $rules['quantity'] = ['required', 'numeric', 'min:0.001', 'max:999999999999.999'];
            $rules['reason'] = $operation === 'out'
                ? ['required', 'string', 'max:255']
                : ['nullable', 'string', 'max:255'];
        }

        if ($operation === 'in') {
            $rules['unit_cost'] = ['nullable', 'numeric', 'min:0', 'max:999999999999.99'];
        }

        return $rules;
    }

    public function messages(): array
    {
        return [
            'product_id.required' => 'សូមជ្រើសរើសផលិតផល។',
            'product_id.exists' => 'ផលិតផលមិនមានក្នុងប្រព័ន្ធ។',
            'quantity.required' => 'សូមបញ្ចូលបរិមាណ។',
            'quantity.min' => 'បរិមាណត្រូវតែធំជាងសូន្យ។',
            'actual_quantity.required' => 'សូមបញ្ចូលបរិមាណស្តុកពិតប្រាកដ។',
            'reason.required' => 'សូមបញ្ចូលមូលហេតុ។',
            'transaction_date.required' => 'សូមបញ្ចូលកាលបរិច្ឆេទប្រតិបត្តិការ។',
        ];
    }
}
