<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use App\Services\SystemSettingsService;

class SaleRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->hasRole('admin')
            || $this->user()?->hasPermission('sales.manage')
            || $this->user()?->hasPermission('sales.create')
            || false;
    }

    public function rules(): array
    {
        return [
            'submission_key' => ['required', 'uuid'],
            'currency' => ['required', Rule::in(['USD', 'KHR'])],
            'sold_at' => ['required', 'date'],
            'customer_name' => ['nullable', 'string', 'max:255'],
            'customer_phone' => ['nullable', 'string', 'max:30'],
            'customer_email' => ['nullable', 'email', 'max:255'],
            'customer_address' => ['nullable', 'string', 'max:5000'],
            'discount' => ['required', 'numeric', 'min:0', 'max:999999999999.99'],
            'tax' => ['required', 'numeric', 'min:0', 'max:999999999999.99'],
            'amount_paid' => ['required', 'numeric', 'min:0', 'max:999999999999.99'],
            'payment_method' => ['required_with:amount_paid', 'in:cash,bank,aba,acleda,other'],
            'payment_reference' => ['nullable', 'string', 'max:255'],
            'payment_notes' => ['nullable', 'string', 'max:5000'],
            'notes' => ['nullable', 'string', 'max:5000'],
            'items' => ['required', 'array', 'min:1'],
            'items.*.product_id' => ['required', 'integer', 'distinct', 'exists:products,id'],
            'items.*.quantity' => ['required', 'numeric', 'min:0.001', 'max:999999999999.999'],
        ];
    }

    public function messages(): array
    {
        return [
            'items.required' => 'សូមបន្ថែមផលិតផលយ៉ាងហោចណាស់មួយ។',
            'items.*.product_id.distinct' => 'ផលិតផលស្ទួនក្នុងការលក់។',
            'items.*.quantity.min' => 'បរិមាណលក់ត្រូវធំជាងសូន្យ។',
            'submission_key.required' => 'លេខសម្ងាត់បញ្ជូនសម្គាល់មិនត្រឹមត្រូវ។',
        ];
    }

    protected function prepareForValidation(): void
    {
        $settings = app(SystemSettingsService::class);
        $this->merge(['currency' => $this->input('currency', $settings->get('currency_code'))]);
    }
}
