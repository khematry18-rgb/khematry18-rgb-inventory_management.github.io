<?php

namespace App\Http\Requests;

use App\Models\Supplier;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateSupplierRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->hasRole('admin')
            || $this->user()?->hasPermission('suppliers.manage')
            || false;
    }

    public function rules(): array
    {
        $supplier = $this->route('supplier');
        $supplierId = $supplier instanceof Supplier ? $supplier->id : null;

        return [
            'name' => [
                'required',
                'string',
                'max:255',
                Rule::unique('suppliers', 'name')->ignore($supplierId)->where(fn ($query) => $query->whereNull('deleted_at')),
            ],
            'company_name' => ['nullable', 'string', 'max:255'],
            'contact_person' => ['nullable', 'string', 'max:255'],
            'phone' => ['nullable', 'string', 'max:30', 'regex:/^[0-9+\-().\s]+$/'],
            'email' => [
                'nullable',
                'email',
                'max:255',
                Rule::unique('suppliers', 'email')->ignore($supplierId)->where(fn ($query) => $query->whereNull('deleted_at')),
            ],
            'address' => ['nullable', 'string', 'max:5000'],
            'city' => ['nullable', 'string', 'max:255'],
            'country' => ['nullable', 'string', 'max:255'],
            'tax_id' => ['nullable', 'string', 'max:100'],
            'notes' => ['nullable', 'string', 'max:5000'],
            'is_active' => ['required', 'boolean'],
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'សូមបញ្ចូលឈ្មោះអ្នកផ្គត់ផ្គង់។',
            'name.unique' => 'អ្នកផ្គត់ផ្គង់ដែលមានឈ្មោះនេះមានរួចហើយ។',
            'email.email' => 'អ៊ីមែលមិនត្រឹមត្រូវ។',
            'email.unique' => 'អ៊ីមែលនេះបានប្រើដោយអ្នកផ្គត់ផ្គង់ផ្សេងរួចហើយ។',
            'phone.regex' => 'លេខទូរស័ព្ទមិនត្រឹមត្រូវ។',
        ];
    }

    protected function prepareForValidation(): void
    {
        $this->merge([
            'email' => filled($this->email) ? strtolower(trim((string) $this->email)) : null,
            'phone' => filled($this->phone) ? trim((string) $this->phone) : null,
            'tax_id' => filled($this->tax_id) ? trim((string) $this->tax_id) : null,
        ]);
    }
}
