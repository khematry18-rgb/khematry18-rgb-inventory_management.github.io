<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class PermissionMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  Closure(Request): (Response)  $next
     */
    public function handle(Request $request, Closure $next, string $permission): Response
    {
        $user = $request->user();
        $allowed = $user?->hasRole('admin')
            || $user?->hasPermission($permission);

        if (! $allowed && str_ends_with($permission, '.view')) {
            $managePermission = str_replace('.view', '.manage', $permission);
            $allowed = $user?->hasPermission($managePermission) ?? false;
        }

        if (! $allowed) {
            abort(403, 'អ្នកមិនមានសិទ្ធិប្រើមុខងារនេះទេ។');
        }

        return $next($request);
    }
}
