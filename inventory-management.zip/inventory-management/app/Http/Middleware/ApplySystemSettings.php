<?php

namespace App\Http\Middleware;

use App\Services\SystemSettingsService;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Symfony\Component\HttpFoundation\Response;

class ApplySystemSettings
{
    public function handle(Request $request, Closure $next): Response
    {
        $settings = app(SystemSettingsService::class)->all();
        config(['app.timezone' => $settings['timezone']]);
        date_default_timezone_set($settings['timezone']);
        App::setLocale($settings['default_language']);
        view()->share('systemSettings', $settings);

        return $next($request);
    }
}
