<?php

namespace App\Http\Controllers;

use App\Http\Requests\StockTransactionRequest;
use App\Models\Product;
use App\Models\StockMovement;
use App\Models\User;
use App\Services\StockService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use RuntimeException;

class StockController extends Controller
{
    public function __construct(private readonly StockService $stockService)
    {
    }

    public function index(): View
    {
        $products = Product::query()
            ->withTrashed(false)
            ->select(['id', 'name', 'sku', 'stock_quantity', 'minimum_stock', 'unit'])
            ->orderBy('name')
            ->get();

        $lowStockProducts = $products->filter(fn ($product) =>
            (float) $product->stock_quantity > 0
            && (float) $product->stock_quantity <= (float) $product->minimum_stock
        )->take(10);

        $stockMovements = StockMovement::query()
            ->with(['product:id,name,sku,unit', 'user:id,name'])
            ->latest('transaction_date')
            ->latest()
            ->limit(10)
            ->get();

        return view('stock.index', [
            'totalProducts' => $products->count(),
            'inStockProducts' => $products->filter(fn ($product) => (float) $product->stock_quantity > (float) $product->minimum_stock)->count(),
            'lowStockProducts' => $lowStockProducts,
            'lowStockCount' => $products->filter(fn ($product) => (float) $product->stock_quantity > 0 && (float) $product->stock_quantity <= (float) $product->minimum_stock)->count(),
            'outOfStockCount' => $products->filter(fn ($product) => (float) $product->stock_quantity <= 0)->count(),
            'totalStockQuantity' => (float) $products->sum(fn ($product) => (float) $product->stock_quantity),
            'stockMovements' => $stockMovements,
        ]);
    }

    public function stockIn(): View
    {
        return view('stock.in', ['products' => $this->selectableProducts()]);
    }

    public function storeStockIn(StockTransactionRequest $request): RedirectResponse
    {
        return $this->storeTransaction($request, 'stock_in');
    }

    public function stockOut(): View
    {
        return view('stock.out', ['products' => $this->selectableProducts()]);
    }

    public function storeStockOut(StockTransactionRequest $request): RedirectResponse
    {
        return $this->storeTransaction($request, 'stock_out');
    }

    public function adjustment(): View
    {
        return view('stock.adjustment', ['products' => $this->selectableProducts()]);
    }

    public function storeAdjustment(StockTransactionRequest $request): RedirectResponse
    {
        return $this->storeTransaction($request, 'adjustment');
    }

    public function history(): View
    {
        $perPage = in_array((int) request('per_page', 10), [10, 25, 50], true)
            ? (int) request('per_page', 10)
            : 10;

        $movements = StockMovement::query()
            ->with(['product:id,name,sku,unit', 'user:id,name'])
            ->when(request('search'), function ($query, $search) {
                $query->whereHas('product', function ($productQuery) use ($search) {
                    $productQuery->where('name', 'like', "%{$search}%")
                        ->orWhere('sku', 'like', "%{$search}%");
                });
            })
            ->when(request('movement_type'), fn ($query) => $query->where('movement_type', request('movement_type')))
            ->when(request('from_date'), fn ($query) => $query->whereDate('transaction_date', '>=', request('from_date')))
            ->when(request('to_date'), fn ($query) => $query->whereDate('transaction_date', '<=', request('to_date')))
            ->when(request('user_id'), fn ($query) => $query->where('user_id', request('user_id')))
            ->when(request('stock_status'), function ($query, $stockStatus) {
                $query->whereHas('product', function ($productQuery) use ($stockStatus) {
                    if ($stockStatus === 'out_of_stock') {
                        $productQuery->where('stock_quantity', '=', 0);
                    } elseif ($stockStatus === 'low_stock') {
                        $productQuery->where('stock_quantity', '>', 0)->whereColumn('stock_quantity', '<=', 'minimum_stock');
                    } elseif ($stockStatus === 'in_stock') {
                        $productQuery->whereColumn('stock_quantity', '>', 'minimum_stock');
                    }
                });
            })
            ->latest('transaction_date')
            ->latest()
            ->paginate($perPage)
            ->withQueryString();

        return view('stock.history', [
            'movements' => $movements,
            'users' => User::whereHas('stockMovements')->orderBy('name')->get(['id', 'name']),
        ]);
    }

    private function storeTransaction(StockTransactionRequest $request, string $operation): RedirectResponse
    {
        $product = Product::findOrFail($request->integer('product_id'));

        try {
            if ($operation === 'stock_in') {
                $this->stockService->stockIn($product, $request->user(), $request->validated());
                $message = 'បានបញ្ចូលស្តុកដោយជោគជ័យ។';
                $redirect = 'stock.in';
            } elseif ($operation === 'stock_out') {
                $this->stockService->stockOut($product, $request->user(), $request->validated());
                $message = 'បានដកស្តុកដោយជោគជ័យ។';
                $redirect = 'stock.out';
            } else {
                $this->stockService->adjustment($product, $request->user(), $request->validated());
                $message = 'បានកែតម្រូវស្តុកដោយជោគជ័យ។';
                $redirect = 'stock.adjustment';
            }
        } catch (RuntimeException $exception) {
            return back()->withInput()->with('error', $exception->getMessage());
        }

        return redirect()->route($redirect)->with('success', $message);
    }

    private function selectableProducts()
    {
        return Product::query()
            ->select(['id', 'name', 'sku', 'stock_quantity', 'minimum_stock', 'unit'])
            ->orderBy('name')
            ->get();
    }
}
