<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Models\Role;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $users = User::query()
            ->with('role')
            ->when(request('search'), function ($query, $search) {
                $query->where(function ($query) use ($search) {
                    $query->where('name', 'like', "%{$search}%")
                        ->orWhere('email', 'like', "%{$search}%")
                        ->orWhere('phone', 'like', "%{$search}%");
                });
            })
            ->when(request('role_id'), fn ($query, $roleId) => $query->where('role_id', $roleId))
            ->when(request()->filled('is_active'), fn ($query) => $query->where('is_active', request('is_active')))
            ->latest()
            ->paginate(15)
            ->withQueryString();

        return view('users.index', [
            'users' => $users,
            'roles' => Role::where('is_active', true)->orderBy('name')->get(),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('users.create', ['roles' => Role::where('is_active', true)->get()]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreUserRequest $request)
    {
        User::create([
            'name' => $request->string('name')->toString(),
            'email' => $request->string('email')->toString(),
            'phone' => $request->input('phone'),
            'role_id' => $request->integer('role_id'),
            'password' => Hash::make($request->string('password')->toString()),
            'is_active' => $request->boolean('is_active'),
        ]);

        return redirect()->route('users.index')->with('success', 'បានបង្កើតអ្នកប្រើប្រាស់ដោយជោគជ័យ។');
    }

    /**
     * Display the specified resource.
     */
    public function show(User $user)
    {
        return view('users.show', ['user' => $user->load('role')]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User $user)
    {
        return view('users.edit', [
            'user' => $user,
            'roles' => Role::where('is_active', true)->get(),
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateUserRequest $request, User $user)
    {
        if ($request->user()->is($user) && $request->integer('role_id') !== (int) $user->role_id) {
            if (! $request->user()->hasPermission('users.manage')) {
                abort(403, 'អ្នកមិនអាចផ្លាស់ប្តូរតួនាទីរបស់ខ្លួនបានទេ។');
            }
        }

        $user->update([
            'name' => $request->string('name')->toString(),
            'email' => $request->string('email')->toString(),
            'phone' => $request->input('phone'),
            'role_id' => $request->integer('role_id'),
            'is_active' => $request->boolean('is_active'),
        ]);

        return redirect()->route('users.index')->with('success', 'បានកែសម្រួលអ្នកប្រើប្រាស់ដោយជោគជ័យ។');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(User $user)
    {
        if (request()->user()->is($user)) {
            return back()->with('error', 'អ្នកមិនអាចលុបគណនីរបស់ខ្លួនបានទេ។');
        }

        if ($user->role?->slug === 'admin') {
            $adminCount = User::whereHas('role', fn ($query) => $query->where('slug', 'admin'))->count();
            if ($adminCount <= 1) {
                return back()->with('error', 'មិនអាចលុបគណនីអ្នកគ្រប់គ្រងចុងក្រោយបានទេ។');
            }
        }

        $user->delete();

        return redirect()->route('users.index')->with('success', 'បានលុបអ្នកប្រើប្រាស់ដោយជោគជ័យ។');
    }
}
