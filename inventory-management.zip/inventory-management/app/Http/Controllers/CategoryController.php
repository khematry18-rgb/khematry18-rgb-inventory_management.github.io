<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreCategoryRequest;
use App\Http\Requests\UpdateCategoryRequest;
use App\Models\Category;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\View\View;

class CategoryController extends Controller
{
    public function index(): View
    {
        $categories = Category::query()
            ->withCount('products')
            ->when(request('search'), function ($query, $search) {
                $query->where(function ($query) use ($search) {
                    $query->where('name', 'like', "%{$search}%")
                        ->orWhere('slug', 'like', "%{$search}%")
                        ->orWhere('description', 'like', "%{$search}%");
                });
            })
            ->when(request()->filled('is_active'), fn ($query) => $query->where('is_active', request('is_active')))
            ->latest()
            ->paginate(15)
            ->withQueryString();

        return view('categories.index', compact('categories'));
    }

    public function create(): View
    {
        return view('categories.create');
    }

    public function store(StoreCategoryRequest $request): RedirectResponse
    {
        Category::create([
            'name' => $request->string('name')->trim()->toString(),
            'slug' => $this->makeUniqueSlug($request->string('name')->trim()->toString()),
            'description' => $request->filled('description') ? $request->string('description')->trim()->toString() : null,
            'is_active' => $request->boolean('is_active'),
        ]);

        return redirect()->route('categories.index')->with('success', 'បានបង្កើតប្រភេទដោយជោគជ័យ។');
    }

    public function show(Category $category): View
    {
        return view('categories.show', [
            'category' => $category->loadCount('products')->load(['products' => fn ($query) => $query->latest()->limit(10)]),
        ]);
    }

    public function edit(Category $category): View
    {
        return view('categories.edit', compact('category'));
    }

    public function update(UpdateCategoryRequest $request, Category $category): RedirectResponse
    {
        $name = $request->string('name')->trim()->toString();
        $category->update([
            'name' => $name,
            'slug' => $category->name === $name
                ? $category->slug
                : $this->makeUniqueSlug($name, $category->id),
            'description' => $request->filled('description') ? $request->string('description')->trim()->toString() : null,
            'is_active' => $request->boolean('is_active'),
        ]);

        return redirect()->route('categories.index')->with('success', 'បានកែសម្រួលប្រភេទដោយជោគជ័យ។');
    }

    public function destroy(Category $category): RedirectResponse
    {
        if ($category->products()->exists()) {
            return back()->with('error', 'មិនអាចលុបប្រភេទនេះបានទេ ព្រោះវានៅតែប្រើដោយផលិតផល។');
        }

        $category->delete();

        return redirect()->route('categories.index')->with('success', 'បានលុបប្រភេទដោយជោគជ័យ។');
    }

    private function makeUniqueSlug(string $name, ?int $ignoreId = null): string
    {
        $base = Str::slug($name);
        if ($base === '') {
            $base = 'category-' . strtolower(Str::random(8));
        }

        $slug = $base;
        $number = 2;
        while (Category::withTrashed()
            ->when($ignoreId, fn ($query) => $query->where('id', '!=', $ignoreId))
            ->where('slug', $slug)
            ->exists()) {
            $slug = $base . '-' . $number++;
        }

        return $slug;
    }
}
