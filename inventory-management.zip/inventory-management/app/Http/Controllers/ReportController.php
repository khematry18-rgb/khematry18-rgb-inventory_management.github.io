<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\StockMovement;
use App\Models\Supplier;
use App\Models\User;
use App\Services\ProfitLossReportService;
use App\Services\PurchaseReportService;
use App\Services\SalesReportService;
use App\Services\StockReportService;
use App\Services\SystemSettingsService;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ReportController extends Controller
{
    public function __construct(
        private readonly SalesReportService $salesReports,
        private readonly PurchaseReportService $purchaseReports,
        private readonly StockReportService $stockReports,
        private readonly ProfitLossReportService $profitLossReports,
        private readonly SystemSettingsService $settings,
    ) {
    }

    public function index(Request $request)
    {
        $filters = $this->validatedFilters($request);
        $salesSummary = $this->salesReports->summary($filters);
        $purchaseSummary = $this->purchaseReports->summary($filters);
        $stockValue = (float) Product::query()->where('is_active', true)->selectRaw('COALESCE(SUM(stock_quantity * cost_price), 0) AS value')->value('value');
        $profitLoss = $this->profitLossReports->calculate($filters);

        $dailySales = $this->salesReports->dailyTotals($filters, $this->settings->get('currency_code'));
        $topProducts = $this->salesReports->topProducts($filters);

        return view('reports.index', [
            'filters' => $filters,
            'salesSummary' => $salesSummary,
            'purchaseSummary' => $purchaseSummary,
            'profitLoss' => $profitLoss,
            'totalProducts' => Product::where('is_active', true)->count(),
            'stockValue' => $stockValue,
            'lowStock' => Product::where('is_active', true)->where('stock_quantity', '>', 0)->whereColumn('stock_quantity', '<=', 'minimum_stock')->count(),
            'outStock' => Product::where('is_active', true)->where('stock_quantity', '=', 0)->count(),
            'dailySales' => $dailySales,
            'topProducts' => $topProducts,
            'products' => Product::where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'categories' => Category::where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'suppliers' => Supplier::where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'users' => User::orderBy('name')->get(['id', 'name']),
        ]);
    }

    public function sales(Request $request)
    {
        $filters = $this->validatedFilters($request);
        return view('reports.sales', [
            'filters' => $filters,
            'sales' => $this->salesReports->paginate($filters, $this->perPage($request)),
            'summary' => $this->salesReports->summary($filters),
            'products' => Product::where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'categories' => Category::where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'users' => User::orderBy('name')->get(['id', 'name']),
        ]);
    }

    public function purchases(Request $request)
    {
        $filters = $this->validatedFilters($request);
        return view('reports.purchases', [
            'filters' => $filters,
            'purchases' => $this->purchaseReports->paginate($filters, $this->perPage($request)),
            'summary' => $this->purchaseReports->summary($filters),
            'products' => Product::where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'suppliers' => Supplier::where('is_active', true)->orderBy('name')->get(['id', 'name']),
        ]);
    }

    public function stock(Request $request)
    {
        $filters = $this->validatedFilters($request);
        $products = $this->stockReports->products($filters)->orderBy('name')->paginate($this->perPage($request))->withQueryString();
        $movements = $this->stockReports->movements($filters)->paginate($this->perPage($request), ['*'], 'movements_page')->withQueryString();
        return view('reports.stock', [
            'filters' => $filters,
            'products' => $products,
            'movements' => $movements,
            'productsList' => Product::where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'categories' => Category::where('is_active', true)->orderBy('name')->get(['id', 'name']),
        ]);
    }

    public function profitLoss(Request $request)
    {
        $filters = $this->validatedFilters($request);
        return view('reports.profit-loss', [
            'filters' => $filters,
            'profitLoss' => $this->profitLossReports->calculate($filters),
            'products' => Product::where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'categories' => Category::where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'users' => User::orderBy('name')->get(['id', 'name']),
        ]);
    }

    public function exportSales(Request $request): StreamedResponse
    {
        return $this->exportCsv('sales-report.csv', ['Invoice', 'Date', 'Customer', 'Currency', 'Exchange Rate', 'Product', 'Quantity', 'Unit Price', 'Subtotal', 'Discount', 'Tax', 'Grand Total', 'Payment Status', 'Status'], function () use ($request) {
            foreach ($this->salesReports->query($this->validatedFilters($request))->lazyById(100) as $sale) {
                foreach ($sale->items as $item) {
                    yield [$sale->sale_number, optional($sale->sold_at)->format('Y-m-d H:i'), $sale->customer_name, $sale->currency, $sale->exchange_rate, $item->product->name ?? '', $item->quantity, $item->unit_price, $sale->subtotal, $sale->discount, $sale->tax, $sale->grand_total, $sale->payment_status, $sale->status];
                }
            }
        });
    }

    public function exportPurchases(Request $request): StreamedResponse
    {
        return $this->exportCsv('purchases-report.csv', ['Order Number', 'Date', 'Supplier', 'Currency', 'Exchange Rate', 'Product', 'Quantity', 'Unit Cost', 'Grand Total', 'Payment Status', 'Purchase Status'], function () use ($request) {
            foreach ($this->purchaseReports->query($this->validatedFilters($request))->lazyById(100) as $purchase) {
                foreach ($purchase->items as $item) {
                    yield [$purchase->purchase_number, optional($purchase->purchased_at)->format('Y-m-d H:i'), $purchase->supplier->name ?? '', $purchase->currency, $purchase->exchange_rate, $item->product->name ?? '', $item->quantity, $item->unit_cost, $purchase->grand_total, $purchase->payment_status, $purchase->status];
                }
            }
        });
    }

    public function exportStock(Request $request): StreamedResponse
    {
        return $this->exportCsv('stock-report.csv', ['Product', 'SKU', 'Barcode', 'Category', 'Current Quantity', 'Minimum Stock', 'Cost Price', 'Stock Value', 'Status'], function () use ($request) {
            foreach ($this->stockReports->products($this->validatedFilters($request))->cursor() as $product) {
                $status = $product->stock_quantity == 0 ? 'Out of Stock' : ($product->stock_quantity <= $product->minimum_stock ? 'Low Stock' : 'In Stock');
                yield [$product->name, $product->sku, $product->barcode, $product->category->name ?? '', $product->stock_quantity, $product->minimum_stock, $product->cost_price, round((float) $product->stock_quantity * (float) $product->cost_price, 2), $status];
            }
        });
    }

    public function exportProfitLoss(Request $request): StreamedResponse
    {
        return $this->exportCsv('profit-loss-report.csv', ['Currency', 'Metric', 'Amount'], function () use ($request) {
            $data = $this->profitLossReports->calculate($this->validatedFilters($request));
            foreach ($data['by_currency'] as $currency => $totals) {
                foreach ($totals as $key => $value) {
                    yield [$currency, str_replace('_', ' ', ucfirst($key)), $value];
                }
                yield [$currency, 'net profit', 'Not available; operating expenses are not recorded'];
            }
        });
    }

    private function validatedFilters(Request $request): array
    {
        return $request->validate([
            'from_date' => ['nullable', 'date'],
            'to_date' => ['nullable', 'date', 'after_or_equal:from_date'],
            'product_id' => ['nullable', 'integer', 'exists:products,id'],
            'category_id' => ['nullable', 'integer', 'exists:categories,id'],
            'supplier_id' => ['nullable', 'integer', 'exists:suppliers,id'],
            'payment_method' => ['nullable', 'in:cash,bank,card,aba,acleda,other'],
            'status' => ['nullable', 'string', 'max:30'],
            'payment_status' => ['nullable', 'in:unpaid,partially_paid,paid'],
            'cashier_id' => ['nullable', 'integer', 'exists:users,id'],
            'customer' => ['nullable', 'string', 'max:255'],
            'stock_status' => ['nullable', 'in:in,low,out'],
            'movement_type' => ['nullable', 'string', 'max:30'],
            'currency' => ['nullable', 'in:USD,KHR'],
        ]);
    }

    private function perPage(Request $request): int
    {
        return in_array((int) $request->integer('per_page', 25), [10, 25, 50], true) ? (int) $request->integer('per_page', 25) : 25;
    }

    private function exportCsv(string $filename, array $headers, callable $rows): StreamedResponse
    {
        return response()->streamDownload(function () use ($headers, $rows) {
            $output = fopen('php://output', 'w');
            fputcsv($output, $headers);
            foreach ($rows() as $row) {
                fputcsv($output, $row);
            }
            fclose($output);
        }, $filename, ['Content-Type' => 'text/csv; charset=UTF-8']);
    }
}
