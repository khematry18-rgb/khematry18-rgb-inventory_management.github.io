<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreProductRequest;
use App\Http\Requests\UpdateProductRequest;
use App\Models\Category;
use App\Models\Product;
use App\Services\BarcodeService;
use App\Services\StockService;
use App\Services\SystemSettingsService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class ProductController extends Controller
{
    public function index(): View
    {
        $perPage = in_array((int) request('per_page', 10), [10, 25, 50], true)
            ? (int) request('per_page', 10)
            : 10;

        $products = Product::query()
            ->with('category:id,name')
            ->when(request('search'), function ($query, $search) {
                $query->where(function ($query) use ($search) {
                    $query->where('name', 'like', "%{$search}%")
                        ->orWhere('sku', 'like', "%{$search}%")
                        ->orWhere('barcode', 'like', "%{$search}%");
                });
            })
            ->when(request('category_id'), fn ($query) => $query->where('category_id', request('category_id')))
            ->when(request()->filled('is_active'), fn ($query) => $query->where('is_active', request('is_active')))
            ->when(request('stock_status') === 'in_stock', fn ($query) => $query->where('stock_quantity', '>', 0)->whereColumn('stock_quantity', '>', 'minimum_stock'))
            ->when(request('stock_status') === 'low_stock', fn ($query) => $query->where('stock_quantity', '>', 0)->whereColumn('stock_quantity', '<=', 'minimum_stock'))
            ->when(request('stock_status') === 'out_of_stock', fn ($query) => $query->where('stock_quantity', '<=', 0))
            ->latest()
            ->paginate($perPage)
            ->withQueryString();

        return view('products.index', [
            'products' => $products,
            'categories' => Category::where('is_active', true)->orderBy('name')->get(['id', 'name']),
        ]);
    }

    public function create(SystemSettingsService $settings): View
    {
        return view('products.create', [
            'categories' => Category::where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'settings' => $settings->all(),
        ]);
    }

    public function store(
        StoreProductRequest $request,
        BarcodeService $barcodeService,
        SystemSettingsService $settings,
        StockService $stockService,
    ): RedirectResponse
    {
        $imagePath = null;
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('products', 'public');
        }

        $stockQuantity = (float) $request->input('stock_quantity');
        $sku = $request->filled('sku') ? $request->string('sku')->trim()->toString() : $settings->generateSku();
        $barcode = $request->filled('barcode')
            ? $request->string('barcode')->trim()->toString()
            : ($settings->get('auto_generate_barcode') ? $barcodeService->generateInternalValue(new Product(['sku' => $sku])) : null);

        DB::transaction(function () use ($request, $imagePath, $stockQuantity, $barcode, $sku, $stockService) {
            $product = Product::create([
                'category_id' => $request->integer('category_id'),
                'name' => $request->string('name')->trim()->toString(),
                'sku' => $sku,
                'barcode' => $barcode,
                'description' => $request->filled('description') ? $request->string('description')->trim()->toString() : null,
                'cost_price' => $request->input('cost_price'),
                'selling_price' => $request->input('selling_price'),
                'stock_quantity' => $stockQuantity,
                'minimum_stock' => $request->input('minimum_stock'),
                'unit' => $request->string('unit')->trim()->toString(),
                'image' => $imagePath,
                'is_active' => $request->boolean('is_active'),
            ]);

            $stockService->recordOpeningBalance($product, $request->user(), $stockQuantity);
        });

        return redirect()->route('products.index')->with('success', 'បានបង្កើតផលិតផលដោយជោគជ័យ។');
    }

    public function show(Product $product): View
    {
        return view('products.show', [
            'product' => $product->load(['category:id,name', 'stockMovements' => fn ($query) => $query->latest()->limit(20)->with('user:id,name')])->loadCount([
                'purchaseItems',
                'saleItems',
                'stockMovements',
            ]),
        ]);
    }

    public function edit(Product $product): View
    {
        return view('products.edit', [
            'product' => $product,
            'categories' => Category::where('is_active', true)->orderBy('name')->get(['id', 'name']),
        ]);
    }

    public function update(UpdateProductRequest $request, Product $product): RedirectResponse
    {
        $newImagePath = null;
        $oldImagePath = $product->image;
        if ($request->hasFile('image')) {
            $newImagePath = $request->file('image')->store('products', 'public');
        }

        DB::transaction(function () use ($request, $product, $newImagePath) {
            $product->update([
                'category_id' => $request->integer('category_id'),
                'name' => $request->string('name')->trim()->toString(),
                'sku' => $request->string('sku')->trim()->toString(),
                'barcode' => $request->filled('barcode') ? $request->string('barcode')->trim()->toString() : null,
                'description' => $request->filled('description') ? $request->string('description')->trim()->toString() : null,
                'cost_price' => $request->input('cost_price'),
                'selling_price' => $request->input('selling_price'),
                'minimum_stock' => $request->input('minimum_stock'),
                'unit' => $request->string('unit')->trim()->toString(),
                'image' => $newImagePath ?: $product->image,
                'is_active' => $request->boolean('is_active'),
            ]);
        });

        if ($newImagePath && $oldImagePath && $oldImagePath !== $newImagePath) {
            Storage::disk('public')->delete($oldImagePath);
        }

        return redirect()->route('products.index')->with('success', 'បានកែសម្រួលផលិតផលដោយជោគជ័យ។');
    }

    public function destroy(Product $product): RedirectResponse
    {
        if ($product->purchaseItems()->exists() || $product->saleItems()->exists()) {
            return back()->with('error', 'មិនអាចលុបផលិតផលនេះបានទេ ព្រោះមានប្រវត្តិការទិញ ឬការលក់។');
        }

        $imagePath = $product->image;
        $product->delete();

        if ($imagePath) {
            Storage::disk('public')->delete($imagePath);
        }

        return redirect()->route('products.index')->with('success', 'បានលុបផលិតផលដោយជោគជ័យ។');
    }
}
