<?php

namespace App\Http\Controllers;

use App\Http\Requests\SalePaymentRequest;
use App\Http\Requests\SaleRequest;
use App\Models\Product;
use App\Models\Sale;
use App\Services\InvoiceService;
use App\Services\SaleService;
use App\Services\SystemSettingsService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use RuntimeException;

class SaleController extends Controller
{
    public function __construct(
        private readonly SaleService $saleService,
        private readonly InvoiceService $invoiceService,
        private readonly SystemSettingsService $settings,
    ) {
    }

    public function index(Request $request): View
    {
        $this->authorizeSalesView($request);
        $perPage = in_array((int) $request->input('per_page', 10), [10, 25, 50], true)
            ? (int) $request->input('per_page', 10)
            : 10;

        $sales = Sale::query()
            ->with(['creator:id,name'])
            ->withSum('items as total_quantity', 'quantity')
            ->when(
                $request->filled('search'),
                fn ($query) => $query->where(function ($searchQuery) use ($request) {
                    $search = $request->input('search');
                    $searchQuery->where('sale_number', 'like', "%{$search}%")
                        ->orWhere('customer_name', 'like', "%{$search}%")
                        ->orWhere('customer_phone', 'like', "%{$search}%");
                })
            )
            ->when($request->filled('status'), fn ($query) => $query->where('status', $request->input('status')))
            ->when($request->filled('payment_status'), fn ($query) => $query->where('payment_status', $request->input('payment_status')))
            ->when($request->filled('payment_method'), fn ($query) => $query->whereHas('payments', fn ($paymentQuery) => $paymentQuery->where('method', $request->input('payment_method'))))
            ->when($request->filled('from_date'), fn ($query) => $query->whereDate('sold_at', '>=', $request->input('from_date')))
            ->when($request->filled('to_date'), fn ($query) => $query->whereDate('sold_at', '<=', $request->input('to_date')))
            ->when(
                ! $request->user()->hasRole('admin') && ! $request->user()->hasRole('manager')
                    && ! $request->user()->hasPermission('sales.manage') && ! $request->user()->hasPermission('sales.view'),
                fn ($query) => $query->where('created_by', $request->user()->id)
            )
            ->latest('sold_at')
            ->latest('id')
            ->paginate($perPage)
            ->withQueryString();

        return view('sales.index', ['sales' => $sales]);
    }

    public function create(Request $request): View
    {
        $this->authorizeSaleOperation($request);
        return view('sales.create', [
            'products' => Product::query()
                ->where('is_active', true)
                ->when(! $this->settings->get('allow_negative_stock'), fn ($query) => $query->where('stock_quantity', '>', 0))
                ->orderBy('name')
                ->get(['id', 'name', 'sku', 'barcode', 'selling_price', 'stock_quantity', 'image', 'unit']),
            'settings' => $this->settings->all(),
        ]);
    }

    public function store(SaleRequest $request): RedirectResponse
    {
        try {
            $sale = $this->saleService->create($request->validated(), $request->user());
            $destination = $this->settings->get('print_receipt_automatically') ? 'sales.print' : 'sales.show';
            return redirect()->route($destination, $sale)->with('success', 'ការលក់បានរក្សាទុកដោយជោគជ័យ។');
        } catch (RuntimeException $exception) {
            return back()->withInput()->with('error', $exception->getMessage());
        }
    }

    public function show(Request $request, Sale $sale): View
    {
        $this->authorizeSalesView($request);
        $this->authorizeOwnSale($request, $sale);
        $sale->load(['creator', 'items.product', 'payments.recorder']);
        $receipt = $this->invoiceService->receipt($sale);
        return view('sales.show', ['sale' => $sale, ...$receipt]);
    }

    public function edit(Request $request, Sale $sale): RedirectResponse
    {
        if (! $request->user()->hasRole('admin') && ! $request->user()->hasPermission('sales.manage')) {
            abort(403, 'អ្នកមិនមានសិទ្ធិកែសម្រួលការលក់។');
        }
        if ($sale->status !== 'draft') {
            return redirect()->route('sales.show', $sale)->with('error', 'ការលក់ដែលបានបញ្ចប់មិនអាចកែសម្រួលបានទេ។');
        }
        return redirect()->route('sales.show', $sale);
    }

    public function destroy(Request $request, Sale $sale): RedirectResponse
    {
        abort(403, 'ការលុបការលក់មិនត្រូវបានអនុញ្ញាត។ សូមប្រើការលុបចោល។');
    }

    public function storePayment(SalePaymentRequest $request, Sale $sale): RedirectResponse
    {
        try {
            $this->saleService->addPayment($sale, $request->validated(), $request->user());
            return redirect()->route('sales.show', $sale)->with('success', 'បានកត់ត្រាការទូទាត់ដោយជោគជ័យ។');
        } catch (RuntimeException $exception) {
            return back()->withInput()->with('error', $exception->getMessage());
        }
    }

    public function cancel(Request $request, Sale $sale): RedirectResponse
    {
        if (! $request->user()->hasRole('admin') && ! $request->user()->hasPermission('sales.manage')) {
            abort(403, 'អ្នកមិនមានសិទ្ធិលុបចោលការលក់។');
        }
        try {
            $this->saleService->cancel($sale, $request->user(), $request->input('reason'));
            return redirect()->route('sales.show', $sale)->with('success', 'បានលុបចោលការលក់ និងស្តុកត្រឡប់ដោយជោគជ័យ។');
        } catch (RuntimeException $exception) {
            return back()->with('error', $exception->getMessage());
        }
    }

    public function print(Request $request, Sale $sale): View
    {
        $this->authorizeSalesView($request);
        $this->authorizeOwnSale($request, $sale);
        $sale->load(['creator', 'items.product', 'payments.recorder']);
        return view('sales.receipt', ['sale' => $sale, ...$this->invoiceService->receipt($sale)]);
    }

    public function productSearch(Request $request): JsonResponse
    {
        $this->authorizeSaleOperation($request);
        $search = trim((string) $request->input('q', ''));
        $products = Product::query()
            ->where('is_active', true)
            ->when(! $this->settings->get('allow_negative_stock'), fn ($query) => $query->where('stock_quantity', '>', 0))
            ->when($search !== '', fn ($query) => $query->where(function ($productQuery) use ($search) {
                $productQuery->where('name', 'like', "%{$search}%")
                    ->orWhere('sku', 'like', "%{$search}%")
                    ->orWhere('barcode', 'like', "%{$search}%");
            }))
            ->orderBy('name')
            ->limit(20)
            ->get(['id', 'name', 'sku', 'barcode', 'selling_price', 'stock_quantity', 'image', 'unit']);

        return response()->json($products);
    }

    public function barcodeLookup(Request $request): JsonResponse
    {
        $this->authorizeSaleOperation($request);
        $barcode = trim((string) $request->input('barcode', $request->route('barcode')));
        $product = Product::query()
            ->where('barcode', $barcode)
            ->first(['id', 'name', 'sku', 'barcode', 'selling_price', 'stock_quantity', 'image', 'unit', 'is_active']);

        if (! $product) {
            return response()->json(['message' => 'រកមិនឃើញផលិតផលតាម Barcode នេះ។'], 404);
        }
        if (! $product->is_active) {
            return response()->json(['message' => 'ផលិតផលនេះមិនសកម្មទេ។'], 422);
        }
        if ((float) $product->stock_quantity <= 0 && ! $this->settings->get('allow_negative_stock')) {
            return response()->json(['message' => 'ផលិតផលនេះអស់ស្តុក។'], 422);
        }
        return response()->json($product);
    }

    public function qrProductLookup(Request $request): JsonResponse
    {
        $this->authorizeSaleOperation($request);
        $validated = $request->validate([
            'product_id' => ['required', 'integer', 'exists:products,id'],
        ]);
        $product = Product::query()->findOrFail($validated['product_id']);

        if (! $product->is_active) {
            return response()->json(['message' => 'ផលិតផលនេះមិនសកម្មទេ។'], 422);
        }
        if ((float) $product->stock_quantity <= 0 && ! $this->settings->get('allow_negative_stock')) {
            return response()->json(['message' => 'ផលិតផលនេះអស់ស្តុក។'], 422);
        }

        return response()->json($product->only([
            'id', 'name', 'sku', 'barcode', 'selling_price', 'stock_quantity', 'image', 'unit',
        ]));
    }

    private function authorizeSalesView(Request $request): void
    {
        $user = $request->user();
        if (! $user->hasRole('admin') && ! $user->hasRole('manager')
            && ! $user->hasPermission('sales.manage') && ! $user->hasPermission('sales.view') && ! $user->hasPermission('sales.create')) {
            abort(403, 'អ្នកមិនមានសិទ្ធិមើលការលក់។');
        }
    }

    private function authorizeSaleOperation(Request $request): void
    {
        $user = $request->user();
        if (! $user->hasRole('admin') && ! $user->hasPermission('sales.manage') && ! $user->hasPermission('sales.create')) {
            abort(403, 'អ្នកមិនមានសិទ្ធិបង្កើតការលក់។');
        }
    }

    private function authorizeOwnSale(Request $request, Sale $sale): void
    {
        $user = $request->user();
        if (! $user->hasRole('admin') && ! $user->hasRole('manager')
            && ! $user->hasPermission('sales.manage') && ! $user->hasPermission('sales.view')) {
            if ($sale->created_by !== $user->id) {
                abort(403, 'អ្នកមិនអាចមើលការលក់របស់អ្នកដទៃបានទេ។');
            }
        }
    }
}
