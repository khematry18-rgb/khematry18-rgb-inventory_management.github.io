<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Notifications\DatabaseNotification;
use Illuminate\View\View;

class NotificationController extends Controller
{
    public function recent(Request $request): JsonResponse
    {
        return response()->json([
            'notifications' => $request->user()->notifications()
                ->latest()
                ->limit(5)
                ->get(['id', 'data', 'read_at', 'created_at'])
                ->map(fn (DatabaseNotification $notification) => [
                    'id' => $notification->id,
                    'title' => $notification->data['title'] ?? 'ការជូនដំណឹង',
                    'message' => $notification->data['message'] ?? '',
                    'read' => $notification->read_at !== null,
                    'created_at' => $notification->created_at->diffForHumans(),
                ]),
        ]);
    }

    public function index(Request $request): View
    {
        return view('notifications.index', [
            'notifications' => $request->user()->notifications()->latest()->paginate(15),
            'unreadCount' => $request->user()->unreadNotifications()->count(),
        ]);
    }

    public function show(Request $request, string $notification): View
    {
        $notification = $request->user()->notifications()->whereKey($notification)->firstOrFail();
        $notification->markAsRead();

        return view('notifications.show', compact('notification'));
    }

    public function markAsRead(Request $request, string $notification): RedirectResponse
    {
        $this->ownedNotification($request, $notification)->markAsRead();

        return back()->with('success', 'បានសម្គាល់ថាបានអាន។');
    }

    public function markAsUnread(Request $request, string $notification): RedirectResponse
    {
        $this->ownedNotification($request, $notification)->markAsUnread();

        return back()->with('success', 'បានសម្គាល់ថាមិនទាន់អាន។');
    }

    public function markAllAsRead(Request $request): RedirectResponse
    {
        $request->user()->unreadNotifications()->update(['read_at' => now()]);

        return back()->with('success', 'បានសម្គាល់ការជូនដំណឹងទាំងអស់ថាបានអាន។');
    }

    public function destroy(Request $request, string $notification): RedirectResponse
    {
        $this->ownedNotification($request, $notification)->delete();

        return redirect()->route('notifications.index')->with('success', 'បានលុបការជូនដំណឹង។');
    }

    public function clear(Request $request): RedirectResponse
    {
        $request->user()->notifications()->delete();

        return redirect()->route('notifications.index')->with('success', 'បានសម្អាតការជូនដំណឹងទាំងអស់។');
    }

    private function ownedNotification(Request $request, string $id): DatabaseNotification
    {
        return $request->user()->notifications()->whereKey($id)->firstOrFail();
    }
}
