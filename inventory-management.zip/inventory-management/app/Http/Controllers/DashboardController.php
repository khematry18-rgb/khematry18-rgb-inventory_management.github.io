<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\ActivityLog;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\Sale;
use App\Models\StockMovement;
use App\Models\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use App\Services\SystemSettingsService;

class DashboardController extends Controller
{
    public function index(Request $request): View
    {
        $settings = app(SystemSettingsService::class);
        $displayCurrency = $settings->get('currency_code');
        $user = $request->user();
        $isAdmin = $user->hasRole('admin');
        $isManager = $user->hasRole('manager');
        $isStaff = $user->hasRole('staff');
        $canViewReports = $isAdmin || $isManager || $user->hasPermission('reports.view');
        $canViewProducts = $isAdmin || $isManager || $isStaff || $user->hasPermission('products.manage') || $user->hasPermission('products.view');
        $canViewCategories = $isAdmin || $isManager || $user->hasPermission('categories.manage');
        $canViewSuppliers = $isAdmin || $isManager || $user->hasPermission('suppliers.manage');
        $canViewSales = $isAdmin || $isManager || $isStaff || $user->hasPermission('sales.manage') || $user->hasPermission('sales.view') || $user->hasPermission('sales.create');
        $canViewPurchases = $isAdmin || $isManager || $canViewReports || $user->hasPermission('purchases.manage');
        $canViewStock = $isAdmin || $isManager || $isStaff || $user->hasPermission('stock.manage') || $user->hasPermission('stock.view');
        $canViewActivityLogs = $isAdmin || $user->hasPermission('activity-logs.view');

        $period = (int) $request->integer('period', 30);
        $period = in_array($period, [7, 30, 90], true) ? $period : 30;
        $start = Carbon::today()->subDays($period - 1)->startOfDay();
        $end = Carbon::now()->endOfDay();
        $todayStart = Carbon::today();
        $todayEnd = Carbon::now();

        $completedSales = Sale::query()->whereIn('status', ['completed', 'confirmed']);
        if (! $canViewReports) {
            $completedSales->where('created_by', $user->id);
        }

        $chartSales = (clone $completedSales)
            ->where('currency', $displayCurrency)
            ->where(function ($query) use ($start, $end) {
                $query->whereBetween('completed_at', [$start, $end])
                    ->orWhere(function ($fallback) use ($start, $end) {
                        $fallback->whereNull('completed_at')->whereBetween('sold_at', [$start, $end]);
                    });
            })
            ->with(['items:id,sale_id,product_id,quantity,line_total,cost_price'])
            ->get(['id', 'currency', 'grand_total', 'completed_at', 'sold_at']);

        $chartPurchases = collect();
        if ($canViewPurchases && $canViewReports) {
            $chartPurchases = Purchase::query()
                ->where('status', 'confirmed')
                ->where('currency', $displayCurrency)
                ->where(function ($query) use ($start, $end) {
                    $query->whereBetween('confirmed_at', [$start, $end])
                        ->orWhere(function ($fallback) use ($start, $end) {
                            $fallback->whereNull('confirmed_at')->whereBetween('purchased_at', [$start, $end]);
                        });
                })
                ->get(['grand_total', 'confirmed_at', 'purchased_at']);
        }

        $daily = $this->buildDailySeries($start, $chartSales, $chartPurchases);
        $historyStart = Carbon::now()->subMonths(11)->startOfMonth();
        $historyEnd = Carbon::now()->endOfDay();
        $historySales = (clone $completedSales)
            ->where('currency', $displayCurrency)
            ->where(function ($query) use ($historyStart, $historyEnd) {
                $query->whereBetween('completed_at', [$historyStart, $historyEnd])
                    ->orWhere(function ($fallback) use ($historyStart, $historyEnd) {
                        $fallback->whereNull('completed_at')->whereBetween('sold_at', [$historyStart, $historyEnd]);
                    });
            })
            ->with(['items:id,sale_id,product_id,quantity,line_total,cost_price'])
            ->get(['id', 'currency', 'grand_total', 'completed_at', 'sold_at']);
        $historyPurchases = collect();
        if ($canViewPurchases && $canViewReports) {
            $historyPurchases = Purchase::query()
                ->where('status', 'confirmed')
                ->where('currency', $displayCurrency)
                ->where(function ($query) use ($historyStart, $historyEnd) {
                    $query->whereBetween('confirmed_at', [$historyStart, $historyEnd])
                        ->orWhere(function ($fallback) use ($historyStart, $historyEnd) {
                            $fallback->whereNull('confirmed_at')->whereBetween('purchased_at', [$historyStart, $historyEnd]);
                        });
                })
                ->get(['grand_total', 'currency', 'confirmed_at', 'purchased_at']);
        }
        $weekly = $this->buildGroupedSeries($historySales, $historyPurchases, 'week');
        $monthly = $this->buildGroupedSeries($historySales, $historyPurchases, 'month');

        $recentSales = Sale::query()
            ->whereIn('status', ['completed', 'confirmed'])
            ->when(! $canViewReports, fn ($query) => $query->where('created_by', $user->id))
            ->with('creator:id,name')
            ->latest('completed_at')
            ->latest('sold_at')
            ->paginate(5, ['*'], 'sales_page')
            ->withQueryString();

        $recentPurchases = $canViewPurchases && $canViewReports
            ? Purchase::query()
                ->where('status', 'confirmed')
                ->with(['supplier:id,name', 'creator:id,name'])
                ->latest('confirmed_at')
                ->latest('purchased_at')
                ->paginate(5, ['*'], 'purchases_page')
                ->withQueryString()
            : null;

        $recentMovements = $canViewStock
            ? StockMovement::query()->with('product:id,name,sku')->latest()->paginate(5, ['*'], 'movements_page')->withQueryString()
            : null;

        $lowStock = Product::query()->where('is_active', true)->where('stock_quantity', '>', 0)->whereColumn('stock_quantity', '<=', 'minimum_stock')->count();
        $outOfStock = Product::query()->where('is_active', true)->where('stock_quantity', '<=', 0)->count();
        $totalStockQuantity = Product::query()->where('is_active', true)->sum('stock_quantity');
        $totalStockValue = (float) Product::query()->where('is_active', true)->selectRaw('COALESCE(SUM(stock_quantity * cost_price), 0) AS value')->value('value');

        $stockAlerts = $canViewStock
            ? Product::query()
                ->where('is_active', true)
                ->whereColumn('stock_quantity', '<=', 'minimum_stock')
                ->orderBy('stock_quantity')
                ->paginate(8, ['*'], 'stock_page')
                ->withQueryString()
            : null;

        $totalProducts = Product::count();
        $totalCategories = Category::count();
        $totalSuppliers = Supplier::count();
        $totalSalesCount = $canViewSales ? (clone $completedSales)->count() : 0;
        $salesRevenue = $canViewSales ? (float) (clone $completedSales)->where('currency', $displayCurrency)->sum('grand_total') : 0;
        $totalPurchasesCount = $canViewPurchases ? Purchase::query()->where('status', 'confirmed')->count() : 0;
        $purchaseTotal = $canViewPurchases ? (float) Purchase::query()->where('status', 'confirmed')->where('currency', $displayCurrency)->sum('grand_total') : 0;

        $todaySales = $canViewSales
            ? (clone $completedSales)
                ->where('currency', $displayCurrency)
                ->where(function ($query) use ($todayStart, $todayEnd) {
                    $query->whereBetween('completed_at', [$todayStart, $todayEnd])
                        ->orWhere(function ($fallback) use ($todayStart, $todayEnd) {
                            $fallback->whereNull('completed_at')->whereBetween('sold_at', [$todayStart, $todayEnd]);
                        });
                })
            : null;
        $todaySalesCount = $todaySales ? (clone $todaySales)->count() : 0;
        $todaySalesTotal = $todaySales ? (float) (clone $todaySales)->sum('grand_total') : 0;

        $todayPurchases = $canViewPurchases
            ? Purchase::query()
                ->where('status', 'confirmed')
                ->where('currency', $displayCurrency)
                ->where(function ($query) use ($todayStart, $todayEnd) {
                    $query->whereBetween('confirmed_at', [$todayStart, $todayEnd])
                        ->orWhere(function ($fallback) use ($todayStart, $todayEnd) {
                            $fallback->whereNull('confirmed_at')->whereBetween('purchased_at', [$todayStart, $todayEnd]);
                        });
                })
            : null;
        $todayPurchasesCount = $todayPurchases ? (clone $todayPurchases)->count() : 0;
        $todayPurchasesTotal = $todayPurchases ? (float) (clone $todayPurchases)->sum('grand_total') : 0;

        $topSellingProducts = $canViewSales
            ? DB::table('sale_items')
                ->join('sales', 'sales.id', '=', 'sale_items.sale_id')
                ->join('products', 'products.id', '=', 'sale_items.product_id')
                ->whereIn('sales.status', ['completed', 'confirmed'])
                ->where('sales.currency', $displayCurrency)
                ->whereNull('sales.deleted_at')
                ->whereNull('products.deleted_at')
                ->where('products.is_active', true)
                ->where(function ($query) use ($start, $end) {
                    $query->whereBetween('sales.completed_at', [$start, $end])
                        ->orWhere(function ($fallback) use ($start, $end) {
                            $fallback->whereNull('sales.completed_at')->whereBetween('sales.sold_at', [$start, $end]);
                        });
                })
                ->when(! $canViewReports, fn ($query) => $query->where('sales.created_by', $user->id))
                ->select([
                    DB::raw('products.id AS product_id'),
                    'products.name',
                    'products.sku',
                    DB::raw('SUM(sale_items.quantity) AS quantity_sold'),
                    DB::raw('SUM(sale_items.line_total) AS total_sales'),
                ])
                ->groupBy('products.id', 'products.name', 'products.sku')
                ->orderByDesc('quantity_sold')
                ->limit(5)
                ->get()
            : collect();

        $recentActivities = ActivityLog::query()
            ->with('user:id,name')
            ->when(! $canViewActivityLogs, fn ($query) => $query->where('user_id', $user->id))
            ->latest()
            ->limit(8)
            ->get();

        $periodSalesRevenue = $canViewSales ? (float) (clone $completedSales)
            ->where(function ($query) use ($start, $end) {
                $query->whereBetween('completed_at', [$start, $end])
                    ->orWhere(function ($fallback) use ($start, $end) {
                        $fallback->whereNull('completed_at')->whereBetween('sold_at', [$start, $end]);
                    });
            })->where('currency', $displayCurrency)->sum('grand_total') : 0;

        $profitOverview = $chartSales->sum(function (Sale $sale) {
            $revenue = (float) $sale->grand_total;
            $costOfGoods = $sale->items->sum(function ($item) {
                return (float) $item->quantity * (float) ($item->cost_price ?? 0);
            });

            return $revenue - $costOfGoods;
        });

        $chartData = [
            'daily' => $daily,
            'weekly' => $weekly,
            'monthly' => $monthly,
        ];

        return view('dashboard.index', compact(
            'period', 'canViewReports', 'canViewProducts', 'canViewCategories',
            'canViewSuppliers', 'canViewSales', 'canViewPurchases', 'canViewStock',
            'lowStock', 'outOfStock', 'totalStockQuantity', 'totalProducts',
            'totalCategories', 'totalSuppliers', 'totalSalesCount', 'salesRevenue',
            'totalStockValue', 'todaySalesCount', 'todaySalesTotal',
            'todayPurchasesCount', 'todayPurchasesTotal',
            'totalPurchasesCount', 'purchaseTotal', 'periodSalesRevenue',
            'profitOverview', 'recentSales', 'recentPurchases', 'recentMovements',
            'stockAlerts', 'topSellingProducts', 'recentActivities',
            'canViewActivityLogs', 'chartData', 'displayCurrency'
        ));
    }

    private function buildDailySeries(Carbon $start, $sales, $purchases): array
    {
        $labels = [];
        $salesSeries = [];
        $purchaseSeries = [];
        $profitSeries = [];

        for ($date = $start->copy(); $date->lte(Carbon::today()); $date->addDay()) {
            $key = $date->toDateString();
            $labels[] = $date->format('d/m');
            $daySales = $sales->filter(fn (Sale $sale) => $this->saleDate($sale)->toDateString() === $key);
            $salesSeries[] = round($daySales->sum(fn (Sale $sale) => (float) $sale->grand_total), 2);
            $profitSeries[] = round($daySales->sum(fn (Sale $sale) => $this->saleProfit($sale)), 2);
            $purchaseSeries[] = round($purchases->filter(fn ($purchase) => $this->purchaseDate($purchase)->toDateString() === $key)
                ->sum(fn ($purchase) => (float) $purchase->grand_total), 2);
        }

        return compact('labels', 'salesSeries', 'purchaseSeries', 'profitSeries');
    }

    private function buildGroupedSeries($sales, $purchases, string $group): array
    {
        $salesGroups = collect();
        $purchaseGroups = collect();
        $profitGroups = collect();
        $format = $group === 'week' ? 'o-W' : 'Y-m';
        $labelFormat = $group === 'week' ? 'W/Y' : 'm/Y';

        foreach ($sales as $sale) {
            $date = $this->saleDate($sale);
            $key = $date->format($format);
            $salesGroups[$key] = ($salesGroups[$key] ?? 0) + (float) $sale->grand_total;
            $profitGroups[$key] = ($profitGroups[$key] ?? 0) + $this->saleProfit($sale);
        }
        foreach ($purchases as $purchase) {
            $date = $this->purchaseDate($purchase);
            $key = $date->format($format);
            $purchaseGroups[$key] = ($purchaseGroups[$key] ?? 0) + (float) $purchase->grand_total;
        }

        $keys = collect();
        for ($offset = 11; $offset >= 0; $offset--) {
            $date = $group === 'week' ? Carbon::now()->subWeeks($offset) : Carbon::now()->subMonths($offset)->startOfMonth();
            $keys->push($date->format($format));
        }
        $labels = [];
        $salesSeries = [];
        $purchaseSeries = [];
        $profitSeries = [];
        foreach ($keys as $key) {
            $part = $group === 'week'
                ? Carbon::now()->setISODate((int) substr($key, 0, 4), (int) substr($key, 5))
                : Carbon::createFromFormat('Y-m', $key)->startOfMonth();
            $labels[] = $part->format($labelFormat);
            $salesSeries[] = round((float) ($salesGroups[$key] ?? 0), 2);
            $purchaseSeries[] = round((float) ($purchaseGroups[$key] ?? 0), 2);
            $profitSeries[] = round((float) ($profitGroups[$key] ?? 0), 2);
        }

        return compact('labels', 'salesSeries', 'purchaseSeries', 'profitSeries');
    }

    private function saleDate(Sale $sale): Carbon
    {
        return $sale->completed_at ?? $sale->sold_at ?? Carbon::now();
    }

    private function purchaseDate(Purchase $purchase): Carbon
    {
        return $purchase->confirmed_at ?? $purchase->purchased_at ?? Carbon::now();
    }

    private function saleProfit(Sale $sale): float
    {
        $costOfGoods = $sale->items->sum(function ($item) {
            return (float) $item->quantity * (float) ($item->cost_price ?? 0);
        });

        return (float) $sale->grand_total - $costOfGoods;
    }
}
