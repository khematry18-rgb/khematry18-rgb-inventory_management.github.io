<?php

namespace App\Http\Controllers;

use App\Http\Requests\PurchasePaymentRequest;
use App\Http\Requests\PurchaseReceiveRequest;
use App\Http\Requests\PurchaseRequest;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\Supplier;
use App\Services\PurchaseService;
use App\Services\SystemSettingsService;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;
use RuntimeException;

class PurchaseController extends Controller
{
    public function __construct(
        private readonly PurchaseService $purchaseService,
        private readonly SystemSettingsService $settings,
    ) {
    }

    public function index(): View
    {
        $perPage = in_array((int) request('per_page', 10), [10, 25, 50], true) ? (int) request('per_page', 10) : 10;
        $purchases = Purchase::query()
            ->with(['supplier:id,name', 'creator:id,name'])
            ->withSum('items as total_quantity', 'quantity')
            ->when(request('search'), fn ($q, $search) => $q->where('purchase_number', 'like', "%{$search}%")->orWhereHas('supplier', fn ($sq) => $sq->where('name', 'like', "%{$search}%")))
            ->when(request('supplier_id'), fn ($q) => $q->where('supplier_id', request('supplier_id')))
            ->when(request('status'), fn ($q) => $q->where('status', request('status')))
            ->when(request('payment_status'), fn ($q) => $q->where('payment_status', request('payment_status')))
            ->when(request('from_date'), fn ($q) => $q->whereDate('purchased_at', '>=', request('from_date')))
            ->when(request('to_date'), fn ($q) => $q->whereDate('purchased_at', '<=', request('to_date')))
            ->latest()
            ->paginate($perPage)
            ->withQueryString();

        return view('purchases.index', [
            'purchases' => $purchases,
            'suppliers' => Supplier::where('is_active', true)->orderBy('name')->get(['id', 'name']),
        ]);
    }

    public function create(): View
    {
        return view('purchases.create', [
            'suppliers' => Supplier::where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'products' => Product::where('is_active', true)->orderBy('name')->get(['id', 'name', 'sku', 'stock_quantity', 'unit', 'cost_price']),
            'settings' => $this->settings->all(),
        ]);
    }

    public function store(PurchaseRequest $request): RedirectResponse
    {
        try {
            $purchase = $this->purchaseService->create($request->validated(), $request->user());
            return redirect()->route('purchases.show', $purchase)->with('success', 'បានបង្កើតបញ្ជាទិញដោយជោគជ័យ។');
        } catch (RuntimeException $exception) {
            return back()->withInput()->with('error', $exception->getMessage());
        }
    }

    public function show(Purchase $purchase): View
    {
        $purchase->load(['supplier', 'creator', 'receiver', 'items.product', 'payments.recorder'])->loadCount('stockMovements');
        $paid = $this->purchaseService->amountPaid($purchase);
        return view('purchases.show', [
            'purchase' => $purchase,
            'paid' => $paid,
            'outstanding' => max(0, (float) $purchase->grand_total - $paid),
        ]);
    }

    public function edit(Purchase $purchase): View
    {
        if (! in_array($purchase->status, ['draft', 'pending'], true) || $purchase->payments()->exists() || $purchase->stockMovements()->exists()) {
            abort(403, 'បញ្ជាទិញនេះមិនអាចកែសម្រួលបានទេ។');
        }
        return view('purchases.edit', [
            'purchase' => $purchase->load('items.product'),
            'suppliers' => Supplier::where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'products' => Product::where('is_active', true)->orderBy('name')->get(['id', 'name', 'sku', 'stock_quantity', 'unit', 'cost_price']),
            'settings' => $this->settings->all(),
        ]);
    }

    public function update(PurchaseRequest $request, Purchase $purchase): RedirectResponse
    {
        try {
            $purchase = $this->purchaseService->update($purchase, $request->validated());
            return redirect()->route('purchases.show', $purchase)->with('success', 'បានកែសម្រួលបញ្ជាទិញដោយជោគជ័យ។');
        } catch (RuntimeException $exception) {
            return back()->withInput()->with('error', $exception->getMessage());
        }
    }

    public function destroy(Purchase $purchase): RedirectResponse
    {
        if ($purchase->stockMovements()->exists() || $purchase->payments()->exists()) {
            return back()->with('error', 'មិនអាចលុបបញ្ជាទិញដែលមានស្តុក ឬការទូទាត់។ សូមប្រើការលុបចោល។');
        }
        if (! in_array($purchase->status, ['draft', 'pending', 'cancelled'], true)) {
            return back()->with('error', 'បញ្ជាទិញនេះមិនអាចលុបបានទេ។');
        }
        $purchase->delete();
        return redirect()->route('purchases.index')->with('success', 'បានលុបបញ្ជាទិញដោយជោគជ័យ។');
    }

    public function receive(Purchase $purchase): View
    {
        if (! in_array($purchase->status, ['draft', 'pending', 'partially_received'], true)) {
            abort(403, 'បញ្ជាទិញនេះមិនអាចទទួលស្តុកបានទេ។');
        }
        return view('purchases.receive', ['purchase' => $purchase->load(['supplier', 'items.product'])]);
    }

    public function storeReceive(PurchaseReceiveRequest $request, Purchase $purchase): RedirectResponse
    {
        try {
            $purchase = $this->purchaseService->receive($purchase, $request->validated(), $request->user());
            return redirect()->route('purchases.show', $purchase)->with('success', 'បានទទួលស្តុកបញ្ជាទិញដោយជោគជ័យ។');
        } catch (RuntimeException $exception) {
            return back()->withInput()->with('error', $exception->getMessage());
        }
    }

    public function cancelRequest(Purchase $purchase): RedirectResponse
    {
        $reason = request('reason');
        try {
            $this->purchaseService->cancel($purchase, request()->user(), $reason);
            return redirect()->route('purchases.show', $purchase)->with('success', 'បានលុបចោលបញ្ជាទិញដោយជោគជ័យ។');
        } catch (RuntimeException $exception) {
            return back()->with('error', $exception->getMessage());
        }
    }

    public function storePayment(PurchasePaymentRequest $request, Purchase $purchase): RedirectResponse
    {
        try {
            $this->purchaseService->addPayment($purchase, $request->validated(), $request->user());
            return redirect()->route('purchases.show', $purchase)->with('success', 'បានកត់ត្រាការទូទាត់ដោយជោគជ័យ។');
        } catch (RuntimeException $exception) {
            return back()->withInput()->with('error', $exception->getMessage());
        }
    }

    public function print(Purchase $purchase): View
    {
        $purchase->load(['supplier', 'creator', 'receiver', 'items.product', 'payments.recorder']);
        return view('purchases.print', ['purchase' => $purchase]);
    }
}
