<?php

namespace App\Http\Controllers;

use App\Http\Requests\UpdateSystemSettingsRequest;
use App\Models\SystemSetting;
use App\Services\ActivityLogService;
use App\Services\StockAlertService;
use App\Services\SystemSettingsService;
use DateTimeZone;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class SystemSettingsController extends Controller
{
    public function __construct(private readonly SystemSettingsService $settings)
    {
    }

    public function edit(): View
    {
        return view('settings.edit', [
            'settings' => $this->settings->all(),
            'timezones' => DateTimeZone::listIdentifiers(),
        ]);
    }

    public function update(
        UpdateSystemSettingsRequest $request,
        ActivityLogService $activityLog,
        StockAlertService $stockAlerts,
    ): RedirectResponse
    {
        $validated = $request->validated();
        $oldLogo = $this->settings->get('store_logo');

        if ($request->hasFile('store_logo')) {
            $path = $request->file('store_logo')->store('branding', 'public');
            if (! $path) {
                throw new \RuntimeException('មិនអាចរក្សាទុករូបសញ្ញាហាងបានទេ។');
            }
            $validated['store_logo'] = $path;
        } else {
            unset($validated['store_logo']);
        }

        $saved = $this->settings->save($validated);

        if (! empty($saved['store_logo']) && $oldLogo && $oldLogo !== $saved['store_logo']) {
            Storage::disk('public')->delete($oldLogo);
        }

        $activityLog->record(
            'updated',
            'settings',
            'បានធ្វើបច្ចុប្បន្នភាពការកំណត់ប្រព័ន្ធ។',
            SystemSetting::query()->find(1),
            $request->user()->id,
            $request,
        );
        $stockAlerts->checkAll();

        return redirect()->route('settings.edit')->with('success', 'បានរក្សាទុកការកំណត់ដោយជោគជ័យ។');
    }

    public function removeLogo(ActivityLogService $activityLog): RedirectResponse
    {
        $path = $this->settings->get('store_logo');
        $this->settings->save(['store_logo' => null]);

        if ($path) {
            Storage::disk('public')->delete($path);
        }

        $activityLog->record(
            'updated',
            'settings',
            'បានលុបរូបសញ្ញាហាង។',
            SystemSetting::query()->find(1),
        );

        return redirect()->route('settings.edit')->with('success', 'បានលុបរូបសញ្ញាដោយជោគជ័យ។');
    }
}
