<?php

namespace App\Http\Controllers;

use App\Http\Requests\UpdatePasswordRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ProfileController extends Controller
{
    public function edit(Request $request)
    {
        return view('profile.edit', ['user' => $request->user()->load('role')]);
    }

    public function update(Request $request)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'phone' => ['nullable', 'string', 'max:30'],
        ], [
            'name.required' => 'សូមបញ្ចូលឈ្មោះ។',
        ]);

        $request->user()->update($validated);

        return back()->with('success', 'បានកែសម្រួលប្រវត្តិរូបដោយជោគជ័យ។');
    }

    public function updatePassword(UpdatePasswordRequest $request)
    {
        $request->user()->update([
            'password' => Hash::make($request->string('password')->toString()),
        ]);

        return back()->with('success', 'បានផ្លាស់ប្តូរលេខសម្ងាត់ដោយជោគជ័យ។');
    }
}
