<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Services\ActivityLogService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class AuthenticatedSessionController extends Controller
{
    /**
     * Handle the incoming request.
     */
    public function create(): View
    {
        return view('auth.login');
    }

    public function store(Request $request): RedirectResponse
    {
        $credentials = $request->validate([
            'email' => ['required', 'string', 'email'],
            'password' => ['required', 'string'],
        ], [
            'email.required' => 'សូមបញ្ចូលអ៊ីមែល។',
            'email.email' => 'អ៊ីមែលមិនត្រឹមត្រូវ។',
            'password.required' => 'សូមបញ្ចូលលេខសម្ងាត់។',
        ]);

        if (! Auth::attempt([
            'email' => $credentials['email'],
            'password' => $credentials['password'],
            'is_active' => true,
        ], $request->boolean('remember'))) {
            throw ValidationException::withMessages([
                'email' => 'អ៊ីមែល ឬលេខសម្ងាត់មិនត្រឹមត្រូវ ឬគណនីត្រូវបានបិទ។',
            ]);
        }

        $request->session()->regenerate();
        app(ActivityLogService::class)->record(
            'login',
            'auth',
            'បានចូលប្រើប្រព័ន្ធ។',
            null,
            Auth::id(),
            $request,
        );

        return redirect()->intended(
            '/dashboard'
        );
    }

    public function destroy(Request $request): RedirectResponse
    {
        app(ActivityLogService::class)->record(
            'logout',
            'auth',
            'បានចាកចេញពីប្រព័ន្ធ។',
            null,
            Auth::id(),
            $request,
        );
        Auth::guard('web')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }
}
