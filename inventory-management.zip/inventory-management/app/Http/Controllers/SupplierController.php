<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreSupplierRequest;
use App\Http\Requests\UpdateSupplierRequest;
use App\Models\Supplier;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class SupplierController extends Controller
{
    public function index(): View
    {
        $perPage = in_array((int) request('per_page', 10), [10, 25, 50], true)
            ? (int) request('per_page', 10)
            : 10;

        $suppliers = Supplier::query()
            ->withCount('purchases')
            ->when(request('search'), function ($query, $search) {
                $query->where(function ($query) use ($search) {
                    $query->where('name', 'like', "%{$search}%")
                        ->orWhere('company_name', 'like', "%{$search}%")
                        ->orWhere('contact_person', 'like', "%{$search}%")
                        ->orWhere('phone', 'like', "%{$search}%")
                        ->orWhere('email', 'like', "%{$search}%");
                });
            })
            ->when(request()->filled('is_active'), fn ($query) => $query->where('is_active', request('is_active')))
            ->latest()
            ->paginate($perPage)
            ->withQueryString();

        return view('suppliers.index', compact('suppliers'));
    }

    public function create(): View
    {
        return view('suppliers.create');
    }

    public function store(StoreSupplierRequest $request): RedirectResponse
    {
        Supplier::create($request->validated());

        return redirect()->route('suppliers.index')->with('success', 'បានបង្កើតអ្នកផ្គត់ផ្គង់ដោយជោគជ័យ។');
    }

    public function show(Supplier $supplier): View
    {
        $supplier->loadCount('purchases');
        $recentPurchases = $supplier->purchases()
            ->latest('confirmed_at')
            ->latest('purchased_at')
            ->limit(10)
            ->get(['id', 'purchase_number', 'supplier_id', 'purchased_at', 'confirmed_at', 'status', 'grand_total', 'currency']);
        $totalPurchaseAmounts = $supplier->purchases()
            ->where('status', 'confirmed')
            ->selectRaw("COALESCE(currency, 'USD') as currency, SUM(grand_total) as total")
            ->groupBy('currency')
            ->get()
            ->keyBy('currency');

        return view('suppliers.show', compact('supplier', 'recentPurchases', 'totalPurchaseAmounts'));
    }

    public function edit(Supplier $supplier): View
    {
        return view('suppliers.edit', compact('supplier'));
    }

    public function update(UpdateSupplierRequest $request, Supplier $supplier): RedirectResponse
    {
        $supplier->update($request->validated());

        return redirect()->route('suppliers.index')->with('success', 'បានកែសម្រួលអ្នកផ្គត់ផ្គង់ដោយជោគជ័យ។');
    }

    public function destroy(Supplier $supplier): RedirectResponse
    {
        if ($supplier->purchases()->exists()) {
            return back()->with('error', 'មិនអាចលុបអ្នកផ្គត់ផ្គង់នេះបានទេ ព្រោះមានប្រវត្តិការទិញ។');
        }

        $supplier->delete();

        return redirect()->route('suppliers.index')->with('success', 'បានលុបអ្នកផ្គត់ផ្គង់ដោយជោគជ័យ។');
    }
}
