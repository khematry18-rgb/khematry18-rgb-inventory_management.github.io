<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ActivityLogController extends Controller
{
    public function index(Request $request): View
    {
        $filters = $request->validate([
            'search' => ['nullable', 'string', 'max:150'],
            'user_id' => ['nullable', 'integer', 'exists:users,id'],
            'module' => ['nullable', 'string', 'max:50'],
            'action' => ['nullable', 'string', 'max:80'],
            'from_date' => ['nullable', 'date'],
            'to_date' => ['nullable', 'date', 'after_or_equal:from_date'],
            'per_page' => ['nullable', 'integer', 'in:10,25,50'],
        ]);

        $logs = ActivityLog::query()
            ->with('user:id,name')
            ->when($request->filled('search'), function ($query) use ($filters) {
                $search = '%' . $filters['search'] . '%';
                $query->where(function ($searchQuery) use ($search) {
                    $searchQuery->where('description', 'like', $search)
                        ->orWhere('action', 'like', $search)
                        ->orWhere('module', 'like', $search)
                        ->orWhere('ip_address', 'like', $search)
                        ->orWhereHas('user', fn ($userQuery) => $userQuery->where('name', 'like', $search));
                });
            })
            ->when($request->filled('user_id'), fn ($query) => $query->where('user_id', $filters['user_id']))
            ->when($request->filled('module'), fn ($query) => $query->where('module', $filters['module']))
            ->when($request->filled('action'), fn ($query) => $query->where('action', $filters['action']))
            ->when($request->filled('from_date'), fn ($query) => $query->whereDate('created_at', '>=', $filters['from_date']))
            ->when($request->filled('to_date'), fn ($query) => $query->whereDate('created_at', '<=', $filters['to_date']))
            ->latest()
            ->paginate((int) ($filters['per_page'] ?? 10))
            ->withQueryString();

        return view('activity-logs.index', [
            'logs' => $logs,
            'users' => User::query()->whereHas('activityLogs')->orderBy('name')->get(['id', 'name']),
            'modules' => ActivityLog::query()->select('module')->distinct()->orderBy('module')->pluck('module'),
            'actions' => ActivityLog::query()->select('action')->distinct()->orderBy('action')->pluck('action'),
        ]);
    }

    public function show(ActivityLog $activityLog): View
    {
        return view('activity-logs.show', [
            'activityLog' => $activityLog->load(['user:id,name', 'subject']),
        ]);
    }
}
