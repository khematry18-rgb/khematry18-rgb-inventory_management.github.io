<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Services\BarcodeService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\View\View;

class BarcodeController extends Controller
{
    public function __construct(private readonly BarcodeService $barcodeService)
    {
    }

    public function index(Request $request): View
    {
        $products = Product::query()
            ->whereNotNull('barcode')
            ->when($request->filled('search'), function ($query) use ($request) {
                $search = trim((string) $request->input('search'));
                $query->where(function ($productQuery) use ($search) {
                    $productQuery->where('name', 'like', "%{$search}%")
                        ->orWhere('sku', 'like', "%{$search}%")
                        ->orWhere('barcode', 'like', "%{$search}%");
                });
            })
            ->orderBy('name')
            ->paginate(25)
            ->withQueryString();

        return view('barcodes.index', compact('products'));
    }

    public function generate(Request $request, Product $product): RedirectResponse
    {
        abort_unless($request->user()->hasRole('admin') || $request->user()->hasPermission('products.manage'), 403);

        if (! $product->barcode) {
            $product->update(['barcode' => $this->barcodeService->generateInternalValue($product)]);
        }

        return back()->with('success', 'បានបង្កើត Barcode ផ្ទៃក្នុងសម្រាប់ផលិតផលនេះ។');
    }

    public function barcode(Product $product): Response
    {
        abort_if(! $product->barcode, 404, 'ផលិតផលនេះមិនទាន់មាន Barcode។');

        return response($this->barcodeService->storeBarcodeSvg($product), 200, [
            'Content-Type' => 'image/svg+xml; charset=UTF-8',
            'Content-Disposition' => 'inline; filename="product-' . $product->id . '-barcode.svg"',
            'X-Content-Type-Options' => 'nosniff',
            'Cache-Control' => 'private, max-age=3600',
        ]);
    }

    public function downloadBarcode(Product $product): Response
    {
        abort_if(! $product->barcode, 404, 'ផលិតផលនេះមិនទាន់មាន Barcode។');

        return response($this->barcodeService->storeBarcodeSvg($product), 200, [
            'Content-Type' => 'image/svg+xml; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename="product-' . $product->id . '-barcode.svg"',
            'X-Content-Type-Options' => 'nosniff',
            'Cache-Control' => 'private, no-store',
        ]);
    }

    public function qrCode(Product $product): Response
    {
        $url = route('products.show', $product);

        return response($this->barcodeService->storeQrCodeSvg($product, $url), 200, [
            'Content-Type' => 'image/svg+xml; charset=UTF-8',
            'Content-Disposition' => 'inline; filename="product-' . $product->id . '-qr.svg"',
            'X-Content-Type-Options' => 'nosniff',
            'Cache-Control' => 'private, max-age=3600',
        ]);
    }

    public function downloadQrCode(Product $product): Response
    {
        $url = route('products.show', $product);

        return response($this->barcodeService->storeQrCodeSvg($product, $url), 200, [
            'Content-Type' => 'image/svg+xml; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename="product-' . $product->id . '-qr.svg"',
            'X-Content-Type-Options' => 'nosniff',
            'Cache-Control' => 'private, no-store',
        ]);
    }

    public function print(Request $request): View
    {
        $validated = $request->validate([
            'product_ids' => ['required', 'array', 'min:1', 'max:100'],
            'product_ids.*' => ['required', 'integer', 'distinct', 'exists:products,id'],
            'quantities' => ['required', 'array'],
            'quantities.*' => ['required', 'integer', 'min:1', 'max:100'],
            'label_size' => ['nullable', 'in:small,medium,large'],
        ], [
            'product_ids.required' => 'សូមជ្រើសរើសផលិតផលសម្រាប់បោះពុម្ព។',
            'product_ids.min' => 'សូមជ្រើសរើសផលិតផលយ៉ាងហោចណាស់មួយ។',
            'product_ids.max' => 'អាចបោះពុម្ពបានអតិបរមា 100 ផលិតផលក្នុងមួយដង។',
            'product_ids.*.exists' => 'ផលិតផលមួយចំនួនមិនមានទៀតទេ។',
            'quantities.*.max' => 'ចំនួនស្លាកនីមួយៗមិនអាចលើស 100។',
        ]);

        $products = Product::query()
            ->whereIn('id', $validated['product_ids'])
            ->whereNotNull('barcode')
            ->get()
            ->keyBy('id');

        if ($products->count() !== count($validated['product_ids'])) {
            return back()->withErrors(['product_ids' => 'ផលិតផលមួយចំនួនមិនទាន់មាន Barcode។ សូមបង្កើត Barcode ជាមុនសិន។']);
        }

        $labelCount = collect($validated['product_ids'])
            ->sum(fn ($productId) => (int) ($validated['quantities'][$productId] ?? 1));
        if ($labelCount > 250) {
            return back()->withErrors(['product_ids' => 'អាចបង្កើតស្លាកបានអតិបរមា 250 ក្នុងមួយដង។']);
        }

        $labels = [];
        foreach ($validated['product_ids'] as $productId) {
            $product = $products->get($productId);
            $quantity = (int) ($validated['quantities'][$productId] ?? 1);
            $label = [
                'product' => $product,
                'barcode_svg' => $this->barcodeService->storeBarcodeSvg($product, 38),
                'qr_svg' => $this->barcodeService->storeQrCodeSvg($product, route('products.show', $product), 48),
            ];
            for ($count = 0; $count < $quantity; $count++) {
                $labels[] = $label;
            }
        }

        return view('barcodes.print', [
            'labels' => $labels,
            'labelSize' => $validated['label_size'] ?? 'medium',
        ]);
    }
}
