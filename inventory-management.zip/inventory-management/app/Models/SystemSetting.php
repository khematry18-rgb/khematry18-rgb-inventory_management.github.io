<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SystemSetting extends Model
{
    protected $fillable = ['settings_data'];

    protected function casts(): array
    {
        return ['settings_data' => 'array'];
    }
}
