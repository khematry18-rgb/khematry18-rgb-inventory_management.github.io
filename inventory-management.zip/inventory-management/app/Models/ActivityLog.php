<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class ActivityLog extends Model
{
    protected $fillable = [
        'user_id',
        'action',
        'module',
        'description',
        'subject_type',
        'subject_id',
        'ip_address',
        'user_agent',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function subject(): MorphTo
    {
        return $this->morphTo();
    }

    public function actionLabel(): string
    {
        return match ($this->action) {
            'login' => 'ចូលប្រើប្រព័ន្ធ',
            'logout' => 'ចាកចេញពីប្រព័ន្ធ',
            'created' => 'បង្កើត',
            'updated' => 'កែប្រែ',
            'deleted' => 'លុប',
            'stock.in' => 'បញ្ចូលស្តុក',
            'stock.out' => 'ដកស្តុក',
            'stock.adjustment' => 'កែតម្រូវស្តុក',
            'purchase.received' => 'ទទួលការទិញ',
            'purchase.cancelled' => 'លុបចោលការទិញ',
            'sale.cancelled' => 'លុបចោលការលក់',
            'payment.recorded' => 'កត់ត្រាការទូទាត់',
            default => $this->action,
        };
    }

    public function moduleLabel(): string
    {
        return match ($this->module) {
            'auth' => 'ការផ្ទៀងផ្ទាត់',
            'users' => 'អ្នកប្រើប្រាស់',
            'products' => 'ផលិតផល',
            'categories' => 'ប្រភេទផលិតផល',
            'suppliers' => 'អ្នកផ្គត់ផ្គង់',
            'stock' => 'ស្តុក',
            'purchases' => 'ការទិញ',
            'sales' => 'ការលក់',
            'payments' => 'ការទូទាត់',
            'settings' => 'ការកំណត់',
            default => $this->module,
        };
    }
}
