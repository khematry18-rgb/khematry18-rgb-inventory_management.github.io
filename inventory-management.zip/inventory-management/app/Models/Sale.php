<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Sale extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = ['sale_number', 'currency', 'exchange_rate', 'created_by', 'customer_name', 'customer_phone', 'customer_email', 'customer_address', 'sold_at', 'status', 'payment_status', 'subtotal', 'discount', 'tax', 'grand_total', 'notes', 'submission_key', 'cancelled_at', 'cancel_reason', 'completed_at'];

    protected function casts(): array
    {
        return ['sold_at' => 'datetime', 'completed_at' => 'datetime', 'cancelled_at' => 'datetime', 'exchange_rate' => 'decimal:6', 'subtotal' => 'decimal:2', 'discount' => 'decimal:2', 'tax' => 'decimal:2', 'grand_total' => 'decimal:2'];
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function items(): HasMany
    {
        return $this->hasMany(SaleItem::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    public function stockMovements(): MorphMany
    {
        return $this->morphMany(StockMovement::class, 'reference');
    }
}
