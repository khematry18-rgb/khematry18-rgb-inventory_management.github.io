<?php

namespace App\Database\Query\Grammars;

use Illuminate\Database\Query\Grammars\MySqlGrammar;

class MariaDbGrammar extends MySqlGrammar
{
    public function compileThreadCount()
    {
        return "select variable_value as `Value` from information_schema.session_status where variable_name = 'THREADS_CONNECTED'";
    }
}
